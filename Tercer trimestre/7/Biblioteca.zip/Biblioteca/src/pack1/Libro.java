package pack1;

import java.util.Objects;

public class Libro {
	private String isbn;
	private String titulo;
	private String autor;
	private int anio;
	private boolean alquilado;
	private int diasAlquiler=1;
	private int diasRetraso;
	

	public Libro(String isbn, String titulo, String autor, int anio) {
		super();
		this.isbn = isbn;
		this.titulo = titulo;
		this.autor = autor;
		this.anio = anio;
		this.alquilado=false;
		this.diasAlquiler=diasAlquiler;
		this.diasRetraso=diasRetraso;
	}

	public Libro(String isbn) {
		super();
		this.isbn = isbn;
	}
	//sivamos a usar el hashset y el hashmap hay que definir el atributo en el que se va a basar el hashcode
	
	@Override
	public int hashCode() {
		return Objects.hash(isbn);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Libro other = (Libro) obj;
		return Objects.equals(isbn, other.isbn);
	}

	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public int getAnio() {
		return anio;
	}
	public void setAnio(int anio) {
		this.anio = anio;
	}

	public boolean isAlquilado() {
		return alquilado;
	}

	public void setAlquilado(boolean alquilado) {
		this.alquilado = alquilado;
	}
	

	
	public int getDiasAlquiler() {
		return diasAlquiler;
	}

	public void setDiasAlquiler(int diasAlquiler) {
		this.diasAlquiler = diasAlquiler;
	}
	
	
	public int getDiasRetraso() {
		return diasRetraso;
	}

	public void setDiasRetraso(int diasRetraso) {
		this.diasRetraso = diasRetraso;
	}

	public void alquilarLibro() {
		this.setAlquilado(true);
		this.setDiasAlquiler(5);
	}
	
	public void devolverLibro() {
		this.setAlquilado(false);
		this.setDiasAlquiler(0);
		this.setDiasRetraso(0);
	}
	
	
	public void restarDias() {
		this.diasAlquiler-=1;
		if(this.diasAlquiler<0) {
			this.diasRetraso+=1;
		}
	}
	
	
	@Override
	public String toString() {
		return "Libro [titulo=" + titulo + ", autor=" + autor + ", anio=" + anio + ", isbn=" + isbn + "]";
	}

	
	
	
}





























