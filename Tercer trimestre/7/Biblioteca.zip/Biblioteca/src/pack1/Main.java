package pack1;
import java.util.*;
public class Main {

	static Scanner sc=new Scanner(System.in);
	static Scanner scLine=new Scanner(System.in);
	static int dia=1;
	
	static HashSet<Libro> libros=new HashSet<Libro>();
	static HashSet<Usuario> usuarios=new HashSet<Usuario>();
	static HashMap<Libro, Usuario> librosPrestados= new HashMap<Libro, Usuario>();
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Libro l1=new Libro("11a", "Harry Potter", "Taylor Swift", 1998);
		Libro l2=new Libro("22b", "Percy Jackson", "Rick Riordan", 2005);
		Libro l3=new Libro("33c", "El Coleccionista de relojes extraordinarios", "Laura Gallego", 2004);
		Libro l4=new Libro("44d", "Eragon", "Christopher Paolini", 2003);
		
		libros.add(l1);
		libros.add(l2);
		libros.add(l3);
		libros.add(l4);
		
		Usuario u1=new Usuario("1234d", "Elena", "Alexandra", "Ciobanu", "Calle del Cura", "elena_ac@gmail.com");
		Usuario u2=new Usuario("1234f", "Maria", "Lopez", "Cerdan", "Calle del Tinte", "maria_lc@gmail.com");
		Usuario u3=new Usuario("1234g", "Diego", "Ramirez", "Adrade", "Calle de la Acuarela", "diego_ra@gmail.com");
		usuarios.add(u1);
		usuarios.add(u2);
		usuarios.add(u3);

		while (true) {
			System.out.println("Menú: Día "+dia+"\r\n" + "1.- Introducir libro\r\n" + "2.- Eliminar libro por ISBN\r\n"
					+ "3.- Introducir usuario\r\n" + "4.- Eliminar usuario\r\n" + "5.- Prestar libro a un usuario\r\n"
					+ "6.- Devolver libro por ISBN\r\n" + "7.- Mostrar estado de un libro\r\n"
					+ "8.- Mostrar libros prestados a un usuario\r\n" + "9.- Pasar día");
			int opcion=0;
			String opcionS;
			do {
				System.out.println("\nElija una opcion");
				opcionS = scLine.nextLine();
			} while (isNumericInt(opcionS) == false);
			opcion = Integer.valueOf(opcionS);
			switch (opcion) {
			case 1:
				introducirLibro();
				break;
			case 2:
				eliminarLibro();
				break;
			case 3:
				introducirUsuario();
				break;
			case 4:
				eliminarUsuario();
				break;
			case 5:
				prestarLibro();
				break;
			case 6:
				devolverLibro();
				break;
			case 7:
				mostrarEstado();
				break;
			case 8:
				mostrarLibrosPrestados();
				break;
			case 9:
				pasarDia();
				break;
			}
		}
	}
	
	static public boolean isNumericInt(String valor) {
		try {
			Integer.valueOf(valor);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return false;
		}
		return true;
	}
	private static void pasarDia() {
		// TODO Auto-generated method stub
		System.out.println("Lista de libros: ");
		listaLibros();
		dia+=1;
		for(Libro libro: libros) {
			if(libro.isAlquilado()==true) {
				libro.restarDias();
			}
		}
		for(Usuario usu:usuarios) {
			if(usu.isPenalizado()==true) {
				usu.restarDiasPenalizacion();
			}
		}
		
		for(Libro libro: libros) {
			if(libro.isAlquilado()==true && libro.getDiasRetraso()>0) {
				System.out.println("\nLibros retrasados");
				System.out.println(libro);
			}else if(libro.isAlquilado()==true) {
				System.out.println("\nLibros prestados");
				System.out.println(libro);
			}
		}
		System.out.println();
	}

	private static void mostrarLibrosPrestados() {
		// TODO Auto-generated method stub
		String dni=null;
		for(Usuario u:usuarios) {
			System.out.println(u);
		}
		System.out.println("\nIntroduzca el DNI del usuario");
		dni=scLine.nextLine();
		Usuario nuevoUsuario=new Usuario(dni);
		boolean existeUsuario=usuarios.contains(nuevoUsuario);
		if(existeUsuario) {
			for(Usuario u:usuarios) {
				if(u.equals(nuevoUsuario)) {
					System.out.println("Datos relativos a "+u.getNombre()+" "+u.getApe1()+" "+u.getApe2()
					+"\nDNI: "+u.getDni()
					+"\nDirección: "+u.getDireccion()
					+"\nCorreo Electrónico: "+u.getCorreo());
					if(u.getLibrosEnPosesion().isEmpty()==true) {
						System.out.println("Sin libros alquilados");
					}else {
						u.listarLibros();
					}
				}
			}
		}else {
			System.out.println("Este usuario no existe");
		}
		System.out.println();
	}

	private static void mostrarEstado() {
		// TODO Auto-generated method stub
		String isbn = null;
		System.out.println("Listado de libros:");
		for(Libro l:libros) {
			System.out.println(l.getIsbn()+" "+l.getTitulo()+"de "+l.getAutor());
		}
		System.out.println("\nIntroduzca el ISBN del libro que desea consultar");
		isbn=scLine.nextLine();
		Libro nuevolibro=new Libro(isbn);
		boolean existeLibro=libros.contains(nuevolibro);
		if(existeLibro) {
			for(Libro l:libros) {
				if(l.equals(nuevolibro)) {
					System.out.println("Información sobre el libro: "
							+ "\nTitulo: "+l.getTitulo()
							+ "\nAutor: "+l.getAutor()
							+"\nAño de publicación: "+l.getAnio()
							+"\nISBN: "+l.getIsbn());
					
					if(l.isAlquilado()==true) {//aqui hay que recorrerse el hashmap para poder sacar al usuaio
						System.out.println("Actualmente ALQUILADO");
						for(Libro ll:librosPrestados.keySet()) {
							if(ll.equals(l)) {
								Usuario uu=librosPrestados.get(l); 
								System.out.println("Alquilado por: "+ uu);
							}
						}
						if(l.getDiasAlquiler()>=0) {
							System.out.println("\nDías de alquiler restantes: "+l.getDiasAlquiler());
						}else if(l.getDiasAlquiler()<0) {
							System.out.println("\nDías de retraso: "+Math.abs(l.getDiasRetraso()));
							
						}
						
					}else {
						System.out.println("Actualmente DISPONIBLE");
					}
				}
			}
		}else {			
			System.out.println("Este libro no existe");
		}
		System.out.println();
		
	}

	private static void devolverLibro() {
		// TODO Auto-generated method stub
		String isbn = null;
		System.out.println("Lista de préstamos:");
		for(Libro l:librosPrestados.keySet()) {
			System.out.println(l.getIsbn()+" "+l.getTitulo()+"de "+l.getAutor()+" dias restantes "+l.getDiasAlquiler());
		}
		System.out.println("\nIntroduzca el ISBN del libro que desea devolver");
		isbn=scLine.nextLine();
		Libro nuevolibro=new Libro(isbn);
		boolean existeLibro=libros.contains(nuevolibro);
		if(existeLibro) {
			for(Libro l:librosPrestados.keySet()) {
				if(l.equals(nuevolibro)) {
					if(l.isAlquilado()==true) {
						Usuario uu=librosPrestados.get(l); //para obtener la persona que tiene el libro1
						if(l.getDiasRetraso()>0) {
							int dias=Math.abs(l.getDiasRetraso());
							uu.penalizar(dias);
						}
						uu.devolucion(l);
						System.out.println("Libro devuelto con éxito. Usuario :"+uu.getDni()+" "+uu.getNombre());
					}else {
						System.out.println("Este libro no está alquilado");
					}
				}
			}
		}else {			
			System.out.println("Este libro no existe");
		}
		System.out.println();
	}



	private static void prestarLibro() {
		// TODO Auto-generated method stub
		System.out.println("PRESTAMO DE LIBROS");
		String isbn,dni = null;
		listaLibros();
		System.out.println("¿ISBN?");
		isbn=scLine.nextLine();
		Libro nuevolibro=new Libro(isbn);
		boolean existeLibro=libros.contains(nuevolibro);
		if(existeLibro) {
			for(Libro l:libros) {
				if(l.equals(nuevolibro)) {
					if(l.isAlquilado()==true) {
						System.out.println("Este libro ya está alquilado");
					}else {
						listaUsuarios();
						System.out.println("\nIntroduzca el DNI del usuario");
						dni=scLine.nextLine();
						Usuario nuevoUsuario=new Usuario(dni);
						boolean existeUsuario=usuarios.contains(nuevoUsuario);
						if(existeUsuario) {
							for(Usuario u:usuarios) {
								if(u.equals(nuevoUsuario)) {
									if(u.isPenalizado()==true) {
										System.out.println("Este usuario está penalizado por "+u.getDiasPenalizacion()+" dias.");
									}else {
										if(u.getLibrosEnPosesion().size()>=3) {
											System.out.println("Este usuario ya tiene 3 libros.");
										}else {
											u.alquilar(l);
											u.listarLibros();
											librosPrestados.put(l, u);
										}
									}
								}
							}
						}else {
							System.out.println("Este usuario no existe");
						}
					}
				}
			}
		}else {			
			System.out.println("Este libro no existe");
		}
		System.out.println();
	}


	private static void eliminarUsuario() {
		// TODO Auto-generated method stub
		System.out.println("ELIMINAR USUARIO");
		listaUsuarios();
		System.out.println("Introduzca el DNI");
		String dni=null;
		dni=scLine.nextLine();
		Usuario temp=new Usuario(dni);
		boolean existe=usuarios.contains(temp);
		if(existe) {
			usuarios.remove(temp);
			System.out.println("Usuario eliminado con exito");
		}else {
			System.out.println("Este usuario no existe en la base de datos");
		}
	}

	private static void introducirUsuario() {
		// TODO Auto-generated method stub
		System.out.println("NUEVO USUARIO");
		listaUsuarios();
		System.out.println("\nIntroduzca el DNI");
		String dni,nombre,apel1,apel2=null;
		String direccion,correo=null;
		dni=scLine.nextLine();
		Usuario temp=new Usuario(dni);
		boolean existe=usuarios.contains(temp);
		if(existe) {
			System.out.println("Este usuario ya está registrado");
		}else {
			System.out.println("¿Nombre?");
			nombre=scLine.nextLine();
			System.out.println("¿Primer Apellido?");
			apel1=scLine.nextLine();
			System.out.println("¿Segundo Apellido?");
			apel2=scLine.nextLine();
			System.out.println("¿Dirección?");
			direccion=scLine.nextLine();
			System.out.println("¿Correo electrónico?");
			correo=scLine.nextLine();
			Usuario def= new Usuario(dni, nombre, apel1, apel2, direccion, correo);
			usuarios.add(def);
			System.out.println("Usuario añadido con exito");
		}
		System.out.println();
	}

	private static void listaUsuarios() {
		// TODO Auto-generated method stub
		for(Usuario u: usuarios) {
			System.out.println(u.getDni()+" Nombre: "+u.getNombre()+" "+u.getApe1()+" "+u.getApe2());
		}
	}

	private static void eliminarLibro() {
		// TODO Auto-generated method stub
		listaLibros();
		String isbn = null;
		System.out.println("¿ISBN?");
		isbn=scLine.nextLine();
		Libro libro=new Libro(isbn);
		boolean existe=libros.contains(libro);
		if(existe) {
			libros.remove(libro);
		}else {			
			System.out.println("Este libro no existe");
		}
		System.out.println();
	}

	private static void introducirLibro() {
		// TODO Auto-generated method stub
		System.out.println("NUEVO LIBRO");
		listaLibros();
		String isbn = null,titulo,autor= null;
		int anio=0;
		String opcionS;
		System.out.println("¿ISBN?");
		isbn=scLine.nextLine();
		Libro libro=new Libro(isbn);
		boolean existe=libros.contains(libro);
		if(existe) {
			System.out.println("Este libro ya esté en la biblioteca.");
		}else {
			System.out.println("¿Título?");
			titulo=scLine.nextLine();
			System.out.println("¿Autor?");
			autor=scLine.nextLine();
			do {
				System.out.println("¿Año de publicación?");
				opcionS = scLine.nextLine();
			} while (isNumericInt(opcionS) == false);
			anio = Integer.valueOf(opcionS);
			Libro lx=new Libro(isbn, titulo, autor, anio);
			libros.add(lx);
		}
			
		System.out.println();
	}
	private static void listaLibros() {
		// TODO Auto-generated method stub
		for(Libro libro:libros) {
			System.out.println("ISBN: "+libro.getIsbn()+", Título: "+libro.getTitulo());
		}
		System.out.println();
	}
}
