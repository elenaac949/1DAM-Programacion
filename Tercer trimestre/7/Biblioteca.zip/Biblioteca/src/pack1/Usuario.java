package pack1;

import java.util.HashSet;
import java.util.Objects;

public class Usuario {
	private String dni;
	private String nombre;
	private String ape1;
	private String ape2;
	private String direccion;
	private String correo;
	private boolean penalizado; //true si,false no
	private int diasPenalizacion;
	private HashSet<Libro> librosEnPosesion=new HashSet<Libro>();
	
	public Usuario(String dni, String nombre, String ape1, String ape2, String direccion, String correo) {
		super();
		this.dni = dni;
		this.nombre = nombre;
		this.ape1 = ape1;
		this.ape2 = ape2;
		this.direccion = direccion;
		this.correo = correo;
		this.penalizado=false;
		this.diasPenalizacion=diasPenalizacion;
		this.librosEnPosesion=librosEnPosesion;
	}

	public Usuario(String dni) {
		super();
		this.dni = dni;
	}

	@Override
	public int hashCode() {
		return Objects.hash(dni);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Usuario other = (Usuario) obj;
		return Objects.equals(dni, other.dni);
	}

	public String getDni() {
		return dni;
	}
	public void setDni(String dni) {
		this.dni = dni;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApe1() {
		return ape1;
	}
	public void setApe1(String ape1) {
		this.ape1 = ape1;
	}
	public String getApe2() {
		return ape2;
	}
	public void setApe2(String ape2) {
		this.ape2 = ape2;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public String getCorreo() {
		return correo;
	}
	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public boolean isPenalizado() {
		return penalizado;
	}

	public void setPenalizado(boolean penalizado) {
		this.penalizado = penalizado;
	}

	public int getDiasPenalizacion() {
		return diasPenalizacion;
	}

	public void setDiasPenalizacion(int diasPenalizacion) {
		this.diasPenalizacion = diasPenalizacion;
	}

	public HashSet<Libro> getLibrosEnPosesion() {
		return librosEnPosesion;
	}

	public void setLibrosEnPosesion(HashSet<Libro> librosEnPosesion) {
		this.librosEnPosesion = librosEnPosesion;
	}

	public void alquilar(Libro libro) {
		this.librosEnPosesion.add(libro);
		libro.alquilarLibro();
	}
	
	public void listarLibros() {
		System.out.println("Lista de libros en posesión de "+this.getNombre()+" "+this.getApe1()+" "+this.getApe2());
		for(Libro libro: librosEnPosesion) {
			System.out.println(libro);
		}	
	
	}
	
	public void devolucion(Libro libro) {
		this.librosEnPosesion.remove(libro);
		libro.devolverLibro();
	}
	
	public void penalizar(int dias) {
		this.setPenalizado(true);
		int  diasAnteriores=this.getDiasPenalizacion();
		int diasActuales=dias*2;
		diasActuales+=diasAnteriores;
		if(this.isPenalizado()==true) {
			this.setDiasPenalizacion(diasActuales);;
		}else {
			this.setDiasPenalizacion(dias*2);
		}
	}
	
	public void restarDiasPenalizacion() {
		this.diasPenalizacion-=1;
		if(this.diasPenalizacion<=0) {
			this.setPenalizado(false);
		}
	}

	@Override
	public String toString() {
		return "Usuario [dni=" + dni + ", nombre=" + nombre + ", ape1=" + ape1 + ", ape2=" + ape2 + ", direccion="
				+ direccion + ", correo=" + correo + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
