package prueba1;

public class Furgoneta extends Vehiculo{
	private double capacidad;//litros
	
	public Furgoneta(String matricula, String marca, String modelo, int caballos, double capacidad) {
		super(matricula, marca, modelo, caballos);
		this.capacidad = capacidad;
	}

	public double getCapacidad() {
		return capacidad;
	}

	public void setCapacidad(double capacidad) {
		this.capacidad = capacidad;
	}
	
	@Override
	public String toString() {
		return "Furgoneta "+ this.getMarca()+" "+this.getModelo()+" "+this.getMatricula();
	}
	
	
	
}
