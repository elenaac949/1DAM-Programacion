package prueba1;

public class Alquiler {
	private Empresa empresa;
	private Vehiculo vehiculo;
	private int dias;
	
	
	public Alquiler(Empresa empresa, Vehiculo vehiculo, int dias) {
		super();
		this.empresa = empresa;
		this.vehiculo = vehiculo;
		this.dias = dias;
		
	}

	public Empresa getEmpresa() {
		return empresa;
	}
	public void setEmpresa(Empresa empresa) {
		this.empresa = empresa;
	}
	public Vehiculo getVehiculo() {
		return vehiculo;
	}
	public void setVehiculo(Vehiculo vehiculo) {
		this.vehiculo = vehiculo;
	}
	public int getDias() {
		return dias;
	}
	public void setDias(int dias) {
		this.dias = dias;
	}
	
	public void restarDias() {
		dias-=1;
	}

	
	@Override
	public String toString() {
		return this.vehiculo.getMarca()+" "+this.vehiculo.getModelo()+" "+this.vehiculo.getMatricula()+" "+ this.empresa.getNombre()+" "+this.dias+" dias restantes";
	}
	
	
	
}
