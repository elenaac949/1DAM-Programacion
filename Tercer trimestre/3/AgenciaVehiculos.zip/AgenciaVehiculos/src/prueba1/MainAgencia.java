package prueba1;

import java.util.*;

public class MainAgencia {

	static Scanner sc = new Scanner(System.in);
	static Scanner scLine = new Scanner(System.in);
	static int dia = 1;

	static Vehiculo vehiculos[] = new Vehiculo[12];
	static Empresa empresas[] = new Empresa[6];
	static Alquiler alquileres[] = new Alquiler[vehiculos.length];

	static int numCoches = 7;
	static int numFurgos = 3;
	static int numMotos = 2;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// vehiculos

		vehiculos[0] = new Coche("111A", "Toyota", "Yaris", 100, 5);
		vehiculos[1] = new Coche("222B", "Cupra", "Terramar", 100, 4);
		vehiculos[2] = new Coche("333C", "Dacia", "Dokker", 90, 5);
		vehiculos[3] = new Coche("444D", "Renault", "Yaris", 100, 4);
		vehiculos[4] = new Coche("555E", "BMW", "Serie X1", 120, 3);
		vehiculos[5] = new Coche("666F", "Fiat", "600", 90, 4);
		vehiculos[6] = new Coche("777G", "Hyundai", "Kona", 100, 5);

		vehiculos[7] = new Furgoneta("1234H", "Citroen", "Berlingo", 120, 10.2);
		vehiculos[8] = new Furgoneta("5678I", "Peugeot", "Rifter", 90, 9.5);
		vehiculos[9] = new Furgoneta("9101J", "Ford", "Transit", 85, 10);

		vehiculos[10] = new Moto("7878M", "BMW", "C 400 GT", 150, false);
		vehiculos[11] = new Moto("4659X", "Ducati", "Multistrada 1260", 140, true);

		// empresas

		empresas[0] = new Empresa("Empresa1 S.A.", "G1234H");
		empresas[1] = new Empresa("Empresa2 S.A.", "10293A");
		empresas[2] = new Empresa("Empresa3 S.A.", "L0983K");
		empresas[3] = new Empresa("Empresa4 S.A.", "B2136G");
		empresas[4] = new Empresa("Empresa5 S.A.", "G0987F");
		empresas[5] = new Empresa("Empresa6 S.A.", "P1238A");

		
		while (true) {
			System.out.println("DIA " + dia);
			
			int empresa = 0;
			do {
				String opcionS0;
				do {
					System.out.println("¿Qué empresa desea alquilar un vehiculo (1-6)?");
					opcionS0 = scLine.nextLine();
				} while (isNumericInt(opcionS0) == false);
				empresa = Integer.valueOf(opcionS0);
			} while ((empresa<-1 || empresa>6)|| empresa==0);
			
			if (empresa == -1) {
				listaVehiculos();
				pasarDia();
			} else {
				System.out.println(empresas[empresa - 1].getNombre());
				int vehiculo = 0;
				String opcionS;
				
				do {
					do {
						System.out.println("\n¿Qué vehiculo? (1-Coche 2-Furgoneta 3-Moto)");
						opcionS = scLine.nextLine();
					} while (isNumericInt(opcionS) == false);
					vehiculo = Integer.valueOf(opcionS);
				} while (vehiculo<1 || vehiculo>3);
				
				boolean continuar = true;// si hay vehiculos disponible se puede continuar con la pregunta de los dias
				int indice=-1;
				switch (vehiculo) {
				case 1:
					if (numCoches == 0) {
						System.out.println("Todos los coches estan alquilados.");
						continuar = false;
					} else {
						System.out.println("Un coche");
						indice=obtenerVehiculoDisp(0, 6);
						numCoches--;
					}
					break;
				case 2:
					if (numFurgos == 0) {
						System.out.println("Todos las furgonetas estan alquiladas.");
						continuar = false;
					} else {
						System.out.println("Una furgoneta");
						indice=obtenerVehiculoDisp(7, 9);
						numFurgos--;
					}

					break;
				case 3:
					if (numMotos == 0) {
						System.out.println("Todos las motos estan alquiladas.");
						continuar = false;
					} else {
						System.out.println("Una Moto");
						indice=obtenerVehiculoDisp(10, 11);
						numMotos--;
					}
					break;
				default:
					System.out.println("Introduce una opcion válida");
					continuar=false;
					break;
				}
				
				
				if (continuar == true) {
					int dias = 0;
					do {
						System.out.println("\n¿Durante cuantos días?");
						opcionS = scLine.nextLine();
					} while (isNumericInt(opcionS) == false);
					dias = Integer.valueOf(opcionS);
					
					for (int i = 0; i < alquileres.length; i++) {
						if (alquileres[i] == null) {
							alquileres[i] = new Alquiler(empresas[empresa - 1], vehiculos[indice], dias);
							break;
						}
					}
					System.out.println();
				} else {
					System.out.println("Puebe otro día o cambie de vehiculo\n");
				}

			}
		}
	}
	//-------------------------------------------------------------------------------------------------------------------
	public static int obtenerVehiculoDisp(int inicio, int fin) {
		
		int a=-1;
		for(int i=inicio;i<=fin;i++) {
			if(!vehiculos[i].isAlquilado()) {
				vehiculos[i].setAlquilado(true);
				a=i;
				break;
			}
		}
		return a;
	}
	
	//-------------------------------------------------------------------------------------------------------------------
	static public boolean isNumericInt(String valor) {
		try {
			Integer.valueOf(valor);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return false;
		}
		return true;
	}
	
	// ---------------------------------------------------------------------------------------------------------------

	public static void listaVehiculos() {
		System.out.println("VEHICULOS SIN ALQUILAR");
		int indice = 0;
		for (Vehiculo v : vehiculos) {
			if (v.isAlquilado() == false) {
				System.out.println("-" + v);
			}
		}

		System.out.println("\nVEHICULOS ALQUILADOS");
		for (int i = 0; i < alquileres.length; i++) {
			if (alquileres[i] != null) {
				System.out.println("-" + alquileres[i]);
			}
		}
	}
	
	//----------------------------------------------------------------------------------------------------------------
	public static void pasarDia() {
		dia++;
		for (int i = 0; i < alquileres.length; i++) {
			if (alquileres[i] != null) {
				alquileres[i].restarDias();
				if (alquileres[i].getDias() <0) {
					alquileres[i].getVehiculo().setAlquilado(false);
					if (alquileres[i].getVehiculo() instanceof Coche) {
						numCoches++;
					} else if (alquileres[i].getVehiculo() instanceof Furgoneta) {
						numFurgos++;
					} else if (alquileres[i].getVehiculo() instanceof Moto) {
						numMotos++;
					}
					alquileres[i] = null;
				}
			}
		}
		System.out.println();
	}

}
