package pack1;

public class Jugador {
	private String nombre;
	private Posicion posicion;

	public Jugador(String nombre) {
		super();
		this.nombre = nombre;
	}
	
	
	public Jugador(String nombre, Posicion posicion) {
		super();
		this.nombre = nombre;
		this.posicion = posicion;
	}


	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public Posicion getPosicion() {
		return posicion;
	}
	public void setPosicion(Posicion posicion) {
		this.posicion = posicion;
	}
	
	
	
}
