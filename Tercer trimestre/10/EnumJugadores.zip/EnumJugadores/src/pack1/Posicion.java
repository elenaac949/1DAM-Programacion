package pack1;

public enum Posicion {
	DEL("Delantero",80,20),
	MED("Centrocampista",50,50),
	DEF("Defensa",20,80);
	
	private String posicion;
	private int energiaAtaque;
	private int energiaDefensa;
	
	
	private Posicion(String posicion, int energiaAtaque, int energiaDefensa) {
		this.posicion = posicion;
		this.energiaAtaque = energiaAtaque;
		this.energiaDefensa = energiaDefensa;
	}
	
	public String getPosicion() {
		return posicion;
	}
	public void setPosicion(String posicion) {
		this.posicion = posicion;
	}
	public int getEnergiaAtaque() {
		return energiaAtaque;
	}
	public void setEnergiaAtaque(int energiaAtaque) {
		this.energiaAtaque = energiaAtaque;
	}
	public int getEnergiaDefensa() {
		return energiaDefensa;
	}
	public void setEnergiaDefensa(int energiaDefensa) {
		this.energiaDefensa = energiaDefensa;
	}
	
	
}
