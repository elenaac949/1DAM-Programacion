package pack1;

import java.util.HashSet;
import java.util.Random;
import java.util.Scanner;

public class MainEnumJugadores {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		HashSet<Jugador> jugadores=new HashSet<Jugador>();
		
		Jugador j0=new Jugador("Elena Lete");
		Jugador j1=new Jugador("Ona Batlle");
		Jugador j2=new Jugador("Vicky Lopez");
		Jugador j3=new Jugador("Irene Paredes", Posicion.DEF);
		Jugador j4=new Jugador("Alexia Putellas", Posicion.MED);
		Jugador j5=new Jugador("Salma Paralluelo", Posicion.DEL);
		Jugador j6=new Jugador("Athenea del Castillo", Posicion.DEL);
		
		jugadores.add(j6);
		jugadores.add(j5);
		jugadores.add(j4);
		jugadores.add(j3);
		jugadores.add(j2);
		jugadores.add(j1);
		jugadores.add(j0);
		
		
		while(true) {
			for(Jugador jugador:jugadores) {
				System.out.println("\nPulse enter para obtener la posición de "+jugador.getNombre());
				sc.nextLine();
				if(jugador.getPosicion()==null) {
					Random r=new Random();
					Posicion posiciones[]=Posicion.values();
					int random=r.nextInt(posiciones.length);
					Posicion posAleatoria=posiciones[random];
					jugador.setPosicion(posAleatoria);
					System.out.println("Posicion de "+jugador.getNombre()+": "+jugador.getPosicion().getPosicion());
					System.out.println("Fuerza defensiva: "+jugador.getPosicion().getEnergiaDefensa());
					System.out.println("Fuerza de ataque: "+jugador.getPosicion().getEnergiaAtaque());
				}else {
					System.out.println(jugador.getNombre()+" ya tiene posición y es : "+jugador.getPosicion().getPosicion());
				}
				

			}
		}
		
		
	}

}



























