package pack1;
import java.time.*;
import java.time.format.*;
import java.time.temporal.ChronoUnit;
import java.util.*;
public class MainFechasHoras {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scLine= new  Scanner(System.in);
		Scanner sc= new  Scanner(System.in);
		
		LocalDateTime ldt= LocalDateTime.now();
		LocalDateTime ldtMod=LocalDateTime.now();

		System.out.println(ldt);
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/YYYY HH:mm:ss");
		System.out.println(ldt.format(formatter));
		
		
		
		while(true) {
			System.out.println("1.- Sumar tiempo\r\n"
					+ "2.- Restar tiempo\r\n");
			int opcion=0;
			String opcionS;
			do {
				System.out.println("Elija una opción");
				opcionS = scLine.nextLine();
			} while (isNumericInt(opcionS) == false);
			opcion= Integer.valueOf(opcionS);
			
			
			int unidad=0;
			System.out.println("1.-Minutos\r\n"
					+ "2.-Horas\r\n"
					+ "3.-Días\r\n"
					+ "4.-Meses\r\n"
					+ "5.-Años");
			do {
				System.out.println("Elija una opción");
				opcionS = scLine.nextLine();
			} while (isNumericInt(opcionS) == false);
			unidad= Integer.valueOf(opcionS);
			
			int minutos,horas,dias,meses,anios=0;
		
			switch(unidad) {
			case 1:
				if(opcion==1) {
					System.out.println("¿Minutos a sumar?");
					minutos=sc.nextInt();
					ldtMod=ldt.plusMinutes(minutos);

				}else if (opcion==2) {
					System.out.println("¿Minutos a restar?");
					minutos=sc.nextInt();
					ldtMod=ldt.minusMinutes(minutos);
				}
				break;
			case 2:
				if(opcion==1) {
					System.out.println("¿Horas a sumar?");
					horas=sc.nextInt();
					ldtMod=ldt.plusHours(horas);

				}else if (opcion==2) {
					System.out.println("¿Horas a restar?");
					horas=sc.nextInt();
					ldtMod=ldt.minusHours(horas);
				}
				
				break;
			case 3:
				if(opcion==1) {
					System.out.println("¿Días a sumar?");
					dias=sc.nextInt();
					ldtMod=ldt.plusDays(dias);

				}else if (opcion==2) {
					System.out.println("¿Días a restar?");
					dias=sc.nextInt();
					ldtMod=ldt.minusDays(dias);
				}
				break;
			case 4:
				if(opcion==1) {
					System.out.println("¿Meses a sumar?");
					meses=sc.nextInt();
					ldtMod=ldt.plusMonths(meses);

				}else if (opcion==2) {
					System.out.println("¿Meses a restar?");
					meses=sc.nextInt();
					ldtMod=ldt.minusMonths(meses);
				}
				break;
			case 5:
				if(opcion==1) {
					System.out.println("¿Años a sumar?");
					anios=sc.nextInt();
					ldtMod=ldt.plusYears(anios);

				}else if (opcion==2) {
					System.out.println("¿Años a restar?");
					anios=sc.nextInt();
					ldtMod=ldt.minusYears(anios);
				}
				break;
			}
			
			System.out.println("Fecha y hora modificada: "+ldtMod.format(formatter));
			System.out.println();
			
			System.out.println("Fecha y hora real: "+ldt.format(formatter));
			System.out.println();
			
			
			int horasDif=(int)ChronoUnit.HOURS.between(ldt, ldtMod);
			double minutosDif=(double)ChronoUnit.MINUTES.between(ldt, ldtMod);
			double minutosRestantes=(double)((minutosDif/60)-horasDif)*60;
			
			System.out.println("Horas de diferencia: "+Math.abs(horasDif));
			System.out.println("Minutos de diferencia: "+Math.abs((int)minutosDif));
			System.out.println("Tiempo de diferencia: "+Math.abs(horasDif)+" horas + "+Math.abs((int)Math.round(minutosRestantes))+" minutos");
			
			System.out.println();
			
			
		}
	}


	static public boolean isNumericInt(String valor) {
		try {
			Integer.valueOf(valor);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return false;
		}
		return true;
	}
	
	
}
