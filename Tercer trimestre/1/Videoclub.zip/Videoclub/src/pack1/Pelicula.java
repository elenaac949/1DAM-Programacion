package pack1;

public class Pelicula {
	private String titulo;
	private int codigo;
	private int precio;
	private String condicion;
	private int diasPrestamo;//maximo dia de prestamo
	private int dias=0;
	private static int num=10000;
	private boolean disponible=true;//true=si, false=no

	public Pelicula(String titulo, String condicion, int precio, int diasPrestamo) {
		super();
		this.titulo = titulo;
		this.condicion = condicion;
		this.precio = precio;
		this.diasPrestamo = diasPrestamo;
		this.setCodigo(num);
		this.disponible=disponible;

	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo =num;
		num++;
	}


	public int getPrecio() {
		return precio;
	}

	public void setPrecio(int precio) {
		this.precio = precio;
	}

	public String getCondicion() {
		return condicion;
	}

	public void setCondicion(String condicion) {
		this.condicion = condicion;
	}

	public int getDiasPrestamo() {
		return diasPrestamo;
	}

	public void setDiasPrestamo(int diasPrestamo) {
		this.diasPrestamo = diasPrestamo;
	}


	public static int getNum() {
		return num;
	}
	public static void setNum(int num) {
		Pelicula.num = num;
	}

	public boolean isDisponible() {
		return disponible;
	}

	public void setDisponible(boolean disponible) {
		this.disponible = disponible;
	}

	public int getDias() {
		return dias;
	}

	public void setDias(int dias) {
		this.dias = dias;
	}

	public void sumarDias() {
		this.dias+=1;
		if(disponible==false) {
			if(this.dias>=this.diasPrestamo) {
				this.setDisponible(true);
				this.setDias(0);
			}
		}
	}
		
	

	
	
	
	
	
	@Override
	public String toString() {
		return "Pelicula [Titulo=" + titulo + ", Categoría=" + condicion + ", Precio=" + precio + ", Péstamo(dias)=" + diasPrestamo +", Código=" + codigo+"]";
	}


	

	
	
	
	
	
	
	
	
}
