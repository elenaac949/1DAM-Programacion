package pack1;
import java.util.*;
public class MainVideoclub {

	static Scanner scInt=new Scanner (System.in);
	static Scanner scLine=new Scanner (System.in);
	static Scanner scd=new Scanner (System.in);
	
	static ArrayList<Pelicula> peliculas=new ArrayList();
	static ArrayList<Pelicula>peliculasAlquiladas=new ArrayList();
	static ArrayList<Pelicula>peliculasDisponibles=new ArrayList();
	static ArrayList<CD> cds=new ArrayList();
	
	static int dia=1;
	static double gananciasPel=0;
	static double gananciasCD=0;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		while(true) {
			System.out.println("MENÚ:DIA "+dia);
			System.out.println("1.-Introducir nuevo producto");
			System.out.println("2.-Eliminar producto");
			System.out.println("3.-Ver listado de películas");
			System.out.println("4.-Ver listado de CDs");
			System.out.println("5.-Alquilar película");
			System.out.println("6.-Vender disco");
			System.out.println("7.-Ver películas en alquiler");
			System.out.println("8.-Ver ganancias");
			System.out.println("9.-Pasar al día siguiente");
			int opcion=0;

			String opcionS;
			do {
				System.out.println("\nElija una opcion");
				opcionS = scLine.nextLine();
			} while (isNumericInt(opcionS) == false);
			opcion = Integer.valueOf(opcionS);
			
			switch(opcion) {
			case 1:
				nuevoProducto();
				break;
			case 2:
				eliminarProducto();
				break;
			case 3:
				listaPeliculas() ;
				break;
			case 4:
				listaCDs();
				break;
			case 5:
				alquilarPelicula();
				break;
			case 6:
				venderDisco();
				break;
			case 7:
				verAlquileres();
				break;
			case 8:
				ganancias();
				break;
			case 9:
				pasarDia();
				break;
			default:
				System.err.println("Elige una de las opciones mostradas\n");
				break;
			}
			
		}
		
	}
	
	
	//-------------------------------------------------------------------------------------------
	static public boolean isNumericInt(String valor) {
		try {
			Integer.valueOf(valor);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return false;
		}
		return true;
	}
	
	//------------------------------------------------------------------------------------------
	private static int excepcionMinMax(int elegir, int min, int max) {
		// TODO Auto-generated method stub
		boolean error = true;
		while (error) {
			error = false;
			try {
				Scanner scInt = new Scanner(System.in);
				elegir = scInt.nextInt();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println("\nNo has introducido un número");
				error = true;
			}
			if (!error && (elegir < min || elegir > max)) {
				error = true;
				System.out.println("Introduce un número dentro del rango (" + min + "-" + max + ")");
			}
		}
		return elegir;
	}
	//--------------------------------------------------------------------------------------------
	public static void nuevoProducto() {
		System.out.println("INTRODUCIR NUEVO PRODUCTO");
		System.out.println("1.-Nueva película");
		System.out.println("2.-Nuevo CD");
		int opcion=0;

		String opcionS;
		do {
			System.out.println("\nElija una opcion");
			opcionS = scLine.nextLine();
		} while (isNumericInt(opcionS) == false);
		opcion = Integer.valueOf(opcionS);
		
		switch(opcion) {
		case 1:
			nuevaPelicula();
			break;
		case 2:
			nuevoCD();
			break;
		default:
			System.out.println("Elija una de las opciones mostradas");
			break;
		}
	}
	//-----------------------------------------------------------------------------------------------
	public static void nuevaPelicula() {
		System.out.println("DATOS PELICULA");
		System.out.println("Titulo:");
		String titulo=scLine.nextLine();
		System.out.println("Condición?:");
		System.out.println("-Novedades: N");
		System.out.println("-Semi-nuevas: S");
		System.out.println("-Antiguas: A");
		String respuesta=scLine.nextLine();
		String condicion="";
		int precio=0;
		int dias=0;
		
		if(respuesta.equalsIgnoreCase("n")) {
			condicion="Novedades";
			precio=3;
			dias=1;
		}
		else if(respuesta.equalsIgnoreCase("s")) {
			condicion="Semi-nuevas";
			precio=2;
			dias=2;
		}
		else if(respuesta.equalsIgnoreCase("a")) {
			condicion="Antiguas";
			precio=1;
			dias=4;
		}

		System.out.println("Cantidad que quieres adquirir");
		
		int cantidad=scInt.nextInt();

		for (int i=0;i<cantidad;i++) {
			Pelicula p=new Pelicula(titulo, condicion, precio, dias);
			peliculas.add(p);
		}
		System.out.println();
	}
	
	//------------------------------------------------------------------------------------------
	public static void nuevoCD() {
		System.out.println("DATOS CD");
		System.out.println("Titulo: ");
		String titulo=scLine.nextLine();
		
		System.out.println("Autor:");
		String autor=scLine.nextLine();
		
		System.out.println("Precio de venta: ");
		double precio=scInt.nextDouble();
		

		System.out.println("Cantidad?");
		int cantidad=scInt.nextInt();
		
		for (int i=0;i<cantidad;i++) {
			CD c =new CD(titulo, autor, precio);
			cds.add(c);
		}
	}
	
	//------------------------------------------------------------------------------------------
	public static void listaPeliculas() {
		System.out.println("LISTADO DE PELICULAS");
		for (int i=0;i<peliculas.size();i++) {
			System.out.println(peliculas.get(i));
		}
		System.out.println();
	}
	
	//------------------------------------------------------------------------------------------
	public static void listaCDs() {
		System.out.println("LISTADO DE CDs");
		for (int i=0;i<cds.size();i++) {
			System.out.println(cds.get(i));
		}
		System.out.println();
	}
	
	//-------------------------------------------------------------------------------------------
	public static void eliminarProducto() {
		System.out.println("ELIMINAR PRODUCTO");
		int indice=0;
		for (int i=0;i<peliculas.size();i++) {
			System.out.println(indice++ +".- Pelicula: "+peliculas.get(i).getTitulo()+" Codigo: "+peliculas.get(i).getCodigo());
		}
		for (int i=0;i<cds.size();i++) {
			System.out.println(indice++ +".- CDs: "+ cds.get(i).getTitulo()+" Código: "+cds.get(i).getCodigo());
		}
		System.out.println("Introduce el número del producto que quiere eliminar");
		
		int num=scInt.nextInt();
		
		if (num>=0 && num<(peliculas.size()+cds.size())) {
			if(num<=peliculas.size()) {
				peliculas.remove(num);
				System.out.println("Pelicula eliminada correctamente");
			}
			else {
				cds.remove(num-peliculas.size());
				System.out.println("CD eliminado correctamente");
			}
		}else {
			System.out.println("Ese producto no está en la lista");
		}
		
		System.out.println();
	}
	
	
	//-----------------------------------------------------------------------------------------
	
	public static void alquilarPelicula() {
		System.out.println("ALQUILER DE PELICULAS");
		if(peliculas.size()==0) {
			System.out.println("No hay peliculas para alquilar");
		}else {
			int  indice=0;
			for (int i=0;i<peliculas.size();i++) {
				if(peliculas.get(i).isDisponible()==true) {
					System.out.println(indice++ +".- "+peliculas.get(i));
				}
			}
			int num =0;
			do {
				System.out.println("\nIntroduce el número de la pelicula que quieras alquilar");
				num=scInt.nextInt();
				for (int i=0;i<peliculas.size();i++) {
					if(peliculas.get(i).isDisponible()==true && i==num) {
						gananciasPel+=peliculas.get(num).getPrecio();
						System.out.println("La película "+peliculas.get(num).getTitulo()+ " ha sido alquilada por "+peliculas.get(num).getDiasPrestamo()+" dias");
						peliculas.get(num).setDisponible(false);
					}
				}
			}while(num<0 || num>=indice);
			System.out.println();
		}

	}
	//------------------------------------------------------------------------------------------
	public static void venderDisco() {
		System.out.println("VENTA DE DISCOS");
		if(cds.size()==0) {
			System.out.println("No hay discos para vender.");
		}else {
			int indice=0;
			for (int i=0;i<cds.size();i++) {
				System.out.println(indice++ + ".- Titulo: "+cds.get(i).getTitulo()+" /Autor: "+cds.get(i).getAutor());
			}
			int num=0;
			do {
				System.out.println("Elige el número de disco que quieres vender");
				num=scInt.nextInt();
			}while(num<0 || num>cds.size());
			
			System.out.println("El disoc "+cds.get(num).getTitulo()+" de "+cds.get(num).getAutor()+" ha sido vendido por "+cds.get(num).getPrecio()+" euros");
			gananciasCD+=cds.get(num).getPrecio();
			cds.remove(num);	
		}
	}
	//-----------------------------------------------------------------------------------------------
	
	public static void verAlquileres() {
		System.out.println("LISTA DE PELICULAS EN ALQUILER\n");
		int contador =0;
		
		for (int i=0;i<peliculas.size();i++) {
			if(peliculas.get(i).isDisponible()==true) {
				contador++;
			}
		}
		if(contador==peliculas.size()) {
			System.out.println("No hay peliculas en alquiler");
		}else {
			int  indice=0;
			for (int i=0;i<peliculas.size();i++) {
				if(peliculas.get(i).isDisponible()==false) {
					System.out.println(indice++ +".- "+peliculas.get(i));
				}
			}
		}
		System.out.println();
	}
	
	//------------------------------------------------------------------------------------------------
	
	public static void ganancias() {
		System.out.println("GANANCIAS\n");
		System.out.println("Ganancias de las peliculas: "+gananciasPel+" euros");
		System.out.println("Gnancias de los discos: "+gananciasCD+" euros");
		double total=gananciasPel+gananciasCD;
		System.out.println("\nGanancias totales: "+total+" euros\n");
	}
	
	//------------------------------------------------------------------------------------------------
	
	public static void pasarDia() {
		System.out.println("¿Desea pasar al día siguiente (s/n)?");
		String respuesta=scLine.nextLine();
		respuesta=respuesta.trim();
		if(respuesta.equalsIgnoreCase("s")) {
			dia++;
			sumarDiaAlquiler();
		}
	}
	
	public static void sumarDiaAlquiler() {
		for (int i=0;i<peliculas.size();i++) {
			if(peliculas.get(i).isDisponible()==false) {
				peliculas.get(i).sumarDias();
			}
		}
	}
	
	
	//-----------------------------------------------------------------------------------------------
	
	
	
	
	
	
}
