package pack1;

public class CD {
	
	private String titulo;
	private int codigo;
	private double precio;
	private String autor;
	private static int num=20000;
	private boolean disponible=true;//true=si,false=no

	

	public CD(String titulo, String autor, double precio) {
		super();
		this.titulo = titulo;
		this.autor = autor;
		this.precio = precio;
		this.setCodigo(num);
	
	}
	
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = num;
		num++;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}

	
	public static int getNum() {
		return num;
	}

	public static void setNum(int num) {
		CD.num = num;
	}

	public boolean isDisponible() {
		return disponible;
	}

	public void setDisponible(boolean disponible) {
		this.disponible = disponible;
	}


	


	@Override
	public String toString() {
		return "CD [Titulo=" + titulo + ", Autor=" + autor + ", Precio=" + precio +", Código=" + codigo+"]";
	}
	
	
	
}
