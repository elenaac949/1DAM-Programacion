package prueba1;

public class Coche extends Vehiculo{
	private int npuertas;

	
	public Coche(String matricula, String marca, String modelo, int caballos, int npuertas) {
		super(matricula, marca, modelo, caballos);
		this.npuertas = npuertas;
		this.setPrecio(105.8);
	}

	
	public int getNpuertas() {
		return npuertas;
	}

	public void setNpuertas(int npuertas) {
		this.npuertas = npuertas;
	}
	
	@Override
	public String toString() {
		return "Coche "+ this.getMarca()+" "+this.getModelo()+" "+this.getMatricula();
	}
	
}
