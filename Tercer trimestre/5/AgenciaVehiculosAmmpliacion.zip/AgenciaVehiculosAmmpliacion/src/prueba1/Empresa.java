package prueba1;
import java.util.*;
public class Empresa {
	private String nombre;
	private String cif;
	private ArrayList<Vehiculo> vehiculosAlquilados;

	
	public Empresa(String nombre, String cif) {
		super();
		this.nombre = nombre;
		this.cif = cif;
		this.vehiculosAlquilados=new ArrayList();
	}
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCif() {
		return cif;
	}
	public void setCif(String cif) {
		this.cif = cif;
	}

	public ArrayList<Vehiculo> getVehiculosAlquilados() {
		return vehiculosAlquilados;
	}

	public void setVehiculosAlquilados(ArrayList<Vehiculo> vehiculosAlquilados) {
		this.vehiculosAlquilados = vehiculosAlquilados;
	}
	
	
	//-----------------------------------------------------------------------------------
	public void alquilarVehiculo(Vehiculo v) {
		vehiculosAlquilados.add(v);
	}
	
	public void devolverVehiculo(Vehiculo v) {
		vehiculosAlquilados.remove(v);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
