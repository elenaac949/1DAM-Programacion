package prueba1;

public class Moto extends Vehiculo{
	private boolean portacascos;//true=si,false=no

	public Moto(String matricula, String marca, String modelo, int caballos, boolean portacascos) {
		super(matricula, marca, modelo, caballos);
		this.portacascos = portacascos;
		this.setPrecio(65);
	}

	public boolean isPortacascos() {
		return portacascos;
	}

	public void setPortacascos(boolean portacascos) {
		this.portacascos = portacascos;
	}
	
	@Override
	public String toString() {
		return "Moto "+ this.getMarca()+" "+this.getModelo()+" "+this.getMatricula();
	}
	
}
