package prueba1;

public class Vehiculo {
	private String matricula;
	private String marca;
	private String modelo;
	private int caballos;
	private boolean alquilado;//true=si,false=no
	private int diasAlquiler;
	private double precio;// euros al día
	
	
	
	public Vehiculo(String matricula, String marca, String modelo, int caballos) {
		super();
		this.matricula = matricula;
		this.marca = marca;
		this.modelo = modelo;
		this.caballos = caballos;
		this.alquilado=false;
		this.diasAlquiler=diasAlquiler;
		this.precio=precio;
	}
	
	
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public int getCaballos() {
		return caballos;
	}
	public void setCaballos(int caballos) {
		this.caballos = caballos;
	}

	public boolean isAlquilado() {
		return alquilado;
	}
	public void setAlquilado(boolean alquilado) {
		this.alquilado = alquilado;
	}
	
	public int getDiasAlquiler() {
		return diasAlquiler;
	}
	public void setDiasAlquiler(int diasAlquiler) {
		this.diasAlquiler = diasAlquiler;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public void restarDias() {
		this.diasAlquiler-=1;
	}
	
	
	
	
	@Override
	public String toString() {
		return "Vehiculo "+ this.marca+" "+this.modelo+" "+this.matricula;
	}
	
	
}
