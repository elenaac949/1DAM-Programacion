package prueba1;
import java.util.*;
public class MainAgencia {

	static Scanner sc=new Scanner(System.in);
	static Scanner scLine=new Scanner(System.in);
	static int dia=1;
	
	static ArrayList<Vehiculo> vehiculos=new ArrayList<>();
	static ArrayList<Vehiculo> vDisponibles=new ArrayList();
	static ArrayList<Vehiculo> vAlquilados=new ArrayList();
	static ArrayList<Empresa> empresas=new ArrayList();

	static double gananciasTot=0;
	static double gananciasCoche=0;
	static double gananciasMoto=0;
	static double gananciasFurgo=0;
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//vehiculos
		
		Vehiculo c1=new Coche("111A", "Toyota", "Yaris",100, 5);
		Vehiculo c2=new Coche("222B", "Cupra", "Terramar",100, 4);
		Vehiculo c3=new Coche("333C", "Dacia", "Dokker",90, 5);
		Vehiculo c4=new Coche("444D", "Renault", "Yaris",100, 4);
		Vehiculo c5=new Coche("555E", "BMW", "Serie X1",120, 3);
		Vehiculo c6=new Coche("666F", "Fiat", "600",90, 4);
		Vehiculo c7=new Coche("777G", "Hyundai", "Kona",100, 5);
		Vehiculo f1=new Furgoneta("1234H", "Citroen", "Berlingo", 120, 10.2);
		Vehiculo f2=new Furgoneta("5678I", "Peugeot", "Rifter", 90, 9.5);
		Vehiculo f3=new Furgoneta("9101J", "Ford", "Transit", 85, 10);
		Vehiculo m1=new Moto("7878M", "BMW", "C 400 GT", 150, false);
		Vehiculo m2=new Moto("4659X", "Ducati", "Multistrada 1260", 140, true);
		
		//añadir vehiculos
		vDisponibles.add(c1);
		vDisponibles.add(c2);
		vDisponibles.add(c3);
		vDisponibles.add(c4);
		vDisponibles.add(c5);
		vDisponibles.add(c6);
		vDisponibles.add(c7);
		vDisponibles.add(f1);
		vDisponibles.add(f2);
		vDisponibles.add(f3);
		vDisponibles.add(m1);
		vDisponibles.add(m2);
		
		vehiculos.add(c1);
		vehiculos.add(c2);
		vehiculos.add(c3);
		vehiculos.add(c4);
		vehiculos.add(c5);
		vehiculos.add(c6);
		vehiculos.add(c7);
		vehiculos.add(f1);
		vehiculos.add(f2);
		vehiculos.add(f3);
		vehiculos.add(m1);
		vehiculos.add(m2);
		
		//empresas

		Empresa e1=new Empresa("Empresa1 S.A.","G1234H");
		Empresa e2=new Empresa("Empresa2 S.A.","10293A");
		Empresa e3=new Empresa("Empresa3 S.A.","L0983K");
		Empresa e4=new Empresa("Empresa4 S.A.","B2136G");
		Empresa e5=new Empresa("Empresa5 S.A.","G0987F");
		Empresa e6=new Empresa("Empresa6 S.A.","P1238A");
		
		empresas.add(e1);
		empresas.add(e2);
		empresas.add(e3);
		empresas.add(e4);
		empresas.add(e5);
		empresas.add(e6);
		
		boolean salir=false;
		while(!salir) {
			System.out.println("DIA "+dia);
			int numEm=0;
			String opcionS="";
			do {
				do {
					System.out.println("¿Qué empresa desea alquilar un vehiculo? (1-6).");
					System.out.println("Pulse -1 para ver el informe y ganancias");
					System.out.println("Pulse -3 para ver el listado de empresas y alquileres");
					System.out.println("Pulse -4 para devolver un vehiculo");
					opcionS = scLine.nextLine();
				} while (isNumericInt(opcionS) == false);
				numEm = Integer.valueOf(opcionS);
			} while ((numEm<-4 || numEm>6)|| numEm==0|| numEm==-2);
			
			if(numEm==-1) {
				listaNoAlquilados() ;
				listaAlquilados();
				ganancias();
				pasarDia();
				
			}else if(numEm==-3){
				alquileresEmpresas();
			}else if(numEm==-4) {
				devolucionesGeneral() ;
			}else {
				alquiler(numEm);
			}
		}	
	}
	
	//-----------------------------------------------------------------------------------
	static public boolean isNumericInt(String valor) {
		try {
			Integer.valueOf(valor);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return false;
		}
		return true;
	}
	//-----------------------------------------------------------------------------------
	public static void alquileresEmpresas() {
		System.out.println("ALQUILERES DE CADA EMPRESA\n");
		String tipo="";
		String datos="";
		for (Empresa e:empresas) {
			if(e.getVehiculosAlquilados().size()>0) {
				System.out.println(e.getNombre()+" con CIF "+e.getCif()+" tiene: ");
				for(Vehiculo v:e.getVehiculosAlquilados()) {
					if(v instanceof Coche) {
						tipo="Coche";
					}else if(v instanceof Furgoneta) {
						tipo="Furgoneta";
					}else if(v instanceof Moto) {
						tipo="Moto";
					}
					datos=" "+v.getMarca()+" "+v.getModelo()+" "+v.getMatricula();
					System.out.println("-"+tipo+datos);
				}
			}else {
				System.out.println(e.getNombre()+" con CIF "+e.getCif()+" no tiene alquileres");
			}
		}
		System.out.println();
	}
	

	//-----------------------------------------------------------------------------------
	public static void alquiler(int numEmpresa) {
		if(vDisponibles.size()>0) {
			double precio=0;
			double ganancias=0;
			System.out.println(empresas.get(numEmpresa-1).getNombre());
			System.out.println("\nVehiculos disponibles");
			int indice=0;
			for(Vehiculo v:vDisponibles) {
				System.out.println(indice+".-"+v);
				indice++;
			}
			int numVehiculo=0;//num de vehiculo
			String opcionS="";
			do {
				do {
					System.out.println("\n¿Qué vehículo se quiere alquilar?");
					opcionS = scLine.nextLine();
				} while (isNumericInt(opcionS) == false);
				numVehiculo = Integer.valueOf(opcionS);
			} while (numVehiculo<0 || numVehiculo>vDisponibles.size()-1);
			int dias=0;
			do {
				System.out.println("¿Durante cuantos días lo va a alquilar?");
				opcionS = scLine.nextLine();
			} while (isNumericInt(opcionS) == false);
			dias= Integer.valueOf(opcionS);
			
			//ganancias
			precio=vDisponibles.get(numVehiculo).getPrecio();
			ganancias=precio*dias;
			ganancias=Math.round(ganancias*100.00)/100.00;
			sumarGanancias(vDisponibles.get(numVehiculo), ganancias);
			
			//demas gestiones
			vDisponibles.get(numVehiculo).setDiasAlquiler(dias);
			//añadirlo a la lsita de la empresa
			empresas.get(numEmpresa-1).alquilarVehiculo(vDisponibles.get(numVehiculo));
			//ponerlo como alquilado
			vDisponibles.get(numVehiculo).setAlquilado(true);
			//añadir a vehiculos alquilados
			vAlquilados.add(vDisponibles.get(numVehiculo));
			//quitar de disponibles
			vDisponibles.remove(numVehiculo);
		}else {
			System.out.println("No hay vehiculos disponibles");
		}
	}
	
	//--------------------------------------------------------------------------------
	public static void listaVehiculos() {
		if (vDisponibles.size()>0) {
			int contador=0;
			for (Vehiculo v : vDisponibles) {
				System.out.println(contador+".-"+v);
				contador++;
			}
		}else {
			System.out.println("No hay vehículos disponibles");
		}
		System.out.println();
	}	

	//--------------------------------------------------------------------------------
	public static void sumarGanancias(Vehiculo v,double ganancias) {
		if(v instanceof Coche) {
			gananciasCoche+=ganancias;
		}else if(v instanceof Furgoneta) {
			gananciasFurgo+=ganancias;
		}else if(v instanceof Moto) {
			gananciasMoto+=ganancias;
		}
		gananciasTot+=ganancias;
	}
	
	//-----------------------------------------------------------------------------------
	public static void listaNoAlquilados() {
		System.out.println("VEHICULOS SIN ALQUILAR");
		if (vDisponibles.size()>0) {
			for (Vehiculo v : vDisponibles) {
				System.out.println(v);
			}
		}else {
			System.out.println("No hay vehículos disponibles");
		}
		System.out.println();
	}
	//-----------------------------------------------------------------------------------
	public static void listaAlquilados() {
		System.out.println("VEHICULOS ALQUILADOS");
		if (vAlquilados.size()>0) {
			for (Vehiculo v : vAlquilados) {
				System.out.println(v + " " + v.getDiasAlquiler() + " dias");
			} 
		}else {
			System.out.println("No hay vehiculos alquilados");
		}
		System.out.println();
	}
	//----------------------------------------------------------------------------------
	public static void ganancias() {
		System.out.println("\nGANANCIAS ");
		System.out.println("Ganancias totales de la agencia: "+gananciasTot+" euros");
		System.out.println("Ganancias coches: "+gananciasCoche+" euros");
		System.out.println("Ganancias furgonetas: "+gananciasFurgo+" euros");
		System.out.println("Ganancias motos: "+gananciasMoto+" euros");
	}
	//-----------------------------------------------------------------------------------
	public static void pasarDia() {
		for (Vehiculo v:vehiculos) {
			if(v.isAlquilado()==true) {
				if(v.getDiasAlquiler()==0) {
					vAlquilados.remove(v);
					vDisponibles.add(v);
					for(Empresa e:empresas) {
						e.devolverVehiculo(v);
					}
					v.setAlquilado(false);
				}
			}
		}
		//restar dias
		for (Vehiculo v:vehiculos) {
			if(v.isAlquilado()==true) {
				v.restarDias();
			}
		}
		dia++;
		System.out.println();
	}

	//----------------------------------------------------------------------------------
	public static void devolucionesGeneral() {
		boolean salir=false;
		String respuesta,opcionS="";
		while(!salir) {
			System.out.println("DEVOLUCIONES");
			int indice=0;
			int diasRestantes=0;
			double precioDia=0;
			double perdidas=0;
			if (vAlquilados.size()>0) {
				System.out.println("Vehiculos alquilados");
				for (Vehiculo v : vAlquilados) {
					System.out.println(indice+".-"+v + " " + v.getDiasAlquiler() + " dias");
					indice++;
				} 
				int num=0;//num de vehiculo
				do {
					System.out.println("¿Qué vehículo se quiere devolver?");
					opcionS = scLine.nextLine();
				} while (isNumericInt(opcionS) == false);
				num= Integer.valueOf(opcionS);
				do {
					//calcular el dinero que se devuelve al cliente
					diasRestantes=vAlquilados.get(num).getDiasAlquiler();
					precioDia=vAlquilados.get(num).getPrecio();
					perdidas=diasRestantes*precioDia;
					restarGanancias(vAlquilados.get(num), perdidas);
					//eliminarlo del array de vehiculos alquilados por esa empresa
					for(Empresa e:empresas) {
						for(int i=e.getVehiculosAlquilados().size()-1;i>=0;i--) {
							if(e.getVehiculosAlquilados().get(i)==vAlquilados.get(num)) {
								e.devolverVehiculo(e.getVehiculosAlquilados().get(i));;
							}
						}
					}
					//resetear los dias de alquiler y ponerlos en no alquilados
					vAlquilados.get(num).setAlquilado(false);
					vAlquilados.get(num).setDiasAlquiler(0);
					
					//añadirlo a la lista de vehiculos en general y disponibles
//					vehiculos.add(vAlquilados.get(num));
					vDisponibles.add(vAlquilados.get(num));
					
					//eliminarlo de la lista de vehiculos alquilados
					vAlquilados.remove(num);
					System.out.println("Vehiculo devuelto con éxito.");
					System.out.println("¿Desea devolver otro vehiculo? s/n");
					respuesta=scLine.nextLine();
					if(respuesta.equalsIgnoreCase("n")) {
						pasarDia();
						salir=true;
					}else {
						break;
					}
				}while(num<0 || num>vAlquilados.size());
			}else {
				System.out.println("No hay vehiculos alquilados. Vuelva otro dia.");
				salir=true;
			}	
		}
		System.out.println();
	}
	//--------------------------------------------------------------------------------------------------
	public static void restarGanancias(Vehiculo v,double perdidas) {
		if(v instanceof Coche) {
			gananciasCoche-=perdidas;
		}else if(v instanceof Furgoneta) {
			gananciasFurgo-=perdidas;
		}else if(v instanceof Moto) {
			gananciasMoto-=perdidas;
		}
		gananciasTot-=perdidas;
	}
}




















