package pack1;

public class Mozo extends Empleado implements Cobros{

	public Mozo(String nombre, String apellido, String dni, int ant) {
		super(nombre, apellido, dni, ant);
		// TODO Auto-generated constructor stub
		this.setBruto(1200);
		this.sueldoNeto();
		this.indemnizacion();
	}

	@Override
	public void sueldoNeto() {
		double bruto=this.getBruto();
		this.setNeto(bruto*0.85);
	}

	@Override
	public void indemnizacion() {
		if(this.getAnt()<90) {
			this.setIndemnizacion(0);
		}else {
			this.setIndemnizacion(getBruto()*3);
		}
	}

	@Override
	public void subidaSueldo() {
		double sueldo=this.getBruto();
		double subida=(sueldo*0.05);
		sueldo+=subida;
		this.setBruto(sueldo);
		sueldoNeto();
		indemnizacion();
	}

	@Override
	public String toString() {
		return this.getNombre()+" "+this.getApellido()+" "+this.getDni()+" Mozo ";
	}
}







