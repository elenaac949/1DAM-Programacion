package pack1;

public class Jefe extends Empleado implements Cobros{

	private int categoria;
	public Jefe(String nombre, String apellido, String dni, int ant,int categoria) {
		super(nombre, apellido, dni, ant);
		// TODO Auto-generated constructor stub
		this.categoria=categoria;
		this.setBruto(1700+(50*categoria));
		this.sueldoNeto();
		this.indemnizacion();
	}
	
	public int getCategoria() {
		return categoria;
	}
	public void setCategoria(int categoria) {
		this.categoria = categoria;
	}

	@Override
	public void sueldoNeto() {
		// TODO Auto-generated method stub
		this.setNeto(getBruto()*0.80);
	}

	@Override
	public void indemnizacion() {
		double indem=0;
		if(this.getAnt()<90) {
			this.setIndemnizacion(0);
		}else {
			indem=this.getBruto()*3;
			indem+=(400*categoria);
			this.setIndemnizacion(indem);
		}
	}

	@Override
	public void subidaSueldo() {
		double sueldo=this.getBruto();
		double subida=(sueldo*0.1);
		sueldo+=subida;
		this.setBruto(sueldo);
		sueldoNeto();
		indemnizacion();
		
	}
	
	@Override
	public String toString() {
		return this.getNombre()+" "+this.getApellido()+" "+this.getDni()+" Categoría "+this.getCategoria()+" Jefe de Seccion ";
	}
	
	
	

}
