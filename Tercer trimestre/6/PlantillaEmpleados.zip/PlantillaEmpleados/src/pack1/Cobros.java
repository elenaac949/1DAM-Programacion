package pack1;

public interface Cobros {
	public void sueldoNeto() ;
	public void indemnizacion();
	public void subidaSueldo();
	
}
