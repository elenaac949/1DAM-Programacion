package pack1;
import java.util.*;
public class Main {

	static Scanner sc=new Scanner(System.in);
	static Scanner scLine=new Scanner(System.in);
	
	static ArrayList<Empleado>empleados=new ArrayList<>();
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Empleado m1=new Mozo("Maria", "García", "123456789K", 20);
		Empleado m2=new Mozo("Juan", "Lopez", "87636409T", 91);
																//categoria
		Empleado j1=new Jefe("Raul", "Alonso", "715208369I", 240, 3);
		Empleado j2=new Jefe("Mario", "Navarro", "128403769H", 123, 2);
		Empleado j3=new Jefe("Raul", "Gomez", "82725390H", 12, 1);
		
		Empleado d1=new Directivo("Blanca", "Torres", "4273846337L", 667, true);
		Empleado d2=new Directivo("Beatriz", "Valverde", "197263420M", 100, false);
		
		empleados.add(m1);
		empleados.add(m2);
		empleados.add(j1);
		empleados.add(j2);
		empleados.add(j3);
		empleados.add(d1);
		empleados.add(d2);
		
		while(true) {
			System.out.println("1.-Introducir trabajador.");
			System.out.println("2.-Eliminar trabajador.");
			System.out.println("3.-Subir sueldo trabajador.");
			System.out.println("4.-Sueldo neto,despido y antigüedad.");
			System.out.println("5.-Ordenar listas.");
			System.out.println("6.-Sueldo Bruto/Neto/Indemnización");
			//este último lo he puesto para poder comparar los sueldos 
			int opcion=0;
			String opcionS;
			do {
				System.out.println("Elija una opción");
				opcionS = scLine.nextLine();
			} while (isNumericInt(opcionS) == false);
			opcion= Integer.valueOf(opcionS);
			switch(opcion) {
				case 1:
					nuevoTrabajador();
					break;
				case 2:
					eliminarTrabajador();
					break;
				case 3:
					subirSueldo();
					break;
				case 4:
					varios();
					break;
				case 5:
					ordenarListas();
					break;
				case 6:
					lista();
					System.out.println();
					break;
			}
		}
		
	}
	//--------------------------------------------------------------------------------------
	static public boolean isNumericInt(String valor) {
		try {
			Integer.valueOf(valor);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return false;
		}
		return true;
	}
	
	//--------------------------------------------------------------------------------------
	public static void nuevoTrabajador() {
		String nombre,apellido,dni="";
		int puesto,ant, cat=0;
		String opcionS;
		System.out.println("\nINTRODUCIR NUEVO TRABAJADOR");
		do {
			do {
				System.out.println("¿Para que puesto? (1-Mozo,2-Jefe de Sección,3-Directivo)");
				opcionS = scLine.nextLine();
			} while (isNumericInt(opcionS) == false);
			puesto= Integer.valueOf(opcionS);
		} while (puesto<1|| puesto>3);
		
		System.out.println("¿Nombre?");
		nombre=scLine.nextLine();
		
		System.out.println("¿Apellido?");
		apellido=scLine.nextLine();
		
		System.out.println("¿DNI?");
		dni=scLine.nextLine();
		
		do {
			System.out.println("¿Antiguedad?");
			opcionS = scLine.nextLine();
		} while (isNumericInt(opcionS) == false);
		ant= Integer.valueOf(opcionS);

		Empleado e = null;
		
		if(puesto==1) {
			e=new Mozo(nombre, apellido, dni, ant);
		}else if(puesto==2) {
			System.out.println("¿Categoría? (1,2 o 3)");
			cat=sc.nextInt();
			e=new Jefe(nombre, apellido, dni, ant, cat);
		}else if(puesto==3) {
			String respuesta;
			do {
				System.out.println("¿Está en el Consejo de Administración? (s/n)");
				respuesta = scLine.nextLine();
			} while (!respuesta.equalsIgnoreCase("s") || !respuesta.equalsIgnoreCase("n"));
			
			if(respuesta.equalsIgnoreCase("s")) {
				e=new Directivo(nombre, apellido, dni, ant, true);
			}else if(respuesta.equalsIgnoreCase("n")) {
				e=new Directivo(nombre, apellido, dni, ant, false);
			}
		}
		
		empleados.add(e);	
	}
	
	//---------------------------------------------------------------------------------------
	
	public static void eliminarTrabajador() {
		System.out.println("\nELIMINAR EMPLEADO");
		listaTrabajadores();
		int num=0;
		String opcionS;
		do {
			do {
				System.out.println("Seleccione el empleado que desea eliminar");
				opcionS = scLine.nextLine();
			} while (isNumericInt(opcionS) == false);
			num= Integer.valueOf(opcionS);
		} while (num<0||num>empleados.size()-1);
		empleados.remove(num);
		System.out.println();
	}
	//---------------------------------------------------------------------------------------
	public static void listaTrabajadores() {
		int indice=0;
		for(Empleado e:empleados) {
			System.out.println(indice+".-"+e);
			indice++;
		}
	}
	//---------------------------------------------------------------------------------------
	public static void subirSueldo() {
		System.out.println("\nSUBIR SUELDO A UN TRABAJADOR");
		listaTrabajadores();
		int num=0;
		String opcionS;
		do {
			do {
				System.out.println("Seleccione el empleado al que se le sube el sueldo");
				opcionS = scLine.nextLine();
			} while (isNumericInt(opcionS) == false);
			num= Integer.valueOf(opcionS);
		} while (num<0||num>empleados.size()-1);
		empleados.get(num).subidaSueldo();
	}
	//---------------------------------------------------------------------------------------
	public static void varios() {
		System.out.println("\nINFORMACIÓN");
		listaTrabajadores();
		int num=0;
		String opcionS;
		do {
			do {
				System.out.println("¿De qué empleado desea ver los datos?");
				opcionS = scLine.nextLine();
			} while (isNumericInt(opcionS) == false);
			num= Integer.valueOf(opcionS);
		} while (num<0||num>empleados.size()-1);
		System.out.println("\n"+empleados.get(num));
		System.out.println("Sueldo neto: "+empleados.get(num).getNeto()+" euros");
		System.out.println("Indemnización: "+empleados.get(num).getIndemnizacion()+" euros");
		System.out.println("Días de antiguedad: "+empleados.get(num).getAnt()+" dias");
		System.out.println();
	}
	//---------------------------------------------------------------------------------------
	public static void ordenarListas() {
		System.out.println("\nORDENAR LISTAS");
		System.out.println("1.-Por nombre y apellido.");
		System.out.println("2.-Por dias de antiguedad");
		System.out.println("3.-Por sueldo bruto.");
		
		int opcion=0;
		String opcionS;
		do {
			System.out.println("Elija una opción");
			opcionS = scLine.nextLine();
		} while (isNumericInt(opcionS) == false);
		opcion= Integer.valueOf(opcionS);
		switch(opcion) {
		case 1:
			Collections.sort(empleados, new OrdenarPorNombreYApellido());
			System.out.println("Lista de trabajadores ordenados alfabéticamente");
			listaTrabajadores();
			break;
		case 2:
			Collections.sort(empleados, new OrdenarPorAntiguedad());
			System.out.println("Lista de trabajadores ordenados por antiguedad");
			int indice=0;
			for(Empleado e:empleados) {
				System.out.println(indice+".-"+e.getNombre()+" "+e.getApellido()+", Días de antiguedad: "+e.getAnt()+" días");
				indice++;
			}
			break;
		case 3:
			Collections.sort(empleados, new OrdenarPorSueldoBruto());
			System.out.println("Lista de trabajadores ordenados por sueldo bruto");
			indice=0;
			for(Empleado e:empleados) {
				System.out.println(indice+".-"+e.getNombre()+" "+e.getApellido()+", Sueldo: "+e.getBruto()+" euros");
				indice++;
			}
			break;
		}

		System.out.println();
	}
	//---------------------------------------------------------------------------------------
	
	public static void lista() {
		int indice=0;
		for(Empleado e:empleados) {
			System.out.println(indice+".-"+e.getNombre()+" "+e.getApellido()+" Neto="+e.getNeto()+" Bruto="+e.getBruto()+" Indemnización="+e.getIndemnizacion());
			indice++;
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
