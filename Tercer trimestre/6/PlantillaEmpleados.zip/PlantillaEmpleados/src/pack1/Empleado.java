package pack1;

public class Empleado implements Cobros{
	private String nombre;
	private String apellido;
	private String dni;
	private int ant;//antiguedad
	
	private double bruto;
	private double neto;
	private double indemnizacion;
	
	public Empleado(String nombre, String apellido, String dni, int ant) {
		super();
		this.nombre = nombre;
		this.apellido = apellido;
		this.dni = dni;
		this.ant = ant;
		this.bruto=bruto;
		this.neto=neto;
		this.indemnizacion=indemnizacion;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public String getDni() {
		return dni;
	}
	public void setDni(String dni) {
		this.dni = dni;
	}
	public int getAnt() {
		return ant;
	}
	public void setAnt(int ant) {
		this.ant = ant;
	}
	public double getBruto() {
		return bruto;
	}
	public void setBruto(double bruto) {
		this.bruto = bruto;
	}
	public double getNeto() {
		return neto;
	}
	public void setNeto(double neto) {
		this.neto = neto;
	}
	public double getIndemnizacion() {
		return indemnizacion;
	}
	public void setIndemnizacion(double indemnizacion) {
		this.indemnizacion = indemnizacion;
	}
	
	
	@Override
	public String toString() {
		return "Empleado "+this.nombre+" "+this.apellido+" "+this.dni;
	}
	
	@Override
	public void sueldoNeto() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void indemnizacion() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void subidaSueldo() {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
	
	
	
	
	
	
	
}
