package pack1;
import java.util.*;
public class OrdenarPorNombreYApellido implements Comparator<Empleado>{

	@Override
	public int compare(Empleado o1, Empleado o2) {
		// TODO Auto-generated method stub
		int nombre= o1.getNombre().compareTo(o2.getNombre());
		if(nombre==0) {
			return o1.getApellido().compareTo(o2.getApellido());
		}else {
			return nombre;
		}
	}

}
