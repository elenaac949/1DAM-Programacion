package pack1;
import java.util.*;
public class OrdenarPorAntiguedad implements Comparator<Empleado>{

	@Override
	public int compare(Empleado o1, Empleado o2) {
		// TODO Auto-generated method stub
		return Double.compare(o1.getAnt(),o2.getAnt());
	}


}
