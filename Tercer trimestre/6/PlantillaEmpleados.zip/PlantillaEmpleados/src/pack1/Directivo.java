package pack1;

public class Directivo extends Empleado implements Cobros{

	private boolean enConsejo;//true=si,false=no
	
	public Directivo(String nombre, String apellido, String dni, int ant,boolean enConsejo) {
		super(nombre, apellido, dni, ant);
		// TODO Auto-generated constructor stub
		this.enConsejo=enConsejo;
		this.setBruto(4500);
		this.sueldoNeto();
		this.indemnizacion();
	}

	@Override
	public void sueldoNeto() {
		this.setNeto(getBruto()*0.7);
		if(this.enConsejo==true) {
			this.setNeto(getNeto()+200);
		}
	}

	@Override
	public void indemnizacion() {
		double indem=0;
		if(this.getAnt()<90) {
			this.setIndemnizacion(0);
		}else {
			indem=this.getBruto()*3;
			if(this.enConsejo==true) {
				indem+=15000;
			}else {
				indem+=5000;
			}
		}
		this.setIndemnizacion(indem);
	}

	@Override
	public void subidaSueldo() {
		double sueldo=this.getBruto();
		double subida=(sueldo*0.15);
		sueldo+=subida;
		this.setBruto(sueldo);
		sueldoNeto();
		indemnizacion();
	}
	
	@Override
	public String toString() {
		String datos=this.getNombre()+" "+this.getApellido()+" "+this.getDni()+" Directivo ";
		if(this.enConsejo==true) {
			datos=datos+"Miembro del Consejo";
		}else if(this.enConsejo==false) {
			datos=datos+"Normal";
		}
		return datos;
	}

}














