package pack1;
import java.util.*;
public class OrdenarPorSueldoBruto implements Comparator<Empleado>{

	@Override
	public int compare(Empleado o1, Empleado o2) {
		// TODO Auto-generated method stub
		return Double.compare(o1.getBruto(), o2.getBruto());
	}



}
