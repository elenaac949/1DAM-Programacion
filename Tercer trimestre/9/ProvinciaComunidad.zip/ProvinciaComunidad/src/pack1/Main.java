package pack1;
import java.util.*;
public class Main {
	static HashMap<String, String> pais=new HashMap<String, String>();
	//			provincia comunidad
	
	static Scanner sc=new Scanner(System.in);
	static Scanner scLine=new Scanner(System.in);
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		while(true) {
			System.out.println("1.- Introducir dato\r\n"
					+ "2.- Obtener dato\r\n"
					+ "3.- Listado\r\n");
			int opcion=0;
			String opcionS;
			do {
				System.out.println("Elija una opción(1-3)");
				opcionS = scLine.nextLine();
			} while (isNumericInt(opcionS) == false);
			opcion= Integer.valueOf(opcionS);
			switch(opcion) {
			case 1:
				introducirDato();
				break;
			case 2:
				obtenerDato();
				break;
			case 3:
				listado();
				break;
			}
		}
	}

	static public boolean isNumericInt(String valor) {
		try {
			Integer.valueOf(valor);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return false;
		}
		return true;
	}
	
	private static void listado() {
		// TODO Auto-generated method stub
		System.out.println("3.-Listado de provincias y Comunidades Autónomas");
		for (String provincia:pais.keySet()) {
			String comunidad=pais.get(provincia);
			System.out.println("Provincia: "+provincia+", Comunidad Autónoma: "+comunidad);
		}
		System.out.println();
	}


	private static void obtenerDato() {
		// TODO Auto-generated method stub
		//provincia es key
		
		System.out.println("2.-Obtener Dato");
		String provincia,comunidad=null;
		System.out.println("\nIntroduzca la provincia");
		provincia=sc.nextLine();
		comunidad=pais.get(provincia);
		System.out.println("La comunidad autónoma de "+provincia+" es "+comunidad);
		System.out.println();
	}


	private static void introducirDato() {
		// TODO Auto-generated method stub
		System.out.println("1.-Introducir dato");
		String provincia,comunidad=null;
		System.out.println("\nIntroduzca la provincia");
		provincia=scLine.nextLine();
		System.out.println("\nIntroduzca la Comunidad Autónoma");
		comunidad=scLine.nextLine();
		pais.put(provincia, comunidad);
	}

}



























