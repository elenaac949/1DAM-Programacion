package prueba2;

public class Tornillo{
	
	private boolean tamanio; //true=mediano, false=grande 
	private double precioCompra;
	private double precioVenta;
	
	public Tornillo(boolean tamanio) {
		super();
		this.tamanio=tamanio;
		if(tamanio==true) {
			this.precioCompra=1;
			this.precioVenta=6;
		}
		else {
			this.precioCompra=2;
			this.precioVenta=8;
		}
	}


	public boolean isTamanio() {
		return tamanio;
	}

	public void setTamanio(boolean tamanio) {
		this.tamanio = tamanio;
	}


	public double getPrecioCompra() {
		return precioCompra;
	}


	public void setPrecioCompra(double precioCompra) {
		this.precioCompra = precioCompra;
	}


	public double getPrecioVenta() {
		return precioVenta;
	}


	public void setPrecioVenta(double precioVenta) {
		this.precioVenta = precioVenta;
	}
	
	
	
}
