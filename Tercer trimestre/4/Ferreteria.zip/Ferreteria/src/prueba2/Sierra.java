package prueba2;

public class Sierra{

	private double precioCompra=10;
	private double precioVenta=20;

	
	public Sierra() {
		super();
		this.precioCompra=precioCompra;
		this.precioVenta=precioVenta;
	}
	
	
	
	
	public double getPrecioCompra() {
		return precioCompra;
	}
	public void setPrecioCompra(double precioCompra) {
		this.precioCompra = precioCompra;
	}
	public double getPrecioVenta() {
		return precioVenta;
	}
	public void setPrecioVenta(double precioVenta) {
		this.precioVenta = precioVenta;
	}

	
	
	
	
}
