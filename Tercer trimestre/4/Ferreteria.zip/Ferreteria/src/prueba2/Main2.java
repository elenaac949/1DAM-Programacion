package prueba2;
import java.util.*;


public class Main2 {

	static int dia=1;
	//-----------------------------------------------------
	static Scanner sc=new Scanner(System.in);
	static Scanner scLine=new Scanner(System.in);
	//stocks
	static ArrayList<Tornillo> tornillosMed=new ArrayList();
	static ArrayList<Tornillo> tornillosGrand=new ArrayList();
	static ArrayList<Sierra> sierras=new ArrayList();
	
	static double totalTornillos=0;
	static double totalSierras=0;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//menu
			while(true) {
				System.out.println("DIA "+dia);
				System.out.println("Menu");
				System.out.println("1.- Compras de articulos");
				System.out.println("2.- Ventas de artículos");
				System.out.println("3.- Cambio de día");
				System.out.println("4.- Compras por días");
				System.out.println("5.- Ventas por días");
				System.out.println("6.- Ver stocks");
				
				int opcion=0;
				String opcionS;
				do {
					System.out.println("\nElige una opción (1-5):");
					opcionS = scLine.nextLine();
				} while (isNumericInt(opcionS) == false);
				opcion = Integer.valueOf(opcionS);

				switch(opcion) {
				case 1:
					compras();
					break;
				case 2:
					ventas();
					break;
				case 3:
					cambioDia();
					break;
				case 4:
					resumenCompras();
					break;
				case 5:
					resumenVentas();
					break;
				default:
					break;
				}
			}
	}
	//--------------------------------------------------------------------------------------------------------
	
	static public boolean isNumericInt(String valor) {
		try {
			Integer.valueOf(valor);
		} catch (Exception e) {
			return false;
		}
		return true;
	}
	//-------------------------------------------------------------------------------------------------------
	public static void compras() {
		System.out.println("COMPRA DE ARTÍCULOS");
		System.out.println("1.- Tornillos medianos");
		System.out.println("2.- Tornillos grandes");
		System.out.println("3.- Sierras");
		int opcion=0;
		String opcionS;
		do {
			System.out.println("\nElige una opción (1-3):");
			opcionS = scLine.nextLine();
		} while (isNumericInt(opcionS) == false);
		opcion = Integer.valueOf(opcionS);
		
		switch(opcion) {
		case 1:
			compraTornillosMed();
			break;
		case 2:
			compraTornillosG();
			break;
		case 3:
			compraSierras();
			break;
		default:
			break;
		}
	}
	
	static double descuento=0.7;
	public static void compraTornillosMed() {
		int cantidad=0;
		String opcionS;
		do {
			System.out.println("¿Cuantos tornillos quieres comprar?");
			opcionS = scLine.nextLine();
		} while (isNumericInt(opcionS) == false);
		cantidad = Integer.valueOf(opcionS);
		
		boolean tamanio=true;
		double gastoCompra=0;
		cantidad=sc.nextInt();
		Tornillo t=new Tornillo(tamanio);
		if(dia==4 || dia==5) {//que son los dias 5 y 6
			gastoCompra= (cantidad*t.getPrecioCompra())-(cantidad*t.getPrecioCompra()*descuento);
			System.out.println("Se han comprado "+cantidad+" tornillos medianos por "+gastoCompra+" euros");
		}
		else {
			gastoCompra= cantidad*t.getPrecioCompra();
			System.out.println("Se han comprado "+cantidad+" tornillos medianos por "+gastoCompra+" euros");
		}
		totalTornillos-=gastoCompra;
		comprasXdia(cantidad, gastoCompra);
		
		for(int i=0;i<cantidad;i++) {
			tornillosMed.add(t);
		}
	}
	public static void compraTornillosG() {
		int cantidad=0;
		String opcionS;
		do {
			System.out.println("¿Cuantos tornillos quieres comprar?");
			opcionS = scLine.nextLine();
		} while (isNumericInt(opcionS) == false);
		cantidad = Integer.valueOf(opcionS);
		
		boolean tamanio=false;
		double gastoCompra=0;
		cantidad=sc.nextInt();

		Tornillo t=new Tornillo(tamanio);
		if(dia==5 || dia==6) {
			gastoCompra= (cantidad*t.getPrecioCompra())-(cantidad*t.getPrecioCompra()*descuento);
			System.out.println("Se han comprado "+cantidad+" tornillos medianos por "+gastoCompra+" euros");
		}
		else {
			gastoCompra= cantidad*t.getPrecioCompra();
			System.out.println("Se han comprado "+cantidad+" tornillos medianos por "+gastoCompra+" euros");
		}
		totalTornillos-=gastoCompra;
		comprasXdia(cantidad, gastoCompra);
		
		for(int i=0;i<cantidad;i++) {
			tornillosGrand.add(t);
		}
	}
	
	public static void compraSierras() {
		int cantidad=0;
		String opcionS;
		do {
			System.out.println("¿Cuantas sierras quieres comprar?");
			opcionS = scLine.nextLine();
		} while (isNumericInt(opcionS) == false);
		cantidad = Integer.valueOf(opcionS);
		boolean tipo=false;
		double gastoCompra=0;
		cantidad=sc.nextInt();
		Sierra s=new Sierra();
		gastoCompra=s.getPrecioCompra()*cantidad;
		
		totalSierras-=gastoCompra;
		comprasXdia(cantidad, gastoCompra);
		
		for(int i=0;i<cantidad;i++) {
			sierras.add(s);
		}
		System.out.println("Se han comprado "+cantidad+" sierras por "+gastoCompra+" euros");
	}

	
	//-------------------------------------------------------------------------------------------------------

	
	public static void ventas() {
		System.out.println("VENTA DE ARTÍCULOS");
		System.out.println("1.- Tornillos medianos "+tornillosMed.size()+" unidades");
		System.out.println("2.- Tornillos grandes "+tornillosGrand.size()+" unidades");
		System.out.println("3.- Sierras "+sierras.size()+" unidades");
		int opcion=0;
		String opcionS;
		do {
			System.out.println("\nElige una opción (1-3):");
			opcionS = scLine.nextLine();
		} while (isNumericInt(opcionS) == false);
		opcion = Integer.valueOf(opcionS);
		switch(opcion) {
		case 1:
			ventaTorMed() ;
			break;
		case 2:
			ventaTorGrand();
			break;
		case 3:
			ventaSierras();
			break;
		default:
			break;
		}
		
	}
	static double precioDesc=0.8;
	
	public static void ventaTorMed() {
		int cantidad=0;
		String opcionS;
		do {
			System.out.println("¿Cantidad?");
			opcionS = scLine.nextLine();
		} while (isNumericInt(opcionS) == false);
		cantidad = Integer.valueOf(opcionS);
		
		double gananciasVenta=0;
		
		cantidad=sc.nextInt();
		if(tornillosMed.size()!=0) {
			if(tornillosMed.size()>=10 && cantidad>=10) {
				gananciasVenta=cantidad*tornillosMed.get(cantidad).getPrecioVenta()*precioDesc;
			}else {
				gananciasVenta=cantidad*tornillosMed.get(cantidad).getPrecioVenta();
			}
			System.out.println("Ha vendido "+cantidad+" torillos medianos por "+gananciasVenta+" euros");
			totalTornillos+=gananciasVenta;
			ventasXdia(cantidad,gananciasVenta);
			
			for(int i=cantidad;i>0;i--) {
				tornillosMed.remove(tornillosMed.get(i));
			}
		}else {
			System.out.println("No hay tornillos medianos");
		}
		System.out.println();
		
		
		
	}
	public static void ventaTorGrand() {
		int cantidad=0;
		String opcionS;
		do {
			System.out.println("¿Cantidad?");
			opcionS = scLine.nextLine();
		} while (isNumericInt(opcionS) == false);
		cantidad = Integer.valueOf(opcionS);
		double gananciasVenta=0;
		
		cantidad=sc.nextInt();
		if(tornillosGrand.size()!=0) {
			if(tornillosGrand.size()>=10 && cantidad>=10) {
				gananciasVenta=cantidad*tornillosGrand.get(cantidad).getPrecioVenta()*precioDesc;
			}else {
				gananciasVenta=cantidad*tornillosGrand.get(cantidad).getPrecioVenta();
			}
			System.out.println("Ha vendido "+cantidad+" torillos grandes por "+gananciasVenta+" euros");
			totalTornillos+=gananciasVenta;
			ventasXdia(cantidad,gananciasVenta);
			for(int i=cantidad;i>0;i--) {
				tornillosGrand.remove(tornillosGrand.get(i));
			}
		}else {
			System.out.println("No hay tornillos grandes");
		}
		System.out.println();
	}
	public static void ventaSierras() {
		int cantidad=0;
		String opcionS;
		do {
			System.out.println("¿Cantidad?");
			opcionS = scLine.nextLine();
		} while (isNumericInt(opcionS) == false);
		cantidad = Integer.valueOf(opcionS);
		
		double gananciasVenta=0;
		cantidad=sc.nextInt();
		if(sierras.size()!=0) {
			System.out.println("Ha vendido "+cantidad+" sierras por "+gananciasVenta+" euros");
			totalSierras+=gananciasVenta;
			ventasXdia(cantidad,gananciasVenta);
			for(int i=cantidad;i>0;i--) {
				sierras.remove(sierras.get(i));
			}
		}else {
			System.out.println("No hay sierras");
		}
		System.out.println();
	}
	
	//-------------------------------------------------------------------------------------------------------
	
	public static void cambioDia() {
		String resp="";
        do {
            System.out.println("¿Desea cambiar de día (s/n)?");
            resp = scLine.nextLine();
            if (!resp.equalsIgnoreCase("s") && !resp.equalsIgnoreCase("n")) {
                System.out.println("Por favor introduzca 's' o 'n'.");
            }

        } while (!resp.equalsIgnoreCase("s") && !resp.equalsIgnoreCase("n"));
		

		dia++;
		if(dia==8) {
			dia=1;
			for (int i=0;i<7;i++) {
				unidadesComp[i]=0;
				gastoXdia[i]=0;
				unidadesVend[i]=0;
				gananciaXdia[i]=0;
			}
		}
		
		System.out.println("DIA: "+dia);
		System.out.println("BENEFICIOS");
		System.out.println("-Tornillos:"+totalTornillos+" euros");
		System.out.println("-Sierras: "+totalSierras+" euros");
		System.out.println();
	}
	
	
	
	//--------------------------------------------------------------------------------------------------------
	static int unidadesComp[]=new int[7];//la posicion del array son los dias y lo que se gguarda en cada posicion son las unidades
	static int gastoXdia[]=new int[7];//compras
	
	static int unidadesVend[]=new int[7];
	static int gananciaXdia[]=new int[7];//ventas
	

	public static void comprasXdia(int cantidad, double gasto) {
		for(int i=0;i<unidadesComp.length;i++) {
			if(i==dia-1) {
				unidadesComp[i]+=cantidad;
				gastoXdia[i]+=gasto;
			}
		}
		
	}
	public static void ventasXdia(int cantidad,double ganancia) {
		for(int i=0;i<unidadesVend.length;i++) {
			if(i==dia-1) {
				unidadesVend[i]+=cantidad;
				gananciaXdia[i]+=ganancia;
			}
		}
	}

	
	//--------------------------------------------------------------------------------------------------------
	
	public static void resumenCompras() {
		System.out.println("RESUMEN COMPRAS POR DÍAS\n");
		for (int i=0;i<=7;i++) {
			if(i<dia) {
				System.out.println("Dia "+(i+1)+" "+unidadesComp[i]+" piezas "+gastoXdia[i]+" euros");
			}
		}
		System.out.println();
	}
	
	public static void resumenVentas() {
		System.out.println("RESUMEN VENTAS POR DIAS\n");
		for (int i=0;i<=7;i++) {
			if(i<dia) {
				System.out.println("Dia "+(i+1)+" "+unidadesVend[i]+" piezas "+gananciaXdia[i]+" euros");
			}
		}
		System.out.println();
	}

	//----------------------------------------------------------------------------------------------------------

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
