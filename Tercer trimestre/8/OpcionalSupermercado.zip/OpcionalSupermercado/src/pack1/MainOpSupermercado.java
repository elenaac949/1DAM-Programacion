package pack1;
import java.util.*;

public class MainOpSupermercado {
	
	static Scanner sc=new Scanner(System.in);
	static Scanner scLine=new Scanner(System.in);
	
	static int nmes=1;
	
	static HashSet<Producto> productos=new HashSet<Producto>();
	static ArrayList<Producto> arrayProductos=new ArrayList<Producto>();
	static HashMap<Integer,String> meses=new HashMap<Integer, String>();
	
	static HashSet<ProductoCategoria1> alimentos= new HashSet<ProductoCategoria1>();
	static HashSet<ProductoCategoria2> limpieza= new HashSet<ProductoCategoria2>();
	static HashSet<ProductoCategoria3> alcohol= new HashSet<ProductoCategoria3>();
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		meses.put(1, "enero");
		meses.put(2, "febrero");
		meses.put(3, "marzo");
		meses.put(4, "abril");
		meses.put(5, "mayo");
		meses.put(6, "junio");
		meses.put(7, "julio");
		meses.put(8, "agosto");
		meses.put(9, "septiembre");
		meses.put(10, "octubre");
		meses.put(11, "noviembre");
		meses.put(12, "diciembre");
		
		
		
		
		
		Producto p0=new ProductoCategoria1("Galletas María", 2.03, 76,112, 0.5, "02-02-2024","Francia", false);
		Producto p1=new ProductoCategoria1("Arroz", 1.50, 155, 221,1.05, "02-03-2024","España", true);
		Producto p2=new ProductoCategoria2("Suavizante", 2.60, 347,654, 1.5, false, "Ropa");
		Producto p3=new ProductoCategoria2("Detergente con Amoníaco", 1.45, 3,2,123, false, "Suelos");
		Producto p4=new ProductoCategoria3("Mahou", 0.56, 323, 987,1.2, 4.3,Tipo.cerveza, "España");
		Producto p5=new ProductoCategoria3("Vino Blanco", 0.80, 151,554, 1.06,5,Tipo.vino, "Italia");
		
		
		
		productos.add(p0);
		productos.add(p1);
		productos.add(p2);
		productos.add(p3);
		productos.add(p4);
		productos.add(p5);
		
		arrayProductos.add(p0);
		arrayProductos.add(p1);
		arrayProductos.add(p2);
		arrayProductos.add(p3);
		arrayProductos.add(p4);
		arrayProductos.add(p5);
		
		alimentos.add((ProductoCategoria1) p0);
		alimentos.add((ProductoCategoria1) p1);
		limpieza.add((ProductoCategoria2) p2);
		limpieza.add((ProductoCategoria2) p3);
		alcohol.add((ProductoCategoria3) p4);
		alcohol.add((ProductoCategoria3) p5);
		
		
		while(true) {
			
			String mes=meses.get(nmes);
			
			System.out.println("Menú Principal: "+mes+"\r\n"
					+ "1.- Compra de productos genérica\r\n"
					+ "2.- Compra de productos que están bajo mínimos\r\n"
					+ "3.- Venta aleatoria de productos\r\n"
					+ "4.- Ordenar elementos\r\n"
					+ "5.- Cambiar de mes");
			int opcion=0;
			String opcionS;
			do {
				System.out.println("\nElija una opcion");
				opcionS = scLine.nextLine();
			} while (isNumericInt(opcionS) == false);
			opcion = Integer.valueOf(opcionS);
			
			switch(opcion) {
			case 1:
				compraProductos();
				break;
			case 2:
				compraProductosMin();
				break;
			case 3:
				ventaAleatoria();
				break;
			case 4:
				ordenarElementos();
				break;
			case 5:
				pasarMes();
				break;
			}
		}
		
		
	}
	
	
	
	
	private static void pasarMes() {
		// TODO Auto-generated method stub
		nmes++;
		if(nmes==13) {
			nmes=1;
			resetDatos();
		}
		
		double coef=0;
		do {
			System.out.println("\nCoeficiente de descuento en productos de Categoria 1(0,7-1,2)-ALimentos: ");
			coef = sc.nextDouble();
		} while (coef <0.7 || coef>1.2);
		
		//1,2 no es un descuento es una subida???
		for(ProductoCategoria1 p:alimentos) {
			p.aplicarDescuento(coef);
		}
		
		do {
			System.out.println("\nCoeficiente de descuento en productos de Categoria 2(0,7-1,2)-Productos de limpieza: ");
			coef = sc.nextDouble();
		} while (coef <0.7 || coef>1.2);
		
		
		for(ProductoCategoria1 p:alimentos) {
			p.aplicarDescuento(coef);
		}
		
		do {
			System.out.println("\nCoeficiente de descuento en productos de Categoria 3(0,7-1,2)-Bebidas Alcohólicas: ");
			coef = sc.nextDouble();
		} while (coef <0.7 || coef>1.2);
		
		for(ProductoCategoria1 p:alimentos) {
			p.aplicarDescuento(coef);
		}
		
		
	}

	
	private static void resetDatos() {
		// TODO Auto-generated method stub
		for(Producto p:productos) {
			for(Integer mes:meses.keySet()) {
				p.resetearVentas(nmes);
			}
			
		}
	}










	private static void ordenarMes() {
		// TODO Auto-generated method stub
		String mesActual=meses.get(nmes);
		int mes=0;
		String opcionS;
		do {
			System.out.println("¿Qué mes desea consultar?");
			opcionS = scLine.nextLine();
		} while (isNumericInt(opcionS) == false);
		mes = Integer.valueOf(opcionS);
		
		Collections.sort(arrayProductos, new OrdenarPorVentaMes(mes));
		System.out.println("Ventas del mes de "+mesActual);
		for(Producto p:arrayProductos) {
			System.out.println(p.getNombre()+" -Ventas del mes: "+p.getVentaPorMes()[mes-1]);
		}
		System.out.println();
		
	}




	private static void ordenarTotal() {
		// TODO Auto-generated method stub
		Collections.sort(arrayProductos, new OrdenarPorTotalVenta());
		System.out.println("Lista de productos ordenados por el total de ventas");
		for(Producto p:arrayProductos) {
			System.out.println(p.getNombre()+" "+p.getCantidadVendidaTotal()+" unidades vendidas");
		}
		System.out.println();
	}


	private static void ordenarElementos() {
		// TODO Auto-generated method stub
		System.out.println("¿Como deseas ordenar los productos?");
		System.out.println("1.-Cantidad total de ventas desde el principio");
		System.out.println("2.-Cantidad total de ventas por mes");
		int opcion=0;
		String opcionS;
		do {
			System.out.println("\nElija una opcion");
			opcionS = scLine.nextLine();
		} while (isNumericInt(opcionS) == false);
		opcion = Integer.valueOf(opcionS);
		switch(opcion) {
		case 1:
			ordenarTotal();
			break;
		case 2:
			ordenarMes();
			break;
		}
	
	
	}
	


	private static void ventaAleatoria() {
		// TODO Auto-generated method stub
		Random r=new Random();
		int cantidadVendida=0;
		System.out.println("Venta aleatoria:");
		for(Producto p:productos) {
			cantidadVendida=r.nextInt(0, p.getCantidad()+1);
			p.vender(cantidadVendida);
			p.sumarVentasTotales(cantidadVendida);
			p.sumarVentasMes(nmes, cantidadVendida);
		}
		
		for(Producto p:productos) {
			System.out.println("--"+p);
			System.out.println("Ventas: "+p.getCantidadVendida()+" unidades");
			System.out.println("Cantidad actual: "+p.getCantidad()+" unidades");
			if(p.alertaPocasUnidades()==true) {
				System.out.println("¡¡¡Quedan pocas unidades!!!");
			}
			System.out.println();
		}
	}


	
	
	
	private static void compraProductosMin() {
		// TODO Auto-generated method stub
		int cantidad=0;
		String opcionS;
		for(Producto p: productos) {
			if(p.alertaPocasUnidades()==true) {
				System.out.println(p.getNombre()+" --EAN: "+p.getEan()+" --Cantidad: "+p.getCantidad()+" --Cantidad Mínima: "+p.getCantidadMin());
				do {
					System.out.print("\nCantidad a comprar: ");
					opcionS = scLine.nextLine();
				} while (isNumericInt(opcionS) == false);
				cantidad = Integer.valueOf(opcionS);
				p.anadirCantidad(cantidad);
				System.out.println(p.getNombre()+" --EAN: "+p.getEan()+" --Cantidad Actual: "+p.getCantidad()+" --Cantidad Mínima: "+p.getCantidadMin());
			
				System.out.println();
			}
		}
		System.out.println();
	}



	
	private static void compraProductos() {
		int ean,cantidad=0;
		double precioVenta=0;
		String opcionS;
		String respuesta=null;
		for(Producto p:productos) {
			System.out.println(p);
			
		}
		do {
			System.out.println("\nIntroduzca el numero EAN del producto que desea comprar");
			opcionS = scLine.nextLine();
		} while (isNumericInt(opcionS) == false);
		ean = Integer.valueOf(opcionS);
		Producto producto=new Producto(ean);
		boolean existeProducto=productos.contains(producto);
		if(existeProducto) {
			for (Producto p:productos) {
				if(p.equals(producto)) {
					do {
						System.out.print("Número de unidades compradas: ");
						opcionS = scLine.nextLine();
					} while (isNumericInt(opcionS) == false);
					cantidad = Integer.valueOf(opcionS);
					p.anadirCantidad(cantidad);
					p.anadirCantidad(cantidad);
					System.out.println("\n¿Cambiar el precio de venta base del producto?(s/n)");
					respuesta=scLine.nextLine();
					if(respuesta.equalsIgnoreCase("s") || respuesta.equalsIgnoreCase("S")) {
						System.out.print("\nNuuevo precio de venta:");
						precioVenta=sc.nextDouble();
						p.setPrecio(precioVenta);
					}
				}
			}
		}else {
			System.out.println("Ese producto no esta en el catálogo\n");
		}
		
	
	}

	
	
	
	
	
	static public boolean isNumericInt(String valor) {
		try {
			Integer.valueOf(valor);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return false;
		}
		return true;
	}

}
