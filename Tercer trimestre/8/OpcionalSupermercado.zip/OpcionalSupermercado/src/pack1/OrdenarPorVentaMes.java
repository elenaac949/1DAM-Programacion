package pack1;

import java.util.Comparator;

public class OrdenarPorVentaMes implements Comparator<Producto>{

	private int mes;

	
	public OrdenarPorVentaMes(int mes) {
		super();
		this.mes = mes;
	}

	public int getMes() {
		return mes;
	} void setMes(int mes) {
		this.mes = mes;
	}

	@Override
	public int compare(Producto o1, Producto o2) {
		// TODO Auto-generated method stub
				
		int ventas1=o1.getVentaPorMes()[mes-1];
		int ventas2=o2.getVentaPorMes()[mes-1];
		return Integer.compare(ventas1, ventas2);
	}
	
	
}



