package pack1;

import java.util.*;

public class Producto implements Control{
	private String nombre;
	private double precio;
	private int cantidad;
	private int cantidadMin;
	private int cantidadVendida;
	private int cantidadVendidaTotal;
	private int ean;
	private int ventaPorMes[];
	

	public Producto(String nombre, double precio, int cantidad, int ean) {
		super();
		this.nombre = nombre;
		this.precio = precio;
		this.cantidad = cantidad;
		this.ean = ean;
		this.ventaPorMes=new int[12];
	}
	
	public Producto(int ean) {
		super();
		this.ean = ean;
	}





	public int[] getVentaPorMes() {
		return ventaPorMes;
	}

	public void setVentaPorMes(int[] ventaPorMes) {
		this.ventaPorMes = ventaPorMes;
	}

	public int getCantidadVendidaTotal() {
		return cantidadVendidaTotal;
	}

	public void setCantidadVendidaTotal(int cantidadVendidaTotal) {
		this.cantidadVendidaTotal = cantidadVendidaTotal;
	}

	
	public int getCantidadVendida() {
		return cantidadVendida;
	}

	public void setCantidadVendida(int cantidadVendida) {
		this.cantidadVendida = cantidadVendida;
	}

	public int getCantidadMin() {
		return cantidadMin;
	}

	public void setCantidadMin(int cantidadMin) {
		this.cantidadMin = cantidadMin;
	}




	@Override
	public int hashCode() {
		return Objects.hash(ean);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
//		if (getClass() != obj.getClass())
//			return false;
		Producto other = (Producto) obj;
		return ean == other.ean;
	}

	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	public int getCantidad() {
		return cantidad;
	}
	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}
	public int getEan() {
		return ean;
	}
	public void setEan(int ean) {
		this.ean = ean;
	}
	
	public void anadirCantidad(int numUnidades) {
		int can=this.getCantidad();
		can+=numUnidades;
		this.setCantidad(can);
	}
	
	
	public void vender(int numUnidades) {
		int can=this.getCantidad();
		can-=numUnidades;
		this.setCantidad(can);
		this.setCantidadVendida(numUnidades);
	}
	
	public void sumarVentasTotales(int venta) {
		int ventas=this.cantidadVendidaTotal;
		ventas+=venta;
		this.setCantidadVendidaTotal(ventas);
	}
	
	public void sumarVentasMes(int mes,int cantidad) {
		this.ventaPorMes[mes-1]=cantidad;
		this.setVentaPorMes(ventaPorMes);
	}
	
	
	public void resetearVentas(int mes) {
		this.setCantidadVendida(0);
		this.setCantidadVendidaTotal(0);
		this.ventaPorMes[mes-1]=0;
		this.setVentaPorMes(ventaPorMes);
	}
	
	
	
	@Override
	public void aplicarDescuento(double coef) {
		// TODO Auto-generated method stub
		System.out.println("Debes meter este producto en alguna categoría");
	}
	@Override
	public boolean alertaPocasUnidades() {
		// TODO Auto-generated method stub
		return false;
		
	}

	@Override
	public String toString() {
		return "Producto [ean=" + ean + ", nombre=" + nombre + ", precio=" + precio + ", cantidad=" + cantidad + "]";
	}
	
}
