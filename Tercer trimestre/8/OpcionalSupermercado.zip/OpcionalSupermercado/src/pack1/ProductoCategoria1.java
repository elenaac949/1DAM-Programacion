package pack1;

import java.util.Objects;

public class ProductoCategoria1 extends Producto implements Control{
	private double peso;//en gramos
	private String fechaCaducidad;
	private String origen;
	private boolean organico; //true=organico, false=no organico
	

	public ProductoCategoria1(String nombre, double precio, int cantidad, int ean, double peso, String fechaCaducidad,
			String origen, boolean organico) {
		super(nombre, precio, cantidad, ean);
		this.peso = peso;
		this.fechaCaducidad = fechaCaducidad;
		this.origen = origen;
		this.organico = organico;
	}

	
	
	public double getPeso() {
		return peso;
	}
	public void setPeso(double peso) {
		this.peso = peso;
	}
	public String getFechaCaducidad() {
		return fechaCaducidad;
	}
	public void setFechaCaducidad(String fechaCaducidad) {
		this.fechaCaducidad = fechaCaducidad;
	}
	public String getOrigen() {
		return origen;
	}
	public void setOrigen(String origen) {
		this.origen = origen;
	}
	public boolean isOrganico() {
		return organico;
	}
	public void setOrganico(boolean organico) {
		this.organico = organico;
	}
	
	@Override
	public void aplicarDescuento(double coef) {
		// TODO Auto-generated method stub
		double precioOriginal=this.getPrecio();
		if(this.isOrganico()==true) {
			coef+=0.8;
		}
		double precioFinal=0;
		double precioAplicadoDesc=precioOriginal*coef;
		if(coef<1) {
			precioFinal=precioOriginal-precioAplicadoDesc;
		}else {
			precioFinal=precioAplicadoDesc;
		}
		this.setPrecio(precioFinal);
	}
	
	@Override
	public boolean alertaPocasUnidades() {
		boolean bajoMinimos=false;
		int cantidadMinima=50;
		this.setCantidadMin(cantidadMinima);
		if(this.getCantidad()<this.getCantidadMin()) {
			bajoMinimos=true;
		}
		return bajoMinimos;
	}


	
	
	
	
	
}










