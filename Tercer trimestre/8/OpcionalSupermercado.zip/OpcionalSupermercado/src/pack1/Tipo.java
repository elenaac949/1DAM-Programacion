package pack1;

public enum Tipo {
	cerveza,
	vino,
	whiskey;
}
