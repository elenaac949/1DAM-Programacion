package pack1;

public class ProductoCategoria3 extends Producto implements Control{

	private double volumen;//en litros
	private double gradoAlcohol;
	private Tipo tipo;
	private String origen;
	
	
	public ProductoCategoria3(String nombre, double precio, int cantidad, int ean, double volumen, double gradoAlcohol,
			Tipo tipo, String origen) {
		super(nombre, precio, cantidad, ean);
		this.volumen = volumen;
		this.gradoAlcohol = gradoAlcohol;
		this.tipo = tipo;
		this.origen = origen;
	}
	public double getVolumen() {
		return volumen;
	}
	public void setVolumen(double volumen) {
		this.volumen = volumen;
	}
	public double getGradoAlcohol() {
		return gradoAlcohol;
	}
	public void setGradoAlcohol(double gradoAlcohol) {
		this.gradoAlcohol = gradoAlcohol;
	}
	public Tipo getTipo() {
		return tipo;
	}
	public void setTipo(Tipo tipo) {
		this.tipo = tipo;
	}
	public String getOrigen() {
		return origen;
	}
	public void setOrigen(String origen) {
		this.origen = origen;
	}
	
	@Override
	public void aplicarDescuento(double coef) {
		// TODO Auto-generated method stub
		double precioOriginal=this.getPrecio();
		if(this.gradoAlcohol>=25) {
			coef+=1.3;
		}
		double precioFinal=0;
		double precioAplicadoDesc=precioOriginal*coef;
		if(coef<1) {
			precioFinal=precioOriginal-precioAplicadoDesc;
		}else {
			precioFinal=precioAplicadoDesc;
		}
		this.setPrecio(precioFinal);
	}
	@Override
	public boolean alertaPocasUnidades() {
		boolean bajoMinimos=false;
		int cantidadMinima=150;
		this.setCantidadMin(cantidadMinima);
		if(this.getCantidad()<this.getCantidadMin()) {
			bajoMinimos=true;
		}
		return bajoMinimos;
	}
	
	
}













