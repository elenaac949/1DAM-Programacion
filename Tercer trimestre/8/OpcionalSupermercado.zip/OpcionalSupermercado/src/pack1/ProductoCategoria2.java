package pack1;

public class ProductoCategoria2 extends Producto implements Control{

	private double volumen;
	private boolean biodegradable; //true=si, false=no
	private String usoRecomendado;

	public ProductoCategoria2(String nombre, double precio, int cantidad, int ean, double volumen,
			boolean biodegradable, String usoRecomendado) {
		super(nombre, precio, cantidad, ean);
		this.volumen = volumen;
		this.biodegradable = biodegradable;
		this.usoRecomendado = usoRecomendado;
	}
	
	
	
	public double getVolumen() {
		return volumen;
	}
	public void setVolumen(double volumen) {
		this.volumen = volumen;
	}
	public boolean isBiodegradable() {
		return biodegradable;
	}
	public void setBiodegradable(boolean biodegradable) {
		this.biodegradable = biodegradable;
	}
	public String getUsoRecomendado() {
		return usoRecomendado;
	}
	public void setUsoRecomendado(String usoRecomendado) {
		this.usoRecomendado = usoRecomendado;
	}
	
	@Override
	public void aplicarDescuento(double coef) {
		// TODO Auto-generated method stub
		double precioOriginal=this.getPrecio();
		if(this.isBiodegradable()==true) {
			coef+=0.7;
		}
		double precioFinal=0;
		double precioAplicadoDesc=precioOriginal*coef;
		if(coef<1) {
			precioFinal=precioOriginal-precioAplicadoDesc;
		}else {
			precioFinal=precioAplicadoDesc;
		}
		this.setPrecio(precioFinal);
		
	}
	@Override
	public boolean alertaPocasUnidades() {
		boolean bajoMinimos=false;
		int cantidadMinima=100;
		this.setCantidadMin(cantidadMinima);
		if(this.getCantidad()<this.getCantidadMin()) {
			bajoMinimos=true;
		}
		return bajoMinimos;
	}
	
}
