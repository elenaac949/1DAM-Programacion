package pack1;

public interface Control {
	void aplicarDescuento(double coef);
	boolean alertaPocasUnidades();
}
 