package panaderia;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Pan extends Producto {
	static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY");
	private String harina;
	private boolean semillas; // true=si,false=no

	public Pan(String nombre, String codigo, LocalDate fechaCaducidad, Tamanio tamanio, String harina,
			boolean semillas) {
		super(nombre, codigo, fechaCaducidad, tamanio);
		this.harina = harina;
		this.semillas = semillas;
	}

	public String getHarina() {
		return harina;
	}

	public void setHarina(String harina) {
		this.harina = harina;
	}

	public boolean isSemillas() {
		return semillas;
	}

	public void setSemillas(boolean semillas) {
		this.semillas = semillas;
	}

	@Override
	public String toString() {
		return "Pan " + this.getCodigo() + " - " + this.getNombre() + ". Caducidad: "
				+ this.getFechaCaducidad().format(formatter) + ". Tamaño " + this.getTamanio() + ". Harina de "
				+ this.getHarina();
	}

}
