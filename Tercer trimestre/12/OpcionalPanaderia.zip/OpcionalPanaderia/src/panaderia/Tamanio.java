package panaderia;

public enum Tamanio {
	PEQUEÑO(2, 5),
	MEDIANO(5, 15),
	GRANDE(15, 20);
	
	private int min;
	private int max;
	
	private Tamanio(int min, int max) {
		this.min = min;
		this.max = max;
	}
	
	public int getMin() {
		return min;
	}
	public void setMin(int min) {
		this.min = min;
	}
	public int getMax() {
		return max;
	}
	public void setMax(int max) {
		this.max = max;
	}
	
	
}
