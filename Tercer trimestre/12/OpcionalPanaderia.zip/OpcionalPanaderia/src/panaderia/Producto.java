package panaderia;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.*;
import java.util.Objects;

public class Producto implements Caducidad {
	private String nombre;
	private String codigo;
	private LocalDate fechaCaducidad;
	private Tamanio tamanio;
	static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY");

	public Producto(String nombre, String codigo, LocalDate fechaCaducidad, Tamanio tamanio) {
		super();
		this.nombre = nombre;
		this.codigo = codigo;
		this.fechaCaducidad = fechaCaducidad;
		this.tamanio = tamanio;
	}

	public Producto(String codigo) {
		super();
		this.codigo = codigo;
	}

	@Override
	public int hashCode() {
		return Objects.hash(codigo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
//		if (getClass() != obj.getClass())
//			return false;
		Producto other = (Producto) obj;
		return Objects.equals(codigo, other.codigo);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public LocalDate getFechaCaducidad() {
		return fechaCaducidad;
	}

	public void setFechaCaducidad(LocalDate fechaCaducidad) {
		this.fechaCaducidad = fechaCaducidad;
	}

	public Tamanio getTamanio() {
		return tamanio;
	}

	public void setTamanio(Tamanio tamanio) {
		this.tamanio = tamanio;
	}

	@Override
	public String toString() {
		return "Producto [codigo=" + codigo + ", nombre=" + nombre + ", fechaCaducidad="
				+ fechaCaducidad.format(formatter) + ", tamanio=" + tamanio + "]";
	}

	@Override
	public long diasCaducado(LocalDate fecha) {
		// TODO Auto-generated method stub
		long diasCaducado = ChronoUnit.DAYS.between(fecha, this.getFechaCaducidad());
		return diasCaducado;
	}

}
