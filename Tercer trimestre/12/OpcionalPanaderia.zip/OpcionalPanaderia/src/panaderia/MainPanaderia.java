package panaderia;

import java.util.*;
import java.util.HashMap;
import java.time.*;

import java.time.format.DateTimeFormatter;

public class MainPanaderia {
	static Scanner sc = new Scanner(System.in);
	static Scanner scLine = new Scanner(System.in);

	static HashSet<Producto> productos = new HashSet<Producto>();
	static HashSet<Producto> panes = new HashSet<Producto>();
	static HashSet<Producto> dulces = new HashSet<Producto>();
	static HashMap<Producto, Integer> ventas = new HashMap<Producto, Integer>();
	static ArrayList<Producto> caducados = new ArrayList<Producto>();
	static LocalDate fecha = LocalDate.now();
	static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY");

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LocalDate cadP1 = LocalDate.of(2024, 5, 11);
		LocalDate cadP2 = LocalDate.of(2024, 5, 9);
		LocalDate cadP3 = LocalDate.of(2024, 5, 15);
		LocalDate cadD1 = LocalDate.of(2024, 6, 15);
		LocalDate cadD2 = LocalDate.of(2024, 4, 15);
		LocalDate cadD3 = LocalDate.of(2024, 6, 11);

		
		Producto p1 = new Pan("Pan centeno", "P1", cadP1, Tamanio.GRANDE, "Centeno", true);
		Producto p2 = new Pan("Pan trigo", "P2", cadP2, Tamanio.MEDIANO, "Trigo", false);
		Producto p3 = new Pan("Pan rústico", "P3", cadP3, Tamanio.MEDIANO, "Trigo", false);
		Producto d1 = new Dulce("Croissant", "D1", cadD1, Tamanio.PEQUEÑO, 12.3);
		Producto d2 = new Dulce("Palmera", "D2", cadD2, Tamanio.MEDIANO, 143.4);
		Producto d3 = new Dulce("Croissant", "D3", cadD3, Tamanio.PEQUEÑO, 110.7);

		panes.add(p1);
		panes.add(p2);
		panes.add(p3);
		dulces.add(d1);
		dulces.add(d2);
		dulces.add(d3);

		productos.add(p1);
		productos.add(p2);
		productos.add(p3);
		productos.add(d1);
		productos.add(d2);
		productos.add(d3);

		boolean salir = false;
		while (!salir) {
			System.out.println("MENU PRINCIPAL - FECHA: " + fecha.format(formatter) + "\r\n" + "1. Vender pan\r\n"
					+ "2. Vender dulce\r\n" + "3. Ver ventas\r\n" + "4. Ver productos caducados\r\n" + "5. Salir");
			int opcion = 0;
			String opcionS;
			do {
				System.out.println("Elija una opción");
				opcionS = scLine.nextLine();
			} while (isNumericInt(opcionS) == false);
			opcion = Integer.valueOf(opcionS);
			switch (opcion) {
			case 1:
				venderPan();
				break;
			case 2:
				venderDulces();
				break;
			case 3:
				verVentas();
				break;
			case 4:
				verProductosCaducados();
				break;
			case 5:
				System.out.println("Hasta Luego");
				salir = true;
				break;
			}
		}
	}

	private static void verProductosCaducados() {
		// TODO Auto-generated method stub
		long diasCaducidad = 0;
		for (Producto p : productos) {
			diasCaducidad = p.diasCaducado(fecha);
			if (diasCaducidad >= 0) {
				caducados.add(p);
			}
		}

		System.out.println("CADUCADOS: ");
		for (Producto p : caducados) {
			diasCaducidad = p.diasCaducado(fecha);
			System.out.println(p + " - DIAS CADUCADO: " + diasCaducidad);
		}
		System.out.println();

	}

	private static void verVentas() {
		// TODO Auto-generated method stub

		if (ventas.size() > 0) {
			System.out.println("\nVentas:");
			int cantidad = 0;
			for (Producto pan : panes) {
				for (Producto p : ventas.keySet()) {
					cantidad = ventas.get(p);
					if (p.equals(pan)) {
						System.out.println(pan + " - Cantidad: " + cantidad);
					}
				}
			}

			for (Producto dulce : dulces) {
				for (Producto p : ventas.keySet()) {
					cantidad = ventas.get(p);
					if (p.equals(dulce)) {
						System.out.println(dulce + " - Cantidad: " + cantidad);
					}
				}
			}
		} else {
			System.out.println("No hay ventas todavia");
		}
		System.out.println();
	}

	private static void ventas(int cantidad, Producto nuevoProducto) {
		int suma;
		boolean yaVendido = ventas.containsKey(nuevoProducto);
		if (yaVendido == true) {
			suma = ventas.get(nuevoProducto);
			suma += cantidad;
			System.out.println("suma:" + suma);
			ventas.put(nuevoProducto, suma);
		} else if (yaVendido == false) {
			ventas.put(nuevoProducto, cantidad);
		}
		System.out.println("Venta realizada con éxito\n");
	}

	private static void venderDulces() {
		// TODO Auto-generated method stub
		System.out.println("Dulces: ");
		for (Producto dulce : dulces) {
			System.out.println(dulce);
		}
		System.out.print("\nCódigo: ");
		String codigo = null;
		int cantidad, suma = 0;
		codigo = scLine.nextLine();
		Producto nuevoProducto = new Producto(codigo);
		boolean existe = dulces.contains(nuevoProducto);
		if (existe) {
			for (Producto dulce : dulces) {
				if (dulce.equals(nuevoProducto)) {
					String opcionS;
					do {
						System.out.print("Cantidad: ");
						opcionS = scLine.nextLine();
					} while (isNumericInt(opcionS) == false);
					cantidad = Integer.valueOf(opcionS);
					ventas(cantidad, nuevoProducto);
				}
			}
		} else {
			System.out.println("\nEl código no está asociado a ningun dulce\n");
		}
	}

	private static void venderPan() {
		// TODO Auto-generated method stub
		System.out.println("Panes:");
		for (Producto pan : panes) {
			System.out.println(pan);
		}
		System.out.print("\nCódigo: ");
		String codigo = null;
		int cantidad, suma = 0;
		codigo = scLine.nextLine();
		Producto nuevoProducto = new Producto(codigo);
		boolean existe = panes.contains(nuevoProducto);
		if (existe) {
			for (Producto pan : panes) {
				if (pan.equals(nuevoProducto)) {
					String opcionS;
					do {
						System.out.print("Cantidad: ");
						opcionS = scLine.nextLine();
					} while (isNumericInt(opcionS) == false);
					cantidad = Integer.valueOf(opcionS);
					ventas(cantidad, nuevoProducto);
				}
			}
		} else {
			System.out.println("\nEl código no está asociado a ningún pan\n");
		}
	}

	static public boolean isNumericInt(String valor) {
		try {
			Integer.valueOf(valor);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return false;
		}
		return true;
	}

}
