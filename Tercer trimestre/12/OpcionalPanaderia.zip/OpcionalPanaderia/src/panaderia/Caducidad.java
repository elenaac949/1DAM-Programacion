package panaderia;

import java.time.LocalDate;

public interface Caducidad {
	long diasCaducado(LocalDate fecha);
}
