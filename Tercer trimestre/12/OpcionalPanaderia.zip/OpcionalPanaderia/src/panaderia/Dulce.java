package panaderia;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Dulce extends Producto {
	private double calorias;
	static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY");

	public Dulce(String nombre, String codigo, LocalDate fechaCaducidad, Tamanio tamanio, double calorias) {
		super(nombre, codigo, fechaCaducidad, tamanio);
		this.calorias = calorias;
	}

	public double getCalorias() {
		return calorias;
	}

	public void setCalorias(double calorias) {
		this.calorias = calorias;
	}

	@Override
	public String toString() {
		return "Pan " + this.getCodigo() + " - " + this.getNombre() + ". Caducidad: "
				+ this.getFechaCaducidad().format(formatter) + ". Tamaño " + this.getTamanio() + ". Calorias: "
				+ this.getCalorias();
	}

}
