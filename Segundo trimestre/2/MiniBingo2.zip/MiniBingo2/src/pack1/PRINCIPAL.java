package pack1;
import java.util.*;
public class PRINCIPAL {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//se instancian los jugadores
		Jugador j1=new Jugador();
		Jugador j2=new Jugador();
		Jugador j3=new Jugador();
		Jugador j4=new Jugador();
		Jugador j5=new Jugador();
		
		//se les da nombre
		j1.setNombre("Pedro");
		j2.setNombre("Juan");
		j3.setNombre("Luis");
		j4.setNombre("Sonia");
		j5.setNombre("Pablo");
		
		//se les asigna un carton
		
		j1.asignarCarton();
		j2.asignarCarton();
		j3.asignarCarton();
		j4.asignarCarton();
		j5.asignarCarton();
		
		//se instancia el bombo
		
		Bombo b1=new Bombo();
		

		Scanner sc=new Scanner(System.in);
		
		boolean hayGanador=false;
		while (!hayGanador) {
			System.out.println();
			System.out.println("Pulse Enter para dar bola");
			sc.nextLine();
			
			//dar bola
			int bola=b1.sacarBola();
			System.out.println();
			//comprobar carrtones con la bola que ha salido
		
			j1.comprobarCarton(bola);
			j2.comprobarCarton(bola);
			j3.comprobarCarton(bola);
			j4.comprobarCarton(bola);
			j5.comprobarCarton(bola);
			
			//comprobar ganador 
			System.out.println();
			boolean gano1=j1.comprobarGanador();
			boolean gano2=j2.comprobarGanador();
			boolean gano3=j3.comprobarGanador();
			boolean gano4=j4.comprobarGanador();
			boolean gano5=j5.comprobarGanador();
			
			if(gano1==true || gano2==true || gano3==true || gano4==true || gano5==true) {
				hayGanador=true;
			}
		}
		System.out.println();
		System.out.println("Fin de la partida");
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
