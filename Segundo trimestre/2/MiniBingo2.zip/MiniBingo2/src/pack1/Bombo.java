package pack1;

import java.util.Arrays;
import java.util.Random;

public class Bombo {

	
	private int panel[]=new int[21];


	//metodos

	public int sacarBola() {
		Random r=new Random();
		int numero=r.nextInt(1, 21);
		while(panel[numero]!=0) {
			numero=r.nextInt(1, 21);
		}
		panel[numero]=numero;
		
		System.out.println(Arrays.toString(panel));
		System.out.println();
		System.out.println("Número:"+ numero);
		return numero;
	}
	

	
}
