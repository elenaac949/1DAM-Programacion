package pack1;

import java.util.Random;

public class Jugador {

	private String nombre;
	private int num1;
	private int num2;
	private int num3;
	
	private String carton;
	int aciertos;
	
	//Getters y Setters


	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	

	//metodo para asignar carton 
	
	public void asignarCarton() {
		Random r=new Random();
		
		this.num1=r.nextInt(1,21);
		num1=r.nextInt(1,21);
		
		this.num2=r.nextInt(1,21);
		if (this.num1==this.num2) {
			while (this.num1==this.num2) {}
			this.num2=r.nextInt(1,21);
		}
		this.num3=r.nextInt(1,21);
		if (this.num3==this.num1 || this.num3==this.num2) {
			while (this.num3==this.num1 || this.num3==this.num2) {
				this.num3=r.nextInt(1,21);
			}
		}
		System.out.println("Los numeros de "+this.nombre+" son "+this.num1+","+this.num2+","+this.num3);
	}
	//sysos se pueden meter en cualquier metodo
	
	//metood de comprobar carton, que se usa cada vez que sale una bola
	

	// esta bola es la que aparece en el main
	public void comprobarCarton (int bola) {
		if (bola==this.num1) {
			this.aciertos++;
			System.out.println(this.nombre+" tiene el "+bola);
		}
		if (bola==this.num2) {
			this.aciertos++;
			System.out.println(this.nombre+" tiene el "+bola);
		}
		if (bola==this.num3) {
			this.aciertos++;
			System.out.println(this.nombre+" tiene el "+bola);
		}
		
	}
	
	//metodo para comprobar quien ha ganado
	
	public boolean comprobarGanador() {
		if (this.aciertos==3) {
			System.out.println("!!!BINGO!!!");
			System.out.println(this.nombre+" ha ganado");
			return true;
		}
		else {
			return false;
		}
	}
	
	
	
	
	
	
}
