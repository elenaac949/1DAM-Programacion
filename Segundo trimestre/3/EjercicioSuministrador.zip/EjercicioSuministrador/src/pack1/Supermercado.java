package pack1;

public class Supermercado {

	private String nombre;
	int cantidad[]=new int [11]; //array de productos para guardar los productos que se guardan
	private double costeTotal;
	
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public Supermercado(String nombre) {
		super();
		this.nombre = nombre;
	}
	
	
	
	//metodo para obtener todos los productos que se le suministra al super
    public Supermercado(String nombre, int numProductos) {
        this.nombre = nombre;
        this.cantidad = new int[numProductos];
        this.costeTotal = 0;
    }
    public double getCosteTotal() {
    	return costeTotal;
    }
    public void setCosteTotal(double costeTotal) {
    	this.costeTotal = costeTotal;
    }
  
    public int[] getCantidad() {
		return cantidad;
	}
	public void setCantidad(int[] cantidad) {
		this.cantidad = cantidad;
	}
	
	public void solicitarProducto(int unidades, int num) {
        cantidad[num-1] += unidades;
    }
	//numero de Unidades==unidades

	//numero de Productos =num
}
