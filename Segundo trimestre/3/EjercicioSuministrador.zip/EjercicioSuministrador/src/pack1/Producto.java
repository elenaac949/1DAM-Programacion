package pack1;
import java.util.*;
public class Producto {

	private int numero;
	private String nombre;
	private double precio;
	private int total; //total de productos que se han suministrado
	private double precioTotal;
	
	public int getNumero() {
		return numero;
	}
	public String getNombre() {
		return nombre;
	}
	public double getPrecio() {
		return precio;
	}
	
	

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	
	public Producto(int numero, String nombre, double precio) {
		super();
		this.numero = numero;
		this.nombre = nombre;
		this.precio = precio;
	}
	public Producto(String nombre, double precio) {
		super();
		this.nombre = nombre;
		this.precio = precio;
	}
	public void anadirTotal(int unidades) {
		this.total+=unidades;
		
	}
	//precio total total 
	public void anadirPrecioT() {
		this.precioTotal=total*precio;
		precioTotal=Math.round(precioTotal*100.00)/100.00;
		System.out.println("Total: "+this.precioTotal+" €");
	}
	
	
	
	
	
}
