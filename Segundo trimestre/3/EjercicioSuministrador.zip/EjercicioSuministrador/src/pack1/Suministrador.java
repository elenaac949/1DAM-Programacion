package pack1;
import java.util.*;
public class Suministrador {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		// instanciar productos

		Producto p1 = new Producto(1, "Detergente", 2.05);
		Producto p2 = new Producto(2, "Cereales", 1.60);
		Producto p3 = new Producto(3, "Zumo de Naranja", 0.90);
		Producto p4 = new Producto(4, "Brik de Leche", 0.55);
		Producto p5 = new Producto(5, "Arroz", 1.10);
		Producto p6 = new Producto(6, "Pizza", 2.85);
		Producto p7 = new Producto(7, "Pasta", 1.20);
		Producto p8 = new Producto(8, "Pollo", 6.53);
		Producto p9 = new Producto(9, "Patatas", 3.95);
		Producto p10 = new Producto(10, "Champú", 1.78);

		Producto producto[] = { p1, p2, p3, p4, p5, p6, p7, p8, p9, p10 };

		// instanciar los supermercados
		Supermercado s1 = new Supermercado("Mercadona");
		Supermercado s2 = new Supermercado("Lidl");
		Supermercado s3 = new Supermercado("Dia");
		Supermercado s4 = new Supermercado("Alcampo");
		Supermercado s5 = new Supermercado("AhorraMas");

		Supermercado supermercado[] = { s1, s2, s3, s4, s5 };

		Scanner sc = new Scanner(System.in);

		boolean repetir = true;
		while (repetir) {

			for (int i = 0; i < supermercado.length; i++) {
				System.out.println(supermercado[i].getNombre());
				while (true) {
					System.out.println("¿Qué producto se suministra (1-10)?");
					int num = sc.nextInt();
					if (num == -1) {
						break;
					}
					else {
					System.out.println(producto[num - 1].getNombre() + ", " + producto[num - 1].getPrecio() + " €");
					System.out.println("¿Número de unidades?");
					int unidades = sc.nextInt();
					supermercado[i].solicitarProducto(unidades, num);
					
					double precioT = unidades * producto[num - 1].getPrecio();
					producto[num - 1].anadirTotal(unidades);// esto suma las unidades en el método añadirTotal
					precioT = Math.round(precioT * 100.00) / 100.00;
					System.out.println("Total: "+precioT + " €");
					}
					System.out.println();
				}
				System.out.println();
			}

			System.err.println("Informe de productos totales y el precio");
			System.out.println();
			for (int j = 0; j < producto.length; j++) {
				System.out.print(producto[j].getNombre()+", "+ producto[j].getTotal() + " unidades. ");
				producto[j].anadirPrecioT();

			}

			System.out.println();
			System.err.println("Informe sobre lo que se suministra a cada supermercado ");
			System.out.println();
			
			for (int i = 0; i < supermercado.length; i++) {
				System.out.println("***Lista de pedidos de: "+supermercado[i].getNombre()+"***");
				for (int j = 0; j < producto.length; j++) {
					if (supermercado[i].cantidad[j] > 0) {
						double preciot = supermercado[i].cantidad[j] * producto[j].getPrecio();
						preciot = Math.round(preciot * 100.00) / 100.00;
						System.out.println(producto[j].getNombre() + ":"+supermercado[i].cantidad[j] + " unidades. Total: "+ preciot+" €");	
					}
	
				}
				System.out.println();
			}
			System.out.println();
			Scanner scLine = new Scanner(System.in);
			System.out.println("¿Quiere repetir la ronda de suministro? (Si/No)");
			String respuesta = scLine.nextLine();

			if (respuesta.equalsIgnoreCase("n") || respuesta.equalsIgnoreCase("no")) {
				System.out.println("Fin del suministro");
				repetir = false;
			}
		}

	}

}
