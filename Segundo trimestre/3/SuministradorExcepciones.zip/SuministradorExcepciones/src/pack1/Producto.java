package pack1;

public class Producto {
	private String nombre;
	private double precio;
	private int stockSolicitado;
	
	

	public Producto(String nombre, double precio) {
		super();
		this.nombre = nombre;
		this.precio = precio;
	}
	
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	public int getStockSolicitado() {
		return stockSolicitado;
	}
	public void setStockSolicitado(int stockSolicitado) {
		this.stockSolicitado = stockSolicitado;
	}
	
	
	
	
	public double precioPedido(int unidades) {
		
		double precioPedido=this.precio*unidades;
		return precioPedido;
	}
	
	public void acumularStock(int unidades) {
		
		this.stockSolicitado= this.stockSolicitado+unidades;

	}


}
