package pack1;

public class Supermercado {

	private String nombre;
	private int pedidos[]= new int[10];
	
	
	
	public Supermercado(String nombre) {
		super();
		this.nombre = nombre;
	}
	
	
	
	public int[] getPedidos() {
		return pedidos;
	}
	public void setPedidos(int[] pedidos) {
		this.pedidos = pedidos;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	
	public void apuntarPedido(int numProd, int cantidad) {
		this.pedidos[numProd]=this.pedidos[numProd]+cantidad;

	}
}
