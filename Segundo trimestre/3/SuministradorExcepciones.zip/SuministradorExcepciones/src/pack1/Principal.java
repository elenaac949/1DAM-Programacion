package pack1;

import java.util.*;

public class Principal {

	public static void main(String[] args) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Scanner scLine = new Scanner(System.in);

		Producto p0 = new Producto("Lejía", 2.50);
		Producto p1 = new Producto("Chocolate", 1.25);
		Producto p2 = new Producto("Brick de leche", 0.90);
		Producto p3 = new Producto("Macarrones", 1.50);
		Producto p4 = new Producto("Jamón", 5.75);
		Producto p5 = new Producto("Pulpo", 10.5);
		Producto p6 = new Producto("Mantequilla", 1.00);
		Producto p7 = new Producto("Lomo", 3.50);
		Producto p8 = new Producto("Natillas", 2.25);
		Producto p9 = new Producto("Caviar", 32.50);

		Producto productos[] = { p0, p1, p2, p3, p4, p5, p6, p7, p8, p9 };

		Supermercado s0 = new Supermercado("Mercadona");
		Supermercado s1 = new Supermercado("Carrefour");
		Supermercado s2 = new Supermercado("Lidl");
		Supermercado s3 = new Supermercado("Ahorra Más");
		Supermercado s4 = new Supermercado("Alcampo");

		Supermercado supermercados[] = { s0, s1, s2, s3, s4 };

		boolean repetir = true;

		while (repetir) {

			for (int i = 0; i < supermercados.length; i++) {

				int num = 0;
				System.out.println(supermercados[i].getNombre() + ":");
				while (num != -1) {	
					try {
						System.out.println("\nQue producto se suministra (1-10)?");
						num = sc.nextInt();
						
						if(num<0 || num>10) {
							if(num!=-1) {
							throw new IllegalArgumentException("!!!ERROR!!! El numero debe estar entre 1 y 10");
							}
						}
					} catch (InputMismatchException e) {
						System.err.println("!!!ERROR¡¡¡Introduce un numero válido");
						
					}catch (IllegalArgumentException e) {
						System.err.println(e.getMessage());
					}
					finally {
						sc.nextLine();
					}
			
					if (num != -1 ) {
						if(num>=1 && num<=10) {
						try {
							System.out.println(productos[num - 1].getNombre() + ", " + productos[num - 1].getPrecio() + " euros");
						} catch (Exception e) {	
						}
						int unidades=0;
						try {
							System.out.println("Número de unidades?");
							unidades = sc.nextInt();
							if (unidades>0) {
								System.out.println("Total: " + productos[num - 1].getPrecio() * unidades + " euros");
								productos[num - 1].acumularStock(unidades);
								supermercados[i].apuntarPedido(num - 1, unidades);
							}
							
							if(unidades<=0) {
								throw new IllegalArgumentException("¡¡¡ERROR!!!El número debe ser positivo");
							}
						} catch (InputMismatchException e) {
							System.err.println("¡¡¡ERROR!!!Debe introducir un número");
						}catch (IllegalArgumentException e) {
							System.err.println(e.getMessage());
						}
						finally {
							sc.nextLine();
						}
						
						
						}
					}
				}
				System.out.println();
			}

			for (int i = 0; i < supermercados.length; i++) {

				System.out.println("*** Listado de pedidos de: " + supermercados[i].getNombre() + " ***");

				double gastoTotalSuper = 0;
				for (int j = 0; j < productos.length; j++) {

					int pedidoPorProducto = supermercados[i].getPedidos()[j];

					if (pedidoPorProducto > 0) {

						double precioPorProducto = pedidoPorProducto * productos[j].getPrecio();

						gastoTotalSuper = gastoTotalSuper + precioPorProducto;

						System.out.println((pedidoPorProducto + " unidades de " + productos[j].getNombre() + ". Total: "
								+ precioPorProducto + " euros."));

					}
				}
				System.out.println(
						"-- Gasto final de " + supermercados[i].getNombre() + ": " + gastoTotalSuper + " euros. --");
				System.out.println();
			}

			System.out.println("||| LISTADO DE PEDIDOS TOTAL |||");

			double costeTotal = 0;

			for (int i = 0; i < productos.length; i++) {

				costeTotal = costeTotal + productos[i].getStockSolicitado() * productos[i].getPrecio();

				if (productos[i].getStockSolicitado() > 0)
					System.out.println(productos[i].getStockSolicitado() + " unidad/es de " + productos[i].getNombre()
							+ ". Total: " + (productos[i].getStockSolicitado() * productos[i].getPrecio()) + " euros.");
			}

			System.out.println("COSTE TOTAL: " + costeTotal + " euros.");
			System.out.println();

			System.out.println("¿Se quiere repetir otra ronda de suministro? (s/n)");

			String respuesta = scLine.nextLine();

			if (respuesta.equalsIgnoreCase("n") || respuesta.equalsIgnoreCase("no"))
				repetir = false;

		}

		System.out.println("¡¡A Repartir!!");
	}

}
