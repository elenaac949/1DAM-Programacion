package pack1;
import java.util.*;
public class Vaca extends Animal{
	
	private boolean uso;// true=leche, false=carne
	private double leche;
	
	
	public Vaca(String nombre, double peso, int edad, boolean uso) {
		super(nombre, peso, edad);
		this.uso=uso;
		this.setTipo("vaca");

	}

	public boolean isUso() {
		return uso;
	}

	public double getLeche() {
		return leche;
	}

	public void setLeche(double leche) {
		this.leche = leche;
	}

	public void setUso(boolean uso) {
		this.uso = uso;
	}

	
	//metodo para sumar la leche ordeñada en la leche de cada vaca
	public void darLeche(double sumaLeche) {
		this.leche+=sumaLeche;
	}


	
	
	
	
	
}
