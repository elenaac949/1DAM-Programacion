package pack1;
import java.util.*;
public class Animal {
		
		private String nombre;
		private double peso;//KG
		private int edad;//años
		private String tipo;//vaca,cerdo,oveeja
		private boolean vivo; //true=si,false=no 
		
		
		public Animal(String nombre, double peso, int edad) {
			super();
			this.nombre = nombre;
			this.peso = peso;
			this.edad = edad;
			this.tipo=tipo;
			this.vivo=true;
		}
		
		public void muerto() {
			this.vivo=false;
		}
		
		public String getNombre() {
			return nombre;
		}
		public void setNombre(String nombre) {
			this.nombre = nombre;
		}
		public double getPeso() {
			return peso;
		}
		public void setPeso(double peso) {
			this.peso = peso;
		}
		public int getEdad() {
			return edad;
		}
		public void setEdad(int edad) {
			this.edad = edad;
		}
		
		
		public boolean isVivo() {
			return vivo;
		}

		public void setVivo(boolean vivo) {
			this.vivo = vivo;
		}

		public String getTipo() {
			return tipo;
		}

		public void setTipo(String tipo) {
			this.tipo = tipo;
		}

		

		@Override
		public String toString() {
			String datos=""+this.nombre+" : peso: "+this.peso+" Kg, edad: "+this.edad+" años";
			return datos;
		}
		
		
		
}
