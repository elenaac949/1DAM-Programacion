package pack1;
import java.util.*;
public class Principal {

	static Scanner sc=new Scanner(System.in);
	static Scanner scLine=new Scanner(System.in);
	
	static Animal v1=new Vaca("Romera", 230.5, 3, true);
	static Animal v2=new Vaca("Facunda", 205.2, 3, false);
	static Animal v3=new Vaca("Fina", 245.4, 4, true);
	static Animal c1=new Cerdo("Petro", 90.2, 2, "rosado");
	static Animal o1=new Oveja("Mota", 40, 3, "rizado");
	static Animal o2=new Oveja("Coral", 50, 4, "liso");
	static Animal o3=new Oveja("Cebra", 37.6, 1, "rizado");

	static Animal animales[]= {v1,v2,v3,c1,o1,o2,o3};
	static int numAnimales=7;
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		boolean salir=false;
		while(!salir) {
			System.out.println("MENU PRINCIPAL");
			System.out.println("1.-Listado de animales");
			System.out.println("2.-Mostrar tipo de animal");
			System.out.println("3.-Sumar año a un animal");
			System.out.println("4.-Cambiar peso animal");
			System.out.println("5.-Marcar animal como muerto");
			System.out.println("6.-Adquirir nuevo cerdo");
			System.out.println("7.-Listado de animales completo");
			System.out.println("8.-Obtención de leche");
			System.out.println("9.-Venta de leche");
			System.out.println("\nElija una opción");
			
			int opcion=0;
			opcion=sc.nextInt();
			switch(opcion) {
			case 1:
				System.out.println("LISTADO DE ANIMALES");
				listaAnimales();
				
				break;
			case 2:
				System.out.println("MOSTRAR TIPO DE ANIMAL");
				listadoNum();
				tipoAnimal();
				break;
			case 3:
				System.out.println("SUMAR AÑO A ANIMAL");
				listaEdad();
				sumarAnyo();
				break;
			case 4:
				System.out.println("CAMBIAR PERO A ANIMAL");
				listaPeso();
				cambiarPeso();
				break;
			case 5:
				System.out.println("MARCAR ANIMAL COMO MUERTO");
				marcarMuerto();
				break;
			case 6: 
				System.out.println("ADQUIRIR NUEVO CERDO");
				nuevoCerdo();
				break;
			case 7:
				System.out.println("LISTADO DE ANIMALES COMPLETO");
				listadoCom();
				break;
			case 8:
				System.out.println("OBTENCIÓN DE LECHE");
				obtenerLeche();
				break;
			case 9:
				System.out.println("VENTA DE LECHE");
				ventaLeche();
				break;
			}
			
			
			
		}
		

		
		
	}
//----------------------------------
	
	public static void listaAnimales() {
		
		for (Animal a: animales) {
			System.out.println(a);
		}
		System.out.println("Pulse intro para volver al MENU PRINCIPAL");
		scLine.nextLine();
	}
	
	public static void listadoNum() {
		for (int i=0;i<animales.length;i++) {
			System.out.println(i+1+".- "+animales[i].getNombre());
		}

	}
	
	public static void tipoAnimal() {
		System.out.println("Elija un animal");
		int num=0;
		num=sc.nextInt();
		System.out.println(animales[num-1].getNombre()+" es "+animales[num-1].getTipo());
		System.out.println();
		System.out.println("Pulse intro para volver al MENU PRINCIPAL");
		scLine.nextLine();
	}
	//----------------------------------------------------------------------
	public static void listaEdad() {
		for (int i=0;i<animales.length;i++) {
			System.out.println(i+1+".- "+animales[i].getNombre()+" edad: "+animales[i].getEdad()+" años");
		}
	}
	
	public static void sumarAnyo() {
		System.out.println("Elija un animal");
		int num=0;
		num=sc.nextInt();
		int edadActual=animales[num-1].getEdad();
		animales[num-1].setEdad(edadActual+1);
		System.out.println(animales[num-1].getNombre()+" ahora tiene "+animales[num-1].getEdad()+" años");
		System.out.println();
		System.out.println("Pulse intro para volver al MENU PRINCIPAL");
		scLine.nextLine();
	}
	
	//_---------------------------------------------

	public static void listaPeso() {
		for (int i=0;i<animales.length;i++) {
			System.out.println(i+1+".- "+animales[i].getNombre()+" peso: "+animales[i].getPeso()+" Kg");
		}
	}
	
	public static void cambiarPeso() {
		System.out.println("Elija un animal");
		int num=0;
		num=sc.nextInt();
		System.out.println("¿Nuevo peso?");
		double peso=0;
		peso=sc.nextDouble();
		
		double pesoAct=animales[num-1].getPeso();
		if(pesoAct<peso) {
			double resta=peso-pesoAct;
			resta=Math.round(resta*100.00)/100.00;
			System.out.println(animales[num-1].getNombre() +" ha ganado "+resta+" Kg");
		}
		else if(pesoAct>peso) {
			double resta=pesoAct-peso;
			resta=Math.round(resta*100.00)/100.00;
			System.out.println(animales[num-1].getNombre() +" ha perdido "+resta+" Kg");
		}
		else {
			System.out.println("Es el mismo peso");
		}
		System.out.println();
		System.out.println("Pulse intro para volver al MENU PRINCIPAL");
		scLine.nextLine();
	}
	
	//-------------------------------------------------------------
	
	public static void marcarMuerto() {
		listadoNum();
		System.out.println("Elija un animal");
		int num=0;
		num=sc.nextInt();
		animales[num-1].muerto();
		System.out.println("El animal "+animales[num-1].getNombre()+" ha muerto");
		System.out.println();
		System.out.println("Pulse intro para volver al MENU PRINCIPAL");
		scLine.nextLine();
	}
	
	//----------------------------------------------------------------
	
	public static void nuevoCerdo() {
		if(c1.isVivo()) {
			System.out.println("Ya hay un cerdo en la granja");
		}
		else {
			System.out.println("Datos del nuevo cerdo");
			System.out.println("Nombre: ");
			String nombre="";
			nombre=scLine.nextLine();
			System.out.println("\nPeso: ");
			double peso= sc.nextDouble();
			System.out.println("\nEdad: ");
			int edad=sc.nextInt();
			Animal c1= new Animal(nombre, peso, edad);
			System.out.println("\nDatos del nuevo cerdo:");
			System.out.println(c1.toString());
			System.out.println();
			System.out.println("Pulse intro para volver al MENU PRINCIPAL");
			scLine.nextLine();
			
		}
	}
	
	//_------------------------------------------------------------------------------
	
	public static void listadoCom() {
		for (Animal a:animales) {
			if(a instanceof Vaca) {
				Vaca vaca=(Vaca)a;//??????
				if(vaca.isUso()) {
					System.out.println(a.getTipo()+": "+a.getNombre()+" "+a.getPeso()+" kg "+a.getEdad()+" años uso: leche");
				}
				else {
					System.out.println(a.getTipo()+": "+a.getNombre()+" "+a.getPeso()+" kg "+a.getEdad()+" años uso: carne");
				}

			}
			else if(a instanceof Cerdo) {
				Cerdo cerdo=(Cerdo)a;//??????
				System.out.println(a.getTipo()+": "+a.getNombre()+" "+a.getPeso()+" kg "+a.getEdad()+" años color piel: "+ cerdo.getColorPiel());
			}
			else if(a instanceof Oveja) {
				Oveja oveja=(Oveja)a;//??????
				System.out.println(a.getTipo()+": "+a.getNombre()+" "+a.getPeso()+" kg "+a.getEdad()+" años tipo de pelo: "+oveja.getTipoPelo() );
			}
			
		}
		System.out.println();
		System.out.println("Pulse intro para volver al MENU PRINCIPAL");
		scLine.nextLine();
	}
	
	
	
	//----------------------------------------------------------------------
	static double lecheTot=0;
	static double lecheObt=0;
	public static void obtenerLeche() {
		Random r=new Random();
		for (Animal a: animales) {
			if(a instanceof Vaca) {
				Vaca vaca =(Vaca)a;
				if(vaca.isVivo()==true && vaca.isUso()==true) {
					double decimal=r.nextDouble();
					double unidades=r.nextInt(3,9);
					double suma=decimal+unidades;
					suma=Math.round(suma*10.0)/10.0;
					
//					System.out.println("leche antes "+vaca.getLeche());
					vaca.darLeche(suma);
					System.out.println("Leche obtenida por "+vaca.getNombre()+": "+vaca.getLeche()+" l");
					lecheObt+=suma;
					lecheObt=Math.round(lecheObt*10.0)/10.0;
				}
				else if(vaca.isVivo()==false) {
					System.out.println("La vaca "+vaca.getNombre()+" esta muerta");
				}
			}
		}
		lecheTot+=lecheObt;
		System.out.println("El stock de leche es de: "+lecheTot);
		System.out.println();
		System.out.println("Pulse intro para volver al MENU PRINCIPAL");
		scLine.nextLine();
	}
	//-----------------------------------------------------------------------
	static double gananciasTot=0;
	public static void ventaLeche() {
		if(lecheTot<=0) {
			System.out.println("Primero ordeña una vaca para tener leche que vender");
		}else {
			System.out.println("\nLeche en stock: "+lecheTot+" litros");
			double venta=lecheTot+1;

			

	        while (true) {
	            try {
	                System.out.println("¿Cuánta se quiere vender?");
	                venta = sc.nextDouble();

	                if (venta < 0) {
	                    throw new IllegalArgumentException("Error: La cantidad de venta no puede ser negativa.");
	                }

	                if (venta <= lecheTot) {
	                    lecheTot -= venta;
	                    System.out.println("Venta exitosa. Leche restante: " + lecheTot + " litros");
	                    break;
	                } else {
	                    System.out.println("Error: No hay suficiente leche en stock para vender esa cantidad.");
	                }
	            } catch (InputMismatchException e) {
	                System.out.println("Error: Introduce un número válido.");
	                sc.nextLine(); 
	            } catch (IllegalArgumentException e) {
	                System.out.println(e.getMessage());
	            }
	        }
			
			double precioLitro=0.5;//euros/litro
			double ganancias=venta*precioLitro;
			ganancias=Math.round(ganancias*1000.0)/1000.0;
			System.out.println("Ganancias por esta venta: "+ganancias+" euros");
			gananciasTot+=ganancias;
			System.out.println("Ganancias acumuladas: "+gananciasTot+" euros");
		}

		System.out.println();
		System.out.println("Pulse intro para volver al MENU PRINCIPAL");
		scLine.nextLine();
	}
	
	
	
//	while(venta>=lecheTot) {
//	System.out.println("¿Cuanta se quiere vender?");
//	venta=sc.nextDouble();
//	if(venta<lecheTot) {
//		lecheTot-=venta;
//	}
//}
	

	
	
	
}
