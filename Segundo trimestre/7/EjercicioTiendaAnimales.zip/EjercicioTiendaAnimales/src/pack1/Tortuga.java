package pack1;

public class Tortuga extends Animal {

	private boolean tipoOrejas; // true=rojas, false=amarillas
	public static double pCompra = 2.5;
//	public static int pventaRojas=24;
//	public static int pventaAmarilas=20;

	public static int pVenta;

	// constructor
	public Tortuga(String nombre, boolean tipoOrejas) {
		super(nombre);
		this.tipoOrejas = tipoOrejas;
		if (this.tipoOrejas == true) {
			this.pVenta = 24;
		} else {
			this.pVenta = 20;
		}
	}

	// getters y setters
	public boolean isTipoOrejas() {
		return tipoOrejas;
	}

	public void setTipoOrejas(boolean tipoOrejas) {
		this.tipoOrejas = tipoOrejas;
	}

	public static double getPcompra() {
		return pCompra;
	}

	public static void setPcompra(double pcompra) {
		Tortuga.pCompra = pcompra;
	}


	public static int getPventa() {
		return pVenta;
	}

	public static void setPventa(int pventa) {
		Tortuga.pVenta = pventa;
	}

	@Override
	public String toString() {
		String datos;
		if (this.tipoOrejas == true) {
			datos = "Nombre: " + this.getNombre() + "\nTipo de orejas: rojas";

		} else {
			datos = "Nombre: " + this.getNombre() + "\nTipo de orejas: amarillas";
		}
		return datos;

	}

	// por que puedo poner el toString en las dos y que funcione???

}
