package pack1;

public class Perro extends Animal {

	private String raza;
	private String tam;
	public static int pCompra = 5;
	private double pVenta;

	// constructor
	public Perro(String nombre, String raza, String tam, double pVenta) {
		super(nombre);
		this.raza = raza;
		this.tam = tam;
		this.pVenta = pVenta;
		this.pCompra = pCompra;

	}

	// getters y setters
	public String getRaza() {
		return raza;
	}

	public void setRaza(String raza) {
		this.raza = raza;
	}

	public String getTam() {
		return tam;
	}

	public void setTam(String tam) {
		this.tam = tam;
	}

	public static int getpCompra() {
		return pCompra;
	}

	public static void setpCompra(int pCompra) {
		Perro.pCompra = pCompra;
	}

	public double getpVenta() {
		return pVenta;
	}

	public void setpVenta(double pVenta) {
		this.pVenta = pVenta;
	}

	@Override
	public String toString() {
		String datos = "Nombre: " + this.getNombre() + "\nRaza: " + this.raza + "\nTamaño: " + this.tam;
		return datos;
	}

}
