package pack1;

public class Periquito extends Animal {

	private boolean colorPlumaje; // true=verde, false=azul
	public static double pCompra = 2.5;
//	public static int pventaVerdes=18;
//	public static int pventaAzules=25;

	public static int pVenta;

	// constructor
	public Periquito(String nombre, boolean colorPlumaje) {
		super(nombre);
		this.colorPlumaje = colorPlumaje;
		if (this.colorPlumaje == true) {
			this.pVenta = 18;
		} else {
			this.pVenta = 25;
		}

	}

	// getters y setters

	public boolean isColorPlumaje() {
		return colorPlumaje;
	}

	public void setColorPlumaje(boolean colorPlumaje) {
		this.colorPlumaje = colorPlumaje;
	}

	public static double getPcompra() {
		return pCompra;
	}

	public static void setPcompra(double pcompra) {
		Periquito.pCompra = pcompra;
	}


	public static int getPventa() {
		return pVenta;
	}

	public static void setPventa(int pventa) {
		Periquito.pVenta = pventa;
	}

	@Override
	public String toString() {
		String datos;
		if (this.colorPlumaje == true) {
			datos = "Nombre: " + this.getNombre() + "\nTipo de orejas: verdes";

		} else {
			datos = "Nombre: " + this.getNombre() + "\nTipo de orejas: azules";
		}
		return datos;

	}

}
