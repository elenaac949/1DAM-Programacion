package pack1;

public class Pienso {
	private double sInicial; // KG
	private double sActual;
	private double pcompra; // euros/KG
	private double pventa;// euros//KG
	private double dinGanado;
	private double dinGastado;

	public Pienso(double sInicial, double pcompra, double pventa) {
		super();
		this.sInicial = sInicial;
		this.pcompra = pcompra;
		this.pventa = pventa;
		this.sActual = sInicial;
		toString();
		toString1();
		toString2();
	}

	public double getsInicial() {
		return sInicial;
	}

	public void setsInicial(double sInicial) {
		this.sInicial = sInicial;
	}

	public double getPcompra() {
		return pcompra;
	}

	public void setPcompra(double pcompra) {
		this.pcompra = pcompra;
	}

	public double getPventa() {
		return pventa;
	}

	public void setPventa(double pventa) {
		this.pventa = pventa;
	}

	public double getDinGanado() {
		return dinGanado;
	}

	public void setDinGanado(double dinGanado) {
		this.dinGanado = dinGanado;
	}

	public double getDinGastado() {
		return dinGastado;
	}

	public void setDinGastado(double dinGastado) {
		this.dinGastado = dinGastado;
	}

	public double getsActual() {
		return sActual;
	}

	public void setsActual(double sActual) {
		this.sActual = sActual;
		// metodos para sumar y restar las ganancias

	}

	public void gastosTot(double compras) {
		dinGastado += compras;

	}

	public void gananciasTot(double ventas) {
		dinGanado += ventas;
	}

	@Override
	public String toString() {
		String datos = "\n*** Stock inicial: " + this.sInicial + "\n*** Precio de compra: " + this.pcompra
				+ " €\n*** Precio de venta: " + this.pventa + " €";
		return datos;

	}

	public String toString1() {
		String stock = "\n*** Stock Actual: " + this.sActual;
		return stock;
	}

	public String toString2() {
		String ganancia = "\n*** Total de compras: " + this.dinGastado + " € \n*** Total ventas: " + this.dinGanado
				+ " € ";
		return ganancia;
	}

}
