package pack1;

public class Animal {

	private String nombre;
	private boolean comprado;// true= comprado ,false=no hay animal
	private boolean vendido;// true= vendido, false=el perro sigue en la tienda

	public Animal(String nombre) {
		super();
		this.nombre = nombre;
		this.comprado = true;
		this.vendido = false;

	}

	// getters y setters
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public boolean isComprado() {
		return comprado;
	}

	public void setComprado(boolean comprado) {
		this.comprado = comprado;
	}

	public boolean isVendido() {
		return vendido;
	}

	public void setVendido(boolean vendido) {
		this.vendido = vendido;
	}

}
