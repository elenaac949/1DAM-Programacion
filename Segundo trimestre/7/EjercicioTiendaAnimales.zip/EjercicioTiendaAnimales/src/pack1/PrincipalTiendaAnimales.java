package pack1;

import java.util.*;

import javax.swing.plaf.synth.SynthOptionPaneUI;

public class PrincipalTiendaAnimales {

	static Scanner scInt = new Scanner(System.in);
	static Scanner scLine = new Scanner(System.in);
	static Scanner scd = new Scanner(System.in);

	// si los declaras aqui como estaticos son simepre iguales
	static Pienso pPerro = new Pienso(50, 0.2, 3);
	static Pienso pPerico = new Pienso(40, 0.1, 2.5);
	static Pienso pTortuga = new Pienso(40, 0.15, 2.8);

	// perros
	static Perro perro0 = new Perro("Perro0", "Chucho", "Mediano", 50.5);
	static Perro perro1 = new Perro("Perro1", "Perro de Aguas", "Mediano", 100);
	static Perro perro2 = new Perro("Perro2", "Border Collie", "Mediano", 205.3);
	static Perro perro3 = new Perro("Perro3", "Yorkshire terrier", "Pequeño", 89.7);

	static Periquito perico0 = new Periquito("Periquito0", true);
	static Periquito perico1 = new Periquito("Periquito1", true);
	static Periquito perico2 = new Periquito("Periquito2", false);
	static Periquito perico3 = new Periquito("Periquito3", false);
	static Periquito perico4 = new Periquito("Periquito4", true);

	static Tortuga tortu0 = new Tortuga("Tortuga0", false);
	static Tortuga tortu1 = new Tortuga("Tortuga1", false);
	static Tortuga tortu2 = new Tortuga("Tortuga2", false);
	static Tortuga tortu3 = new Tortuga("Tortuga3", false);

	// 18 animales en total
	static Animal animales[] = { perro0, perro1, perro2, perro3, perico0, perico1, perico2, perico3, perico4, tortu0,
			tortu1, tortu2, tortu3, null, null, null, null, null };

	static int numPerros = 4;// número de perros,max 5
	static int numTortugas = 4;// número de tortugas, max 6
	static int numPeriquitos = 5;// numero de periquitos, max 7
	static int numAnimales = 13;
	static int totAnimales = 18;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Ménu tienda de animales
		boolean salir = false;
		while (!salir) {
			System.out.println("Bienvenido a la tienda de animales.¿Qué desea hacer?");
			System.out.println("--1--Venta de animal");
			System.out.println("--2--Adquisición nuevo animal");
			System.out.println("--3--Compra de pienso");
			System.out.println("--4--Venta de pienso");
			System.out.println("--5--Informa piensos PROVISIONAL LISTA DE ANIMALES");
			System.out.println("--6--Salir del programa");

			int opcion = 0;
			String opcionS;
			do {
				System.out.println("Elija una opción");
				opcionS = scLine.nextLine();
			} while (isNumericInt(opcionS) == false);
			opcion = Integer.valueOf(opcionS);

			switch (opcion) {
			case 1:
				System.out.println("OPCION 1: Venta de animales");

				System.out.println("\n-1-Perro");
				System.out.println("-2-Tortuga");
				System.out.println("-3-Periquito");
				System.out.println("-4-Volver atrás");
				int opcion1 = 0;
				boolean entradaValida = false;
				do {
					try {
						System.out.println("¿Qué animal se va a vender?");
						String entrada = scLine.nextLine();
						opcion1 = Integer.parseInt(entrada);

						if (opcion1 < 1 || opcion1 > 4) {
							throw new IllegalArgumentException("El número debe estar entre 1 y 4");
						}
						entradaValida = true;
					} catch (NumberFormatException e) {
						System.out.println("Por favor, introduzca un número entero.");
					} catch (IllegalArgumentException e) {
						System.out.println(e.getMessage());
					}
				} while (!entradaValida);

				switch (opcion1) {
				case 1:
					listaPerros();
					ventaAnimal();
					break;
				case 2:
					listaTortugas();
					ventaAnimal();
					break;
				case 3:
					listaPeriquitos();
					ventaAnimal();
					break;
				case 4:
					break;
				}

				break;
			case 2:
				if (numAnimales < totAnimales) {
					compraAnimal();
				} else {
					System.out.println("La tienda está llena");
				}
				break;
			case 3:
				System.out.println("OPCION 3: Compra de pienso");
				compraPienso();
				break;
			case 4:
				System.out.println("OPCION 4: Venta de pienso");
				ventaPienso();
				break;
			case 5:
				System.out.println("OPCION 5: Informe de piensos ");
				informePiensos();
				break;
			case 6:
				System.out.println("Salir del programa");
				salir = true;
				System.out.println("Hasta pronto");
				break;
			default:
				System.err.println("ERROR. INTRODUCE UNA DE LAS OPCIONES MOSTRADAS");
				break;
			}
		}
	}

	static public boolean isNumericInt(String valor) {

		try {
			Integer.valueOf(valor);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			return false;
		}

		return true;
	}

	public static void ventaAnimal() {
		System.out.println();
		int num = 0;
		String opcionS;
		do {
			System.out.println("Introduce Número del animal que se quiere vender: ");
			opcionS = scLine.nextLine();
		} while (isNumericInt(opcionS) == false);
		num = Integer.valueOf(opcionS);

		if (animales[num] != null) {
			if (animales[num] instanceof Perro) {
				// Coche miCoche = (Coche) arrayVehiculos[ i ];
				Perro nuevoPerro = (Perro) animales[num];
				double pVenta = 0;
//				System.out.println("¿Precio de venta?");
//				pVenta=scd.nextDouble();
				boolean entradaValida = false;
				while (!entradaValida) {
					System.out.println("¿Precio de venta?");
					try {
						pVenta = scd.nextDouble();
						entradaValida = true;
					} catch (InputMismatchException e) {
						System.out.println("Por favor, introduce un número válido.");
						scd.next();
					}
				}
				System.out.println("***Informe de venta***");
				nuevoPerro.setpVenta(pVenta);
				System.out.println("Precio de compra: " + nuevoPerro.getpCompra() + " euros");
				System.out.println("Precio de venta: " + nuevoPerro.getpVenta() + " euros");
				double ganancias = nuevoPerro.getpVenta() - nuevoPerro.getpCompra();
				System.out.println("Ganancias: " + ganancias + " euros");

				numPerros--;
				numAnimales--;
			} else if (animales[num] instanceof Periquito) {
				Periquito nuevoPeriquito = (Periquito) animales[num];
				System.out.println("***Informe de venta***");
				System.out.println("Precio de compra: " + nuevoPeriquito.getPcompra() + " euros");
				System.out.println("Precio de venta: " + nuevoPeriquito.getPventa() + " euros");
				double ganancias = nuevoPeriquito.getPventa() - nuevoPeriquito.getPcompra();
				System.out.println("Ganancias: " + ganancias + " euros");
				numPeriquitos--;
				numAnimales--;
			} else if (animales[num] instanceof Tortuga) {
				Tortuga nuevaTortuga = (Tortuga) animales[num];
				System.out.println("***Informe de venta***");
				System.out.println("Precio de compra: " + nuevaTortuga.getPcompra() + " euros");
				System.out.println("Precio de venta: " + nuevaTortuga.getPventa() + " euros");
				double ganancias = nuevaTortuga.getPventa() - nuevaTortuga.getPcompra();
				System.out.println("Ganancias: " + ganancias + " euros");
				numTortugas--;
				numAnimales--;
			}
			animales[num].setComprado(false);// ya no esta en la tienda
			animales[num].setVendido(true);
			animales[num] = null;
			System.out.println("Venta exitosa!");

		} else {
			System.out.println("Error. Introdce un numero adecuado");
		}
		System.out.println();
	}

	// ----------------------------------------------------------------------------------------------
	public static void compraAnimal() {

		System.out.println("OPCION 2: Adquisición nuevo animal");
		System.out.println("Actualmente tenemos: \n" + numPerros + " Perros\n" + numTortugas + " Tortugas\n"
				+ numPeriquitos + " Periquitos");
		System.out.println("----------------------------------------");
		System.out.println("¿Qué animal se va a adquirir?");
		System.out.println("-1-Perro");
		System.out.println("-2-Tortuga");
		System.out.println("-3-Periquito");
		System.out.println("-4-Volver atrás");
		int opcion2 = 0;
//		opcion2=scInt.nextInt();
		String opcionS;
		do {
			System.out.println("Elija una opción");
			opcionS = scLine.nextLine();
		} while (isNumericInt(opcionS) == false);
		opcion2 = Integer.valueOf(opcionS);
		switch (opcion2) {
		case 1:
			if (numPerros < 5) {
				System.out.println("Número de perros actual: " + numPerros + "/5");
				System.out.println("***Datos nuevo Perro***");
				String nombrePerro = "Perro" + (numPerros);
				System.out.println("Nombre: " + nombrePerro);
				String raza = "";
				String tam = "";
				int pventa = 0;
				System.out.println("Raza: ");
				raza = scLine.nextLine();
				System.out.println("Tamaño (pequeño/mediano/grande): ");
				tam = scLine.nextLine();
//				System.out.println("Precio de venta: ");
//				pventa=scInt.nextInt();
				boolean entradaValida = false;
				while (!entradaValida) {
					System.out.println("Precio de venta posterior: ");
					try {
						pventa = scInt.nextInt();
						entradaValida = true;
					} catch (InputMismatchException e) {
						System.out.println("Por favor, introduce un número entero válido.");
						scInt.next(); // Limpia el buffer del scanner
					}
				}
				animales[numAnimales - 1] = new Perro(nombrePerro, raza, tam, pventa);
				animales[numAnimales - 1].setComprado(true);
				System.out.println("***Resumen de compra***\n" + animales[numAnimales - 1].toString());
				numPerros++;
				numAnimales++;
			} else {
				System.err.println("Vende algun perro para poder comprar. Espacio lleno.");

			}
			System.out.println();
//			System.out.println("creando perro");
//			for (int i=0;i<animales.length;i++) {
//				System.out.println("kjgasjgcdjc kjzxc");
//				if(animales[i]==null) {
//					
//					animales[i]=new Perro("hgj", "das", "dasdasd", 23);
//					animales[i].setComprado(true);
//					System.out.println("el creado el perro "+i);
//					break;
//				}
//				
//			}
			break;
		case 2:
			System.out.println("Número de tortugas actual " + numTortugas + "/6");
			if (numTortugas < 6) {
				System.out.println("***Datos nueva Tortuga***");
				String nombreTortu = "Tortuga" + numTortugas;
				System.out.println("Nombre: " + nombreTortu);
				System.out.println("Tipo de orejas(rojas/amarillas): ");
				String tipoOrejas = scLine.nextLine();
				tipoOrejas.trim();
				if (tipoOrejas.equalsIgnoreCase("rojas")) {
					animales[numAnimales - 1] = new Tortuga(nombreTortu, true);
				} else if (tipoOrejas.equalsIgnoreCase("amarillas")) {
					animales[numAnimales - 1] = new Tortuga(nombreTortu, false);
				} else {
					System.err.println("Introduce una entrada válida");
				}
				System.out.println("***Resumen de compra***\n" + animales[numAnimales - 1].toString());
				numTortugas++;
				numAnimales++;
			} else {
				System.err.println("Vende alguna tortuga para poder comprar. Espacio lleno");

			}
			System.out.println();

			break;

		case 3:
			System.out.println("Número de Periquitos actual: " + numPeriquitos + "/7");
			if (numPeriquitos < 7) {
				System.out.println("***Datos nuevo Periquito");
				String nombre = "Periquito" + numPeriquitos;
				System.out.println("Nombre: " + nombre);

				System.out.println("Color de plumaje(verde/azul): ");
				String colorPlumaje = scLine.nextLine();
				colorPlumaje.trim();
				if (colorPlumaje.equalsIgnoreCase("verde")) {
					animales[numAnimales - 1] = new Periquito(nombre, true);
				} else if (colorPlumaje.equalsIgnoreCase("verde")) {
					animales[numAnimales - 1] = new Periquito(nombre, false);
				} else {
					System.err.println("Introduce una entrada válida");
				}
				System.out.println("***Resumen de compra***\n" + animales[numAnimales - 1].toString());
				numPeriquitos++;
				numAnimales++;
			} else {
				System.err.println("Vende algun periquito para poder comprar. Espacio lleno");
			}
			System.out.println();

			break;
		case 4:
			break;
		}

	}

	// -----------------------------------------------------------------------------------------------

	public static void listaPerros() {
		System.out.println("Lista de perros en venta: ");
		for (int i = 0; i < animales.length; i++) {
			if (animales[i] instanceof Perro && animales[i] != null) {
				System.out.println("(" + i + ")" + " Nombre: " + animales[i].getNombre());
				Perro perro = (Perro) animales[i];
				System.out.println("Raza: " + perro.getRaza());
				System.out.println("Tamaño: " + perro.getTam());
				System.out.println("Precio de compra: " + perro.getpCompra());
				System.out.println("Precio de venta: " + perro.getpVenta());
//				double balance=perro.getpVenta()-perro.getpCompra();
//				System.out.println("Balance "+perro.getNombre()+" : "+ balance);
				System.out.println("-------------------------------------------");
			}
		}
	}
	// ------------------------------------------------------------------------------------

	public static void listaTortugas() {
		System.out.println("Lista de tortugas en venta: ");
		for (int i = 0; i < animales.length; i++) {
			if (animales[i] instanceof Tortuga && animales[i] != null) {
				System.out.println("(" + i + ")" + " Nombre: " + animales[i].getNombre());
				Tortuga tortuga = (Tortuga) animales[i];// casting
				System.out.println("Precio de compra: " + tortuga.getPcompra());
//				double balance;
				if (tortuga.isTipoOrejas() == true) {
					System.out.println("Tipo de orejas: rojas");
					System.out.println("Precio de venta: " + tortuga.getPventa());
				} else {
					System.out.println("Tipo de orejas: amarillas");
					System.out.println("Precio de venta: " + tortuga.getPventa());
				}

				System.out.println("-------------------------------------------");

			}
		}
	}
	// ---------------------------------------------------------------------------

	public static void listaPeriquitos() {
		System.out.println("Lista de periquitos en venta: ");
		for (int i = 0; i < animales.length; i++) {
			if (animales[i] instanceof Periquito && animales[i] != null) {
				System.out.println("(" + i + ")" + "Nombre: " + animales[i].getNombre());
				Periquito periquito = (Periquito) animales[i];// casting
				System.out.println("Precio de compra: " + periquito.getPcompra());
//				double balance;
				if (periquito.isColorPlumaje() == true) {
					System.out.println("Color verde");
					System.out.println("Precio de venta: " + periquito.getPventa());
				} else {
					System.out.println("Color azul");
					System.out.println("Precio de venta: " + periquito.getPventa());
				}

				System.out.println("-------------------------------------------");

			}
		}
	}

	// ----------------------------------------------------------------------------------------

	// piensos STOCK COMPRA VENTA
	static Pienso piensoPerro = new Pienso(50, 0.2, 3);
	static Pienso piensoPeriquito = new Pienso(40, 0.1, 2.5);
	static Pienso piensoTortuga = new Pienso(40, 0.15, 2.8);

	public static void compraPienso() {
		int op = 0;
		boolean entradaValida = false;
		do {
			try {
				System.out.println("¿Qué tipo de pienso se va a comprar?");
				System.out.println("--1--Perro");
				System.out.println("--2--Tortuga");
				System.out.println("--3--Periquito");
				System.out.println("--4--Volver atrás");
				String entrada = scLine.nextLine();
				op = Integer.parseInt(entrada);

				if (op < 1 || op > 4) {
					throw new IllegalArgumentException("El número debe estar entre 1 y 4");
				}
				entradaValida = true;
			} catch (NumberFormatException e) {
				System.err.println("Por favor, introduzca un número entero.");
			} catch (IllegalArgumentException e) {
				System.err.println(e.getMessage());
			}
		} while (!entradaValida);

		double cantidad = 0;
		double gastoCompra;
		entradaValida = false;
		if (op != 4) {
			while (!entradaValida) {
				System.out.println("¿Cantidad de pienso (kg)?");
				try {
					cantidad = scd.nextDouble();
					entradaValida = true;
				} catch (InputMismatchException e) {
					System.err.println("Por favor, introduce un número.");
					scd.next();
				}
			}
		} else {

		}

		switch (op) {
		case 1:
			gastoCompra = piensoPerro.getPcompra() * cantidad;
			gastoCompra = Math.round(gastoCompra * 100.00) / 100.00;
			// vamos sumando ela cantidad al stock actual
			piensoPerro.setsActual(piensoPerro.getsActual() + cantidad);
			System.out.println("Nuevo stock: " + piensoPerro.getsActual());
			System.out.println("Gasto: " + gastoCompra);
			piensoPerro.gastosTot(gastoCompra);// para que se sume lo que has gastado
			break;
		case 2:
			gastoCompra = piensoTortuga.getPcompra() * cantidad;
			gastoCompra = Math.round(gastoCompra * 100.00) / 100.00;
			piensoTortuga.setsActual(piensoTortuga.getsActual() + cantidad);
			System.out.println("Nuevo stock: " + piensoTortuga.getsActual());
			System.out.println("Gasto: " + gastoCompra);
			piensoTortuga.gastosTot(gastoCompra);// para que se sume lo que has gastado

			break;
		case 3:
			gastoCompra = piensoPeriquito.getPcompra() * cantidad;
			gastoCompra = Math.round(gastoCompra * 100.00) / 100.00;
			piensoPeriquito.setsActual(piensoPeriquito.getsActual() + cantidad);
			System.out.println("Nuevo stock: " + piensoPeriquito.getsActual());
			System.out.println("Gasto: " + gastoCompra);
			piensoPeriquito.gastosTot(gastoCompra);// para que se sume lo que has gastado
			break;
		case 4:
			break;
		}
		System.out.println();
	}

	public static void ventaPienso() {
		boolean entradaValida = false;
		int op = 0;
		System.out.println("Perros: \n" + piensoPerro.toString() + "\n");
		System.out.println("Tortugas: \n" + piensoTortuga.toString() + "\n");
		System.out.println("Periquitos: \n" + piensoPeriquito.toString() + "\n");
		System.out.println("-------------------------------------------");
		do {
			try {
				System.out.println("¿Qué tipo de pienso se va a vender?");
				System.out.println("--1--Perro");
				System.out.println("--2--Tortuga");
				System.out.println("--3--Periquito");
				System.out.println("--4--Volver atrás");
				String entrada = scLine.nextLine();
				op = Integer.parseInt(entrada);
				if (op < 1 || op > 4) {
					throw new IllegalArgumentException("El número debe estar entre 1 y 4");
				}
				entradaValida = true;
			} catch (NumberFormatException e) {
				System.err.println("Por favor, introduzca un número entero.");
			} catch (IllegalArgumentException e) {
				System.err.println(e.getMessage());
			}
		} while (!entradaValida);

		double cantidad = 0;
		entradaValida = false;
		if (op != 4) {
			while (!entradaValida) {
				System.out.println("¿Cantidad de pienso (kg)?");
				try {
					cantidad = scd.nextDouble();
					entradaValida = true;
				} catch (InputMismatchException e) {
					System.err.println("Por favor, introduce un número.");
					scd.next();
				}
			}
		} else {

		}

		double gastoVenta;
		switch (op) {
		case 1:
			if (piensoPerro.getsActual() >= cantidad) {
				gastoVenta = piensoPerro.getPventa() * cantidad;
				// vamos sumando ela cantidad al stock actual
				piensoPerro.setsActual(piensoPerro.getsActual() - cantidad);
				System.out.println("Nuevo stock: " + piensoPerro.getsActual());
				System.out.println("Gasto: " + gastoVenta);
				piensoPerro.gastosTot(gastoVenta);// para que se sume lo que has gastado
			} else {
				System.out.println("No hay suficiente pienso para vender. Puebe otra vez");
			}

			break;
		case 2:
			if (piensoTortuga.getsActual() >= cantidad) {
				gastoVenta = piensoTortuga.getPcompra() * cantidad;
				piensoTortuga.setsActual(piensoTortuga.getsActual() - cantidad);
				System.out.println("Nuevo stock: " + piensoTortuga.getsActual());
				System.out.println("Gasto: " + gastoVenta);
				piensoTortuga.gastosTot(gastoVenta);// para que se sume lo que has gastado
			} else {
				System.out.println("No hay suficiente pienso para vender. Puebe otra vez");
			}

			break;
		case 3:
			if (piensoPeriquito.getsActual() >= cantidad) {
				gastoVenta = piensoPeriquito.getPcompra() * cantidad;
				piensoPeriquito.setsActual(piensoPeriquito.getsActual() - cantidad);
				System.out.println("Nuevo stock: " + piensoPeriquito.getsActual());
				System.out.println("Gasto: " + gastoVenta);
				piensoPeriquito.gastosTot(gastoVenta);// para que se sume lo que has gastado
			} else {
				System.err.println("No hay suficiente pienso para vender. Puebe otra vez");
			}
			break;
		}
		System.out.println();
	}

	public static void informePiensos() {
		System.out.println();
		System.out.println("Resumen de piensos");
		System.out.println("Perro: " + piensoPerro.toString());
		System.out.println(piensoPerro.toString2());
		System.out.println(piensoPerro.toString1());
		System.out.println("\nPeriquito: " + piensoPeriquito.toString());
		System.out.println(piensoPeriquito.toString2());
		System.out.println(piensoPeriquito.toString1());
		System.out.println("\nTortuga: " + piensoTortuga.toString());
		System.out.println(piensoTortuga.toString2());
		System.out.println(piensoTortuga.toString1());
		System.out.println();
	}

	public static void listaAnimales() {
		for (int i = 0; i < animales.length; i++) {
			if (animales[i] != null) {
				System.out.println("(" + i + ")" + "Nombre: " + animales[i].getNombre());

				System.out.println("-------------------------------------------");

			} else {
				System.out.println(i);
				System.out.println("-------------------------------------------");
			}
		}
		System.out.println("numero de animales: " + numAnimales);
		System.out.println("numero de perros " + numPerros);
		System.out.println("numero tortugas :" + numTortugas);
		System.out.println("numero periquitos :" + numPeriquitos);
		System.out.println();

	}

}
