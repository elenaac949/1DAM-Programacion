package pack1;
import java.util.*;
public class PrincipalExc {
	static Scanner sc=new Scanner(System.in);
	static Scanner scLine=new Scanner(System.in);
	static int longitud=0;
	static boolean hayArray=false;
	static int array [];
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Menu
		
		boolean salir=false;
		while(!salir) {
			System.out.println("MENU PRINCIPAL");
			System.out.println("1.-Creación de un array unidimensional");
			System.out.println("2.-Obtener raíz cuadrada del doble");
			System.out.println("3.-Salir");
			int opcion=0;
//			opcion=sc.nextInt();
			String opcionS;
			do {
				System.out.println("Selecione una opción");
				opcionS = scLine.nextLine();
			} while (isNumericInt(opcionS) == false);
			opcion = Integer.valueOf(opcionS);
			switch(opcion) {
			case 1:
				boolean volver=false;
				while(!volver) {
					System.out.println("CREACIÓN DE UN ARRAY UNIDIMENSIONAL\n");
		            System.out.println("1. Introducir longitud del array");
		            System.out.println("2. Obtener valores aleatorios alrededor de un índice");
		            System.out.println("3. Salir");
		            int opcion1 =0;
					String opcionS1;
					do {
						System.out.println("Selecione una opción");
						opcionS1 = scLine.nextLine();
					} while (isNumericInt(opcionS1) == false);
					opcion1 = Integer.valueOf(opcionS1);
					
					switch(opcion1) {
					case 1:
						Random r=new Random();
//						System.out.println("Introduce la longitud del array (5-10)");
//						longitud=sc.nextInt();
						boolean entradaValida=false;
						do {
							try {
								System.out.println("Introduce la longitud del array (5-10)");
								longitud=sc.nextInt();
								if(longitud<5 || longitud>10) {
									throw new IllegalArgumentException("Error. Vuelva a intentarlo");
								}else {
									entradaValida=true;
								}
								
							} catch (InputMismatchException e) {
								System.err.println("Error.Vuelva a intentarlo");
								sc.nextLine(); 
							}catch (IllegalArgumentException e) {
								System.err.println(e.getMessage());
								sc.nextLine(); 
							}
						}while(!entradaValida);
						
						
						array=new int[longitud];
						for (int i=0;i<array.length;i++) {
							array[i]=r.nextInt(5,11);
						}
						System.out.println(Arrays.toString(array));
						hayArray=true;
						break;
					case 2:
						Random r1=new Random();
						if(hayArray==true) {
							System.out.println("Introduce un numero entre 0 y "+(longitud-1));
							int num=0;
							num=sc.nextInt();
							int menor=num-2;
							int mayor=num+2;
							int posicion=r1.nextInt(menor,mayor+1);
							if(posicion<0  || posicion>longitud) {
								System.out.println("No hay ningun valor en la posicion "+posicion+" del array, porque no existe");
							}
							else {
								System.out.println("El valor de la posición "+posicion+" es "+array[posicion]);
							}
							System.out.println();
						}else if (hayArray==false){
							System.out.println("Primero debe ir a la opcion 1");
						}
						System.out.println();
						break;
					case 3:
						volver=true;
						break;
					}
				}
				System.out.println();
				break;
			case 2:
				Scanner scd=new Scanner(System.in);
				System.out.println("OBTENER LA RAIZ CUADRADA DE UN NUMERO");
				System.out.print("Introduce un número para calcular la raíz cuadrada: ");
		        try {
		            System.out.print("Introduce un número para calcular la raíz cuadrada: ");
		            double num = scd.nextDouble();
		            if (num <0) {
		                System.out.println("No se puede calcular la raíz cuadrada de un número negativo.");
		            } else {
		                double raiz = Math.sqrt(num);
		                raiz=Math.round(raiz*1000.00)/1000.00;
		                System.out.printf("La raíz cuadrada de "+num+" es: "+raiz);
		                System.out.println();
		            }
		        } catch (InputMismatchException e) {
		            System.out.println("Error: Debes ingresar un número válido.");
		        }
		        System.out.println();
				break;
			case 3:
				salir=true;
				break;
				
			}
		}
		System.out.println("Hasta pronto!");
			
	}
	static public boolean isNumericInt(String valor) {

		try {
			Integer.valueOf(valor);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			return false;
		}

		return true;
	}
	

	
	
	

}
