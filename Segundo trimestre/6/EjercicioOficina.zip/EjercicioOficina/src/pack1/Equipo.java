package pack1;

public class Equipo {

	private int numSerie;
	private String marca;
	private Empleado empleado;
	private boolean libre;// true=esta libre, false= no esta libre, alguien lo tiene
	private boolean reparado;//true= reparado,puede usarse: false=está en el taller
	public static int numEqRep=0;//numero de equipos que hay en reparacion
	
	//----------------------------------------------------------------------------------
	public Equipo(int numSerie, String marca) {
		super();
		this.numSerie = numSerie;
		this.marca = marca;	
		this.libre=true;
		this.reparado=true;
	}
	
	//-----------------------------------------------------------------------------------
	public int getNumSerie() {
		return numSerie;
	}
	public void setNumSerie(int numSerie) {
		this.numSerie = numSerie;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}

	public Empleado getEmpleado() {
		return empleado;
	}
	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}
	public boolean isLibre() {
		return libre;
	}

	public void setLibre(boolean libre) {
		this.libre = libre;
	}

	public boolean isReparado() {
		return reparado;
	}

	public void setReparado(boolean reparado) {
		this.reparado = reparado;
	}
	
	public static int getNumEqRep() {
		return numEqRep;
	}
	public static void setNumEqRep(int numEqRep) {
		Equipo.numEqRep = numEqRep;
	}

	//---------------------------------------------------------------------------------
	@Override
	public String toString() {
		String eq="Equipo con numero de serie "+this.numSerie+" y marca "+this.marca;
		return eq;
	}
	
	
}
