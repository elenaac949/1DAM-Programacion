package pack1;

import java.util.*;


public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Empleado empleados[]= new Empleado[7];//array con el numero de empleados
		
		empleados[0]=new Empleado("Elena", "Ciobanu", "X9320310C");
		empleados[1]=new Empleado("Marta", "Lopez", "98356182J");
		empleados[2]=new Empleado("Jorge", "Fernandez", "76292972D");
		empleados[3]=new Empleado("Mario", "Lopez", "87282730L");
		empleados[4]=new  Empleado(false);
		empleados[5]=new  Empleado(false);
		empleados[6]=new  Empleado(false);
		
	
		
//		Portatil portatiles[]=new Portatil[4];
//		
//		portatiles[0]=new Portatil(1, "Lenovo", "HDD", 500, 8);
//		portatiles[1]=new Portatil(2, "Lenovo", "SSD", 1024, 16);
//		portatiles[2]=new Portatil(3, "Lenovo", "HDD", 1024, 32);
//		portatiles[3]=new Portatil(4, "Lenovo", "SSD", 500, 16);
//		
//		
//		Movil moviles[]=new Movil[5];
//		moviles[0]=new Movil(5, "Xiomi", 128);
//		moviles[1]=new Movil(6, "Apple", 64);
//		moviles[2]=new Movil(7, "Samsung", 128);
//		moviles[3]=new Movil(8, "Xiomi", 128);
//		moviles[4]=new Movil(9, "Xiomi", 64);
		
		
		
		Equipo equipos[]= new Equipo [9];
		equipos[0]=new Portatil(222, "Lenovo", "HDD", 500, 8);
		equipos[1]=new Portatil(654, "Lenovo", "SSD", 1024, 16);
		equipos[2]=new Portatil(987, "Lenovo", "HDD", 1024, 32);
		equipos[3]=new Portatil(123, "Lenovo", "SSD", 500, 16);
		equipos[4]=new Movil(6666, "Xiomi", 128);
		equipos[5]=new Movil(8888, "Apple", 64);
		equipos[6]=new Movil(1111, "Samsung", 128);
		equipos[7]=new Movil(2222, "Xiomi", 128);
		equipos[8]=new Movil(9999, "Xiomi", 64);
		
		
		
		//MENU
		Scanner scInt=new Scanner(System.in);
		Scanner scLine=new Scanner(System.in);
		
		boolean salir=false;
		while(!salir) {
			int opcion=0;
			System.out.println("--MENÚ PRINCIPAL--");
			System.out.println("-1-Listado de empleados");
			System.out.println("-2-Listado de equipos");
			System.out.println("-3-Asignar/Desasignar equipos a un empleado");
			System.out.println("-4-Reparaciones");
			System.out.println("--5--Salir del programa");
			System.out.println("Nuestra oficina cuenta actualmente con "+Empleado.numEmpleados+" empelados");
			System.out.println("\nElija una opción");
			
			try {
				opcion=scInt.nextInt();
			} catch (Exception e) {
				System.err.println("¡¡ERROR!! Introduce un número");
				scInt.next();
			
			}
			switch(opcion) {
			case 1:
				int opcion1=0;
				
				System.out.println("HAS ELEGIDO LA OPCION 1: EMPLEADOS");
				
				System.out.println("-1-Dar de alta un empleado");
				System.out.println("-2-Dar de baja un empleado");
				System.out.println("-3-Listado de todos los empleados");

				System.out.println("\nElija una opcion");
				
				try {
					opcion1=scInt.nextInt();
				} catch (Exception e) {
					System.err.println("¡¡ERROR!! Debes introducir un número");
					scInt.next();
				}
				
				switch(opcion1) {
				case 1:
					altaEmpleado(empleados);
					break;
				case 2:
					System.out.println("DAR DE BAJA UN EMPLEADO");
					verEmpleados(empleados);
					bajaEmpleado(empleados);
					break;
				case 3:
					verEmpleados(empleados);
					mostrarDatosEmpleados(empleados);
					break;
				default:
					System.err.println("\n***INTRODUCE UNA OPCIÓN DE LAS MOSTRADAS***");
					break;
				}
				
				break;
				
			case 2:
				System.out.println("OPCIÓN 2: LISTADO DE EQUIPOS");
				verEquipos(equipos);
				mostrarDetallesEquipos(equipos);
				break;
				
			case 3:
				do {
					System.out.println("OPCIÓN 3: ASIGNAR/DESASIGNAR EQUIPOS");
					System.out.println("¿Qué desea hacer?");
					System.out.println("--1--Asignar equipos a un empleado");
					System.out.println("--2--Desasignar equipos a un empleado");
					opcion=0;
					opcion=scInt.nextInt();
				}while(opcion<1 || opcion>2);
				
				switch(opcion) {
					case 1:
						System.out.println("Asignación de equipos");
						datosAsignacion(equipos,empleados);
						break;
					case 2:
						System.out.println("Desasignación de equipos");
						desasignacionEquipos(equipos,empleados);
						break;
				}				
				break;
				
			case 4:
				System.out.println("OPCIÓN 4: REPARACIONES");
				opcion=0;
				do {
					System.out.println("-1-Enviar un equipo a reparar");
					System.out.println("-2-Recoger equipo del taller");
					
					System.out.println("\nElija una opcion");
					opcion=scInt.nextInt();
				}while(opcion<1  || opcion>2);
				
				switch(opcion) {
				case 1:
					System.out.println("Enviar un equipo al taller");
					repararEquipo(equipos);
					break;
				case 2:
					System.out.println("Recoger equipo del taller");
					recogerEquipo(equipos);
					break;
				}
				
				break;
			case 5:
				System.out.println("¡Hasta pronto!");
				salir=true;
				break;
			default:
				System.err.println("\n***INTRODUCE UNA OPCIÓN DE LAS MOSTRADAS***");
				break;
			}
		}
		
	}
	//**************************************************************************************************************
	//OPCION 1: LISTA DE EMPLEADOS
	//CASE 1: DAR DE BAJA UN EMPLEADO
	public static void altaEmpleado(Empleado empleados[]) {
		Scanner sc = new Scanner(System.in);
		Scanner scLine = new Scanner(System.in);
		String nombre;
		String apellidos;
		String dni="";
	
		for (int i=0;i<empleados.length;i++) {
			if(empleados[i].isActivo()!=true) {
				System.out.println("Dar de alta al empleado número "+(i+1));
				System.out.println("\nNombre:");
				nombre=scLine.nextLine();
				System.out.println("\nApellidos: ");
				apellidos=scLine.nextLine();
				
				while(dni.length()!=9) {
					System.out.println("DNI (max 9 caracteres): ");
					dni=scLine.nextLine();
				}
				empleados[i]=new Empleado(nombre, apellidos, dni);
				Empleado.numEmpleados++;
				System.out.println("Empleado dado de alta: OK");
				break;
			}
		}
		
		for (int i=0;i<empleados.length;i++) {	
			if(empleados[i].isActivo()==true) {
				System.out.println("Empleado nº: "+(i+1)+" "+empleados[i].getNombre()+" "+empleados[i].getApellidos()+" con DNI "+empleados[i].getDni());
			}
		}
		
        System.out.println();
		
	}
	
	//CASE 2: DAR DE BAJA UN EMPLEADO
	public static void bajaEmpleado(Empleado empleados[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Para dar de baja un empleado inserte su ID de empleado: ");
		int numE=0;
		try {
			numE=sc.nextInt();
			
			if (numE<1 || numE>7) {
				throw new IllegalArgumentException("Introduce un ID de empleado correcto ");
			}
			if(empleados[numE-1].isActivo()==true) {
				empleados[numE-1].setActivo(false);
				Empleado.numEmpleados--;
				System.out.println("Empleado dado de baja con exito\n");
			}
			else {
				System.err.println("El empleado no existe");
			}
		} catch (InputMismatchException e) {
			System.err.println("Introduce un número válido");
		}catch (IllegalArgumentException e) {
			System.err.println(e.getMessage());
		}
		
	}
	//CASE 3: VER LISTA DE EMPLEADOS 
	public static void verEmpleados(Empleado empleados[]) {
		System.out.println("LISTA DE EMPLEADOS");
		for (int i=0;i<empleados.length;i++) {
			if(empleados[i].isActivo()==true) {
				System.out.println("Empleado Nº "+(i+1)+": "+empleados[i].getNombre()+" "+empleados[i].getApellidos());
				System.out.println();
			}
		}
	}
	
	//CASE 3: MOSTRAR LOS DATOS DE LOS EMPLEADOS 
	public static void mostrarDatosEmpleados(Empleado empleados[]) {
	Scanner sc = new Scanner(System.in);
	Scanner scLine = new Scanner(System.in);
	
		System.out.println("Para ver los datos de un empleado inserte el ID de empleado. Para salir pulse S");
		int numE=0;
		try {
			numE=sc.nextInt();
			
			if(empleados[numE-1].isActivo()!=true) {
				System.err.println("El empleado no existe");
			}
			else {
				System.out.println("Nombre :"+empleados[numE-1].getNombre());
				System.out.println("Apellidos :"+empleados[numE-1].getApellidos());
				System.out.println("DNI :"+empleados[numE-1].getDni());
				if(empleados[numE-1].getMovil()!=null) {
					System.out.println("Móvil asignado :"+empleados[numE-1].getMovil().toString());
				}
				if(empleados[numE-1].getPortatil()!=null) {
					System.out.println("Portátil asignado :"+empleados[numE-1].getPortatil().toString());
				}
			}
		} catch (Exception e) {
			System.err.println("Introduce un ID de empleado correcto ");
		}
		
		System.out.println();
		
	}
	
	//*********************************************************************************************************
	//OPCION 2: LISTADO DE EQUIPOS
	//
	
	public static void verEquipos(Equipo equipos[] ) {
		for (int i=0;i<equipos.length;i++) {
			System.out.println("Equipo nº "+(i+1));
			
			if(equipos[i] instanceof Portatil) {
				System.out.println("Tipo de equipo: Portátil");
			}
			else if (equipos[i] instanceof Movil) {
				System.out.println("Tipo de equipo: Móvil");
			}
			System.out.println("Marca: "+equipos[i].getMarca());
			System.out.println("Número de serie: "+ equipos[i].getNumSerie());
			if(equipos[i].isReparado()==true) {
				if (equipos[i].isLibre()) {
					System.out.println("Estado: No asignado");
				}
				else {
					System.out.println("Estado: Asignado");
					System.out.println("Empleado: ");
					System.out.println("Nombre completo: "+equipos[i].getEmpleado().getNombre()+" "+ equipos[i].getEmpleado().getApellidos());
					System.out.println("DNI: "+equipos[i].getEmpleado().getDni());
				}
			}
			else {
				System.out.println("Estado: En reparación");
			}

			System.out.println();
		}
	}
	//VER EQUIPOS
	public static void mostrarDetallesEquipos(Equipo equipos[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Para más información introduzca Id del equipo	: ");
		int idEquipo=sc.nextInt();
		
		if(equipos[idEquipo-1].isReparado()) {
			
			if (equipos[idEquipo-1].isLibre()) {
				System.out.println("Dispositivo libre");
			}
			else {
				System.out.println("El dispositivo no está asignado");
			}
		}
		else {
			System.out.println("Dispositivo en reparación");
		}
		
		if(equipos[idEquipo-1]==null) {
			System.out.println("Número de serie no válido");
		}
		else {
			System.out.println("Detalles del equipo:");
			System.out.println("Asignado a: ");
				if(equipos[idEquipo-1].getEmpleado()==null) {
					System.out.println("No asignado");
					System.out.println("Número de serie: "+equipos[idEquipo-1].getNumSerie());
					System.out.println("Marca: "+equipos[idEquipo-1].getMarca());
					if(equipos[idEquipo-1] instanceof Portatil) {
						Portatil portatil= (Portatil) equipos[idEquipo-1];//casting
						System.out.println("Tipo de disco: "+ portatil.getDisco());
						System.out.println("\nTamaño de disco: "+portatil.getTamDisco());
						System.out.println("nMemoria RAM: "+portatil.getRam());
					}
					else if(equipos[idEquipo-1] instanceof Movil) {
						Movil movil= (Movil) equipos[idEquipo-1];
						System.out.println("Pixeles pantalla: "+movil.getPixeles());
					}	
				}
				else {
					System.out.println(equipos[idEquipo-1].getEmpleado().getNombre()+equipos[idEquipo-1].getEmpleado().getApellidos());
					System.out.println("DNI: "+equipos[idEquipo-1].getEmpleado().getDni());
					System.out.println("Número de serie: "+equipos[idEquipo-1].getNumSerie());
					System.out.println("Marca: "+equipos[idEquipo-1].getMarca());
					
					if(equipos[idEquipo-1] instanceof Portatil) {
						Portatil portatil= (Portatil) equipos[idEquipo-1];//casting
						System.out.println("Tipo de disco: "+ portatil.getDisco());
						System.out.println("\nTamaño de disco: "+portatil.getTamDisco());
						System.out.println("nMemoria RAM: "+portatil.getRam());
					}
					else if(equipos[idEquipo-1] instanceof Movil) {
						Movil movil= (Movil) equipos[idEquipo-1];
						System.out.println("Pixeles pantalla: "+movil.getPixeles());
					}	
				}
				System.out.println();
			}
		}
	//*********************************************************************************************
	//OPCION 3 : ASIGNAR Y DESASIGNAR EQUIPOS
	//ASIGNAR
	public static void datosAsignacion(Equipo equipos[], Empleado empleados[]) {
		Scanner sc=new Scanner(System.in);
		verEquipos(equipos);
		System.out.println("Introduzca el ID del equipo que desea asignar: ");
		int idEq=sc.nextInt();
		verEmpleados(empleados);
		System.out.println("Introduzca el ID del empleado al que le quiere asignar el equipo: ");
		int idEm=sc.nextInt();
		asignacionEq(equipos[idEq-1],empleados[idEm-1]);
			
	}
	//
	public static void asignacionEq(Equipo equipo, Empleado empleado) {
		if(equipo.isReparado()) {
			if (equipo.isLibre()) {
				System.out.println("Dispositivo libre para asignar");
				equipo.setEmpleado(empleado);
				if(equipo instanceof Portatil) {
					Portatil portatil = (Portatil) equipo;
					System.out.println("Portátil asignado con éxito");
					empleado.setPortatil(portatil);
					equipo.setLibre(false);
				}
				if(equipo instanceof Movil) {
					Movil movil = (Movil) equipo;
					System.out.println("Móvil asignado con éxito");
					empleado.setMovil(movil);
					equipo.setLibre(false);
				}
			}
			else {
				System.out.println("El dispositivo ya está asignado");
			}
		}
		else {
			System.out.println("Dispositivo en reparación");
		}
	}
	//DESASIGNAR 
	public static void desasignacionEquipos(Equipo equipos[], Empleado empleados[]) {
		Scanner sc=new Scanner(System.in);
		verEquipos(equipos);
		System.out.println("Introduzca el ID del equipo que desea desasignar: ");
		int idEq=sc.nextInt();
		if(equipos[idEq-1] instanceof Portatil) {
			System.out.println("El equipo es un portatil");
			for (int j=0;j<empleados.length;j++) {
				if (empleados[j].getPortatil()==equipos[idEq-1]) {
					empleados[j].setPortatil(null);
				}
			}
		}
		else if(equipos[idEq-1] instanceof Movil) {
			System.out.println("El equipo es un movil");
			for (int j=0;j<empleados.length;j++) {
				if (empleados[j].getMovil()==equipos[idEq-1]) {
					empleados[j].setMovil(null);
				}
			}
		}	
		System.out.println("Equipo desasignado con éxito");
	}
		
	//**********************************************************************************************
	//OPCION 4 : REPARACIONES
	//mandar a reparar
	public static void repararEquipo(Equipo[] equipos) {
		Scanner sc=new Scanner(System.in);
		verEquipos(equipos);
		System.out.println("Introduzca el ID del equipo que desea reparar: ");
		int idEq=sc.nextInt();

		equipos[idEq-1].setLibre(false);
		equipos[idEq-1].setReparado(false);
		
		Equipo.numEqRep++;
		
		if(equipos[idEq-1].getEmpleado() !=  null) {
			if(equipos[idEq-1] instanceof Portatil)
				equipos[idEq-1].getEmpleado().setPortatil(null);
			if(equipos[idEq-1] instanceof Movil)
				equipos[idEq-1].getEmpleado().setMovil(null);
		}
	}
	//recoger de reparar
	public static void recogerEquipo(Equipo[] equipos) {
		for (int i=0;i<equipos.length;i++) {
			if (equipos[i].isReparado()==false) {
				System.out.println("ID: "+(i+1));
				System.out.println("Numero de serie: "+equipos[i].getNumSerie());
				System.out.println("Marca: "+equipos[i].getMarca());
				if(equipos[i] instanceof Portatil) System.out.println("Tipo: Portátil");
				if(equipos[i] instanceof Movil) System.out.println("Tipo: Móvil");
				System.out.println("***************");
			}

		}
		
		if(Equipo.getNumEqRep()!=0) {
			Scanner sc=new Scanner(System.in);
			System.out.println("Introduce el ID del equipo que quieres recoger de reparaciones:");
			int idEq=sc.nextInt();
			if(equipos[idEq-1].isReparado()==false) {
				equipos[idEq-1].setReparado(true);
				equipos[idEq-1].setLibre(true);
				System.out.println("El equipo se ha  recogido y ya está disponible");
				Equipo.numEqRep--;
			}
			else {
				System.out.println("Este equipo no se encuentra en reparaciones");
			}
		}
		else {
			System.out.println("No hay equipos en reparaciones\n");
		}
	}



}
