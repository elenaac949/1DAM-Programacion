package pack1;

public class Movil extends Equipo{

	private double pixeles;
	
	//--------------------------------------------------------------
	public Movil(int numSerie, String marca, double pixeles) {
		super(numSerie, marca);
		this.pixeles = pixeles;
	}

	//---------------------------------------------------------------
	public double getPixeles() {
		return pixeles;
	}

	public void setPixeles(double pixeles) {
		this.pixeles = pixeles;
	}
	//---------------------------------------------------------------
	@Override
	public String toString() {
		String movil="Pixeles de la cámara: "+this.pixeles;
		return movil;
	}
	
}
