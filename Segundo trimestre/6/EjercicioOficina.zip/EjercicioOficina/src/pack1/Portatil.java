package pack1;

public class Portatil extends Equipo {

	private String disco; //HDD o SSD
	private double tamDisco;//GB
	private double ram;//GB

	//--------------------------------------------------------------------------------------
	public Portatil(int numSerie, String marca, String disco, double tamDisco, double ram) {
		super(numSerie, marca);
		this.disco = disco;
		this.tamDisco = tamDisco;
		this.ram = ram;
	}
	//--------------------------------------------------------------------------------------
	public String getDisco() {
		return disco;
	}
	public void setDisco(String disco) {
		this.disco = disco;
	}
	public double getTamDisco() {
		return tamDisco;
	}
	public void setTamDisco(double tamDisco) {
		this.tamDisco = tamDisco;
	}
	public double getRam() {
		return ram;
	}
	public void setRam(double ram) {
		this.ram = ram;
	}
	//--------------------------------------------------------------------------------------
	@Override
	public String toString() {
		String port="Tamaño de disco "+this.tamDisco+" /Tipo de disco "+this.disco+" /Tamaño de RAM "+this.ram;
		return port;
	}
}
