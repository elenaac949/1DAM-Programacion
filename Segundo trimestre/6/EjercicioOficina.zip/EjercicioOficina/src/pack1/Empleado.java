package pack1;

public class Empleado {
	private String nombre;
	private String apellidos;
	private String dni;
	public static int numEmpleados=4;	
	private Portatil portatil;
	private Movil movil;
	private boolean activo; //true= activo, false=no activo
	
	//---------------------------------------------------------------
	public Empleado(String nombre, String apellidos, String dni) {
		super();
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.dni = dni;
		this.portatil=null;//portatil asignado
		this.movil=null;//movil asignado
		this.activo=true;
		
	}
	
	public Empleado(boolean activo) {
		super();
		this.activo = activo;
	}
	
	//--------------------------------------------------------------
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public String getDni() {
		return dni;
	}
	public void setDni(String dni) {
		this.dni = dni;
	}
	public int getNumEmpleado() {
		return numEmpleados;
	}
	public void setNumEmpleado(int numEmpleado) {
		this.numEmpleados = numEmpleado;
	}
	
	public static int getNumEmpleados() {
		return numEmpleados;
	}
	public static void setNumEmpleados(int numEmpleados) {
		Empleado.numEmpleados = numEmpleados;
	}
	public Portatil getPortatil() {
		return portatil;
	}
	public void setPortatil(Portatil portatil) {
		this.portatil = portatil;
	}
	public Movil getMovil() {
		return movil;
	}
	public void setMovil(Movil movil) {
		this.movil = movil;
	}
	public boolean isActivo() {
		return activo;
	}
	public void setActivo(boolean activo) {
		this.activo = activo;
	}

	
}
