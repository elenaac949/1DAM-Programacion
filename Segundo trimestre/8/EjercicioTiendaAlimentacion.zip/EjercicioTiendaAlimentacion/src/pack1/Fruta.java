package pack1;

public class Fruta extends Producto{


	private int caducidad;//dias
	private int cadActual;
	
	
	public Fruta(String nombre, double precio, int stock0, int caducidad) {
		super(nombre, precio, stock0);
		// TODO Auto-generated constructor stub
		this.caducidad=caducidad;
		this.cadActual=caducidad;
	}
	
	public int getCaducidad() {
		return caducidad;
	}

	public void setCaducidad(int caducidad) {
		this.caducidad = caducidad;
	}

	public int getCadActual() {
		return cadActual;
	}

	public void setCadActual(int cadActual) {
		this.cadActual = cadActual;
	}
	
	
}
