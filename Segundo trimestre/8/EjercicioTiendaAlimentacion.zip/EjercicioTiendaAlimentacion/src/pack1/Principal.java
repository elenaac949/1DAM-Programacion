package pack1;
import java.util.*;
public class Principal {

	static Scanner scInt=new Scanner(System.in);
	static Scanner scLine=new Scanner(System.in);
	
	
	
	//Procustos iniciales
	
	static Producto p0=new Fruta("Plátanos", 2.4, 150, 5);
	static Producto p1=new Fruta("Peras", 1.5, 200, 6);
	static Producto p2=new Fruta("Manzanas", 1.7, 250, 7);
	static Producto p3=new Conserva("Atún", 2.1, 500, 6, 2024);
	static Producto p4=new Conserva("Sardinas", 1.8, 600, 8, 2025);
	
	static Producto productos[]= {p0,p1,p2,p3,p4};
	
	static int dia=1;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean salir =false;
		while(!false) {
			System.out.println("\nMENÚ PRINCIPAL-Dia: "+dia);
			System.out.println("-1-Consumir producto");
			System.out.println("-2-Cambio de dia");
			System.out.println("-3-Ventas diarias");
			System.out.println("-4-Renovar conservas");
			int opcion =0;			
			String opcionS;
			do {
				System.out.println("Selecione una opción");
				opcionS = scLine.nextLine();
			} while (isNumericInt(opcionS) == false);
			opcion = Integer.valueOf(opcionS);
			
			
			switch(opcion) {
				case 1:
					System.out.println("Consumir Producto");
					consumirProducto();
					break;
				case 2:
					System.out.println("Cambio de dia");
					cambioDia();
					break;
				case 3:
					System.out.println("Ventas diarias");
					calculoVentas();
					break;
				case 4:
					System.out.println("Renovar conservas");
					renovarConservas();
					break;
				default:
					System.out.println("Introduce una de las opciones mostradas");
					break;
			}
		}	
	}
	
	
	static public boolean isNumericInt(String valor) {

		try {
			Integer.valueOf(valor);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			return false;
		}

		return true;
	}
	
	
	public static void consumirProducto() {

		for (int i=0;i<productos.length;i++) {
			System.out.println(i+1+"."+productos[i].toString());
		}

		int num=0;
		
		boolean entradaValida=false;
		do {
			try {
				System.out.println("\n¿Qué producto desea consumir (1-5)?");
				num=scInt.nextInt();
				if(num<1 || num>5) {
					throw new IllegalArgumentException("Introduce un numero de producto adecuado");
				}else {
					entradaValida=true;
				}
				
			} catch (InputMismatchException e) {
				System.err.println("Introduce un número válido");
				scInt.next(); 
			}catch (IllegalArgumentException e) {
				System.err.println(e.getMessage());
				scInt.next(); 
			}
		}while(!entradaValida);
		
		int cantidad=0;
		
		boolean entradaValida1=false;
		do {
			try {
				System.out.println("¿Qué cantidad?(numero de unidades)");
				cantidad=scInt.nextInt();


				if(cantidad>productos[num-1].getStock0()||cantidad<=0) {
					throw new IllegalArgumentException("Introduce una cantidad adecuada");
				}else {
					entradaValida1=true;
				}
				
			} catch (InputMismatchException e) {
				System.err.println("Introduce una cantidad adecuada");
				scInt.next(); 
			}catch (IllegalArgumentException e) {
				System.err.println(e.getMessage());
				scInt.next(); 
			}
		}while(!entradaValida1);
		productos[num-1].setStockActual(productos[num-1].getStockActual()-cantidad);
		productos[num-1].setUnidadesCon(cantidad);
		productos[num-1].setTotalVenta(cantidad*productos[num-1].getPrecio());
		System.out.println("Cantidad actual de "+productos[num-1].getNombre()+":"+productos[num-1].getStockActual());
		System.out.println("Pulse enter para volver al menú principal");
		scLine.nextLine();
	
	}
	public static void cambioDia() {
		System.out.println("Productos consumidos desde el dia 1");
		for(Producto prod:productos) {
			System.out.println(prod.getNombre()+": "+prod.getUnidadesCon()+" unidades");
		}
		dia+=1;
		
		for(Producto prod:productos) {
			prod.nuevoDia();
			if(prod instanceof Fruta) {
				int dias=((Fruta) prod).getCadActual();
				((Fruta) prod).setCadActual(dias-1);
			}
		}
		System.out.println("--------------------------------------------");
		Random r=new Random ();
		int nuevaCad;
		for(Producto prod:productos) {
			if(prod instanceof Fruta) {
				//Conserva conserva=(Conserva)p;
				Fruta fruta=(Fruta)prod;
				if (fruta.getCadActual()<=0) {
					nuevaCad=r.nextInt(fruta.getCaducidad()-1, fruta.getCaducidad()+2);
					fruta.setCadActual(nuevaCad);
					fruta.setStockActual(fruta.getStock0());
					System.out.println(fruta.getNombre()+" han caducado, se renueva a "+fruta.getStock0()+" unidades con caducidad de "+fruta.getCadActual()+" dias");
				}
			}
		}
		System.out.println("Siguiente día: "+dia);
				
		System.out.println("\nPulse enter para volver al menú principal");
		scLine.nextLine();
	}
	
	public static void calculoVentas() {
		System.out.println("Ventas del día de hoy: Dia "+dia);
		for(Producto p:productos) {
			System.out.println(p.getNombre()+" "+p.getTotalVenta()+" euros");
		}
		System.out.println("\nPulse enter para volver al menú principal");
		scLine.nextLine();
	}
	
	public static void renovarConservas() {
		
		if(p3.getStockActual()==p3.getStock0() && p4.getStockActual()==p4.getStock0()) {
			System.out.println("No hace falta renovar ninguna conserva");
		}
		else if(p3.getStockActual()<=p3.getStock0() ) {
			System.out.println(p3.getNombre()+" renovado a "+p3.getStock0());
		}
		else if(p4.getStockActual()<=p4.getStock0()) {
			System.out.println(p4.getNombre()+" renovado a "+p4.getStock0());
		}
		
		System.out.println("\nPulse intro para volver al menú principal");
		scLine.nextLine();
	}
	
	
	
	
	
//	for(Producto p:productos) {
//	if(p instanceof Conserva) {
//		System.out.println(p.getNombre()+" renovado a "+p.getStock0());
//	}
//
	
//	for (Producto p:productos) {
//		if(p instanceof Conserva) {
//			Conserva conserva=(Conserva)p;
//			if(conserva.getStockActual()<conserva.getStock0()) {
//				//restaurar el stock
//				System.out.println(conserva.getNombre()+" renovado a "+conserva.getStock0());
//			}
//			else {
//				//decir que la conserva en concreto tiene el stock 
//				System.out.println(conserva.getNombre()+" tiene el stock completo");
//			}
//		}
//	}
	
	
	//-------------------------------------------------------
		public static void caducidades() {
			for(Producto fruta:productos) {
				if(fruta instanceof Fruta) {
					//castear Coche miCoche = (Coche) arrayVehiculos[ i ];
					Fruta misfrutas=(Fruta)fruta;
					System.out.println("CADUCIDAD: "+misfrutas.getNombre()+" "+misfrutas.getCaducidad()+" dias");
				}
			}
		}

}
