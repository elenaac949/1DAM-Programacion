package pack1;

public class Conserva extends Producto{
	
	private int mes;
	private int anio;
	
	public Conserva(String nombre, double precio, int stock0,int mes,int anio) {
		super(nombre, precio, stock0);
		this.mes=mes;
		this.anio=anio;
	}

	public int getMes() {
		return mes;
	}

	public void setMes(int mes) {
		this.mes = mes;
	}

	public int getAnio() {
		return anio;
	}

	public void setAnio(int anio) {
		this.anio = anio;
	}

	



}
