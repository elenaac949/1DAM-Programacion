package pack1;

public class Producto {
	 private String nombre;
	 private double precio;
	 private int stock0;
	 private int stockActual;
	 private int unidadesCon;//unidades consumidas
	 private int unidadesConTot;
	 private double totalVenta;
	 
	public Producto(String nombre, double precio, int stock0) {
		super();
		this.nombre = nombre;
		this.precio = precio;
		this.stock0 = stock0;
		this.stockActual=stock0;
		this.unidadesCon=unidadesCon;
		this.totalVenta=totalVenta;
		nuevoDia();
	}
	



	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	public int getStock0() {
		return stock0;
	}
	public void setStock0(int stock0) {
		this.stock0 = stock0;
	}
	public int getStockActual() {
		return stockActual;
	}
	public void setStockActual(int stockActual) {
		this.stockActual = stockActual;
	}
	
	public int getUnidadesCon() {
		return unidadesCon;
	}

	public void setUnidadesCon(int unidadesCon) {
		this.unidadesCon = unidadesCon;
	}

	
	public double getTotalVenta() {
		return totalVenta;
	}

	public void setTotalVenta(double d) {
		this.totalVenta = d;
	}
	
	public void nuevoDia() {
		this.totalVenta=0;
	}
	

	@Override
	
	public String toString() {
		String datos= this.nombre+" "+this.precio+" "+this.stockActual;
		return datos;
	}
	 
}
