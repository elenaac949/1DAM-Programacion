package pack1;
import java.util.*;
public class Esfera {

	//volumen= (4/3)*pi*radio^3
	//superficie =4*pi*r^2
	
	private double radio;
	private String color;
	private String tamanyo;
	
	//setter y getters
	public double getRadio() {
		return radio;
	}
	public void setRadio(double radio) {
		this.radio = radio;
	}
	
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	
	public String getTamanyo() {
		return tamanyo;
	}
	public void setTamanyo(String tamanyo) {
		this.tamanyo=tamanyo;
	}
	
	//metodos
	
	double volumen() {
		double volumen;
		volumen=(4*Math.PI*Math.pow(radio,3))/3;
		volumen=Math.round(volumen*100.0)/100.0;	
		return volumen;
	}
	
	
	double superficie() {
		double superficie;
		superficie=4*Math.PI*Math.pow(radio, 2);
		superficie=Math.round(superficie*100.0)/100.0;
		return superficie;
	}
	
	void asignarColor() {
		Random r= new Random();
		int num=r.nextInt(1, 3);
		if (num==1) {
			color="verde";
			
		}
		else if (num==2) {
			color="azul";
		}	
	}
	 
	void asignarTamanyo() {
		if (radio==1.0) {
			tamanyo="pequeño";
		}
		else if (radio==2.0) {
			tamanyo="mediano";
		}
		else if (radio==3.0) {
			tamanyo="grande";
		}
	}
	
	
	
	
	
}
