package pack1;
import java.util.*;
public class Ortoedro {

	private double ancho;
	private double largo;
	private double alto;
	private String tamanyo;
	private String color;
	
	
	//getters y setters
	public double getAncho() {
		return ancho;
	}
	public void setAncho(double ancho) {
		this.ancho = ancho;
	}
	public double getLargo() {
		return largo;
	}
	public void setLargo(double largo) {
		this.largo = largo;
	}
	public double getAlto() {
		return alto;
	}
	public void setAlto(double alto) {
		this.alto = alto;
	}
	public String getTamanyo() {
		return tamanyo;
	}
	public void setTamanyo(String tamanyo) {
		this.tamanyo = tamanyo;
	}
	

	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	//metodos
	double volumen() {
		double volumen;
		volumen=ancho*largo*alto;
		volumen=Math.round(volumen*100.0)/100.0;	
		return volumen;
	}
	
	// 2*((largp*ancho)+(largo*alto)+(alto*ancho))
	double superficie() {
		double superficie;
		superficie=2*((largo*alto)+(largo*ancho)+(alto*ancho));
		superficie=Math.round(superficie*100.0)/100.0;
		return superficie;
	}
	
	void asignarColor() {
		Random r= new Random();
		int num=r.nextInt(1, 3);
		if (num==1) {
			color="verde";
			
		}
		else if (num==2) {
			color="azul";
		}	
	}
	 
	void asignarTamanyo() {
		if (alto==1.0) {
			tamanyo="pequeño";
		}
		else if (alto==2.0) {
			tamanyo="mediano";
		}
		else if (alto==3.0) {
			tamanyo="grande";
		}
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
