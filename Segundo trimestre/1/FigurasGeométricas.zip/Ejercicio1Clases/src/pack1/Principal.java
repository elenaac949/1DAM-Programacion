package pack1;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//ESFERAS
		
		Esfera esferaP=new Esfera();
		esferaP.setRadio(1);
		esferaP.asignarColor();
		esferaP.asignarTamanyo();

		
		Esfera esferaM=new Esfera();
		esferaM.setRadio(2);
		esferaM.asignarColor();
		esferaM.asignarTamanyo();
		
		Esfera esferaG=new Esfera();
		esferaG.setRadio(3);
		esferaG.asignarColor();
		esferaG.asignarTamanyo();
		
		
		System.out.println("La superficie de la esfera de tamaño "+esferaP.getTamanyo()+" y de color "+esferaP.getColor()+" es "+esferaP.superficie());
		System.out.println("El volumen de la esfera de tamaño "+esferaP.getTamanyo()+" y de color "+esferaP.getColor()+" es "+esferaP.volumen());
		System.out.println();
		System.out.println("La superficie de la esfera de tamaño "+esferaM.getTamanyo()+" y de color "+esferaM.getColor()+" es "+esferaM.superficie());
		System.out.println("El volumen de la esfera de tamaño "+esferaM.getTamanyo()+" y de color "+esferaM.getColor()+" es "+esferaM.volumen());
		System.out.println();
		System.out.println("La superficie de la esfera de tamaño "+esferaG.getTamanyo()+" y de color "+esferaG.getColor()+" es "+esferaG.superficie());
		System.out.println("El volumen de la esfera de tamaño "+esferaG.getTamanyo()+" y de color "+esferaG.getColor()+" es "+esferaG.volumen());
		
		
		//CILINDROS
		
		Cilindro cp=new Cilindro();
		cp.setRadio(1);
		cp.setAltura(1);
		cp.asignarColor();
		cp.asignarTamanyo();
		
		Cilindro cm=new Cilindro();
		cm.setRadio(2);
		cm.setAltura(2);
		cm.asignarColor();
		cm.asignarTamanyo();
		
		Cilindro cg=new Cilindro();
		cg.setRadio(3);
		cg.setAltura(3);
		cg.asignarColor();
		cg.asignarTamanyo();
		
		
		System.out.println("**********************************************************************************************");
		System.out.println("La superficie del cilindro "+ cp.getTamanyo()+" y de color "+cp.getColor()+" es "+cp.superficie());
		System.out.println("El volumen del cilindro "+ cp.getTamanyo()+" y de color "+cp.getColor()+" es "+cp.volumen());
		System.out.println();
		System.out.println("La superficie del cilindro "+ cm.getTamanyo()+" y de color "+cm.getColor()+" es "+cm.superficie());
		System.out.println("El volumen del cilindro "+ cm.getTamanyo()+" y de color "+cm.getColor()+" es "+cm.volumen());
		System.out.println();
		System.out.println("La superficie del cilindro "+ cg.getTamanyo()+" y de color "+cg.getColor()+" es "+cg.superficie());
		System.out.println("El volumen del cilindro "+ cg.getTamanyo()+" y de color "+cg.getColor()+" es "+cg.volumen());
		
		//ORTOEDRO
		
		Ortoedro op=new Ortoedro();
		op.setAlto(1);
		op.setAncho(1);
		op.setLargo(1);
		op.asignarColor();
		op.asignarTamanyo();
		
		Ortoedro om=new Ortoedro();
		om.setAlto(2);
		om.setAncho(2);
		om.setLargo(2);
		om.asignarColor();
		om.asignarTamanyo();
		
		Ortoedro og=new Ortoedro();
		og.setAlto(3);
		og.setAncho(3);
		og.setLargo(3);
		og.asignarColor();
		og.asignarTamanyo();
		
		System.out.println("**********************************************************************************************");
		System.out.println("La superficie del ortoedro "+ op.getTamanyo()+" y de color "+op.getColor()+" es de "+op.superficie());
		System.out.println("El volumen del ortoedro "+op.getTamanyo()+" y de color "+op.getColor()+" es de "+op.volumen());
		System.out.println();
		System.out.println("La superficie del ortoedro "+om.getTamanyo()+" y de color "+om.getColor()+" es de "+om.superficie());
		System.out.println("El volumen del ortoedro "+om.getTamanyo()+" y de color "+om.getColor()+" es de "+om.volumen());
		System.out.println();
		System.out.println("La superficie del ortoedro "+og.getTamanyo()+" y de color "+og.getColor()+" es de "+og.superficie());
		System.out.println("El volumen del ortoedro "+og.getTamanyo()+" y de color "+og.getColor()+" es de "+og.volumen());
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
