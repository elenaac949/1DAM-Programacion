package pack1;
import java.util.*;
public class Cilindro {

	
	
	private double radio;
	private double altura;
	private String color;
	private String tamanyo;
	
	
	
	//getters y setters
	public double getRadio() {
		return radio;
	}
	public void setRadio(double radio) {
		this.radio = radio;
	}
	public double getAltura() {
		return altura;
	}
	public void setAltura(double altura) {
		this.altura = altura;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getTamanyo() {
		return tamanyo;
	}
	public void setTamanyo(String tamanyo) {
		this.tamanyo = tamanyo;
	}
	
	//metodos
	
	//volumen= π r² h
	//area=2π r h + 2π r²
	
	
	double volumen() {
		double volumen;
		volumen=Math.PI*Math.pow(radio, 2)*altura;
		volumen=Math.round(volumen*100.0)/100.0;	
		return volumen;
	}
	
	double superficie() {
		double superficie;
		superficie=(2*Math.PI*radio*altura)+(2*Math.PI*Math.pow(radio, 2));
		superficie=Math.round(superficie*100.0)/100.0;
		return superficie;
	}
	
	void asignarColor() {
		Random r= new Random();
		int num=r.nextInt(1, 3);
		if (num==1) {
			color="verde";
			
		}
		else if (num==2) {
			color="azul";
		}	
	}
	 
	void asignarTamanyo() {
		if (radio==1.0) {
			tamanyo="pequeño";
		}
		else if (radio==2.0) {
			tamanyo="mediano";
		}
		else if (radio==3.0) {
			tamanyo="grande";
		}
	}
	
	
	
	
}
